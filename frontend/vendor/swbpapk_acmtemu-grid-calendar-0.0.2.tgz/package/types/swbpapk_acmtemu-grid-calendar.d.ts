import * as _angular_core from '@angular/core';
import { CdkDragDrop, DragRef } from '@angular/cdk/drag-drop';

/** Auf dem Fuenf-Minuten-Raster erzeugte Zeitspanne aus einer leeren Grid-Spalte. */
interface EventDrawRequest {
    start: string;
    end: string;
    resourceId?: number;
}

/** Eine Ressource/ein Benutzer, dem Events zugeordnet werden können. */
interface CalendarResource {
    id: number;
    name: string;
    avatarUrl?: string;
    color?: string;
}

/**
 * Ein Termin im Grid. `start`/`end` sind ISO-8601-Strings, damit das Objekt
 * verlustfrei als JSON rein- und rausgereicht werden kann (kein Date-Objekt
 * im öffentlichen Vertrag).
 */
interface CalendarEvent {
    id: number;
    title: string;
    /** Kompakter Ersatz fuer einen zu breiten Titel, maximal drei Zeichen. */
    shortTitle?: string;
    start: string;
    end: string;
    resourceId?: number;
    category?: string;
    color?: string;
    imageUrl?: string;
    /** Lokaler, noch nicht persistierter Zeichenentwurf mit negativer ID. */
    isDraft?: boolean;
    meta?: Record<string, unknown>;
}

/** Bearbeitbarer Kommentar einer Checklistenaufgabe. */
interface CalendarTaskComment {
    id: number;
    text: string;
    createdAt: string;
    updatedAt?: string;
    author?: string;
}

/** Datumsbezogene Checklistenaufgabe ohne Uhrzeit. */
interface CalendarTask {
    id: number;
    name: string;
    /** Lokales Kalenderdatum im Format YYYY-MM-DD. */
    date: string;
    resourceId: number;
    /** Eine Ebene Unteraufgaben; fehlt bei einer Hauptaufgabe. */
    parentId?: number;
    completed: boolean;
    comments?: CalendarTaskComment[];
}

/** Gemeinsamer JSON-Eingabevertrag fuer Ressourcen, Events und Checklisten-Tasks. */
interface CalendarGridData {
    resources?: CalendarResource[];
    events?: CalendarEvent[];
    tasks?: CalendarTask[];
}

/** Legt fest, wofür die Spalten des Grids stehen. */
type GridColumnMode = 'date' | 'resource';

/** Sichtbarkeit der zeitgebundenen Grid-Ansicht und der datumsgelagerten Tasks. */
type GridContentMode = 'both' | 'grid' | 'tasks';

/**
 * Zeitraster-Konfiguration, mit der GridLayoutService rechnet. Der Startpunkt
 * jeder Ansicht ergibt sich aus `anchorDate` (rollierendes Fenster), nicht aus
 * einem fixen Wochenstart.
 */
interface GridConfig {
    workingHoursStart: number;
    workingHoursEnd: number;
    pixelsPerHour: number;
    /** Abstand der Hilfslinien in Minuten; Verschieben, Resize und Zeichnen rasten darauf ein. Default: 5. */
    gridLineIntervalMinutes?: number;
}

/**
 * Theming-Input. Jeder Key wird von ThemeService 1:1 als CSS Custom Property
 * `--glc-<kebab-case-key>` auf dem Host-Element gesetzt (siehe Phase 2).
 */
interface GridTheme {
    colorPrimary?: string;
    colorBackground?: string;
    colorBorder?: string;
    colorEventDefault?: string;
    /** Farbe der vollen-Stunden-Linie samt Zeitachsen-Beschriftung (siehe TimeAxisComponent/DayColumnComponent). */
    colorHourLine?: string;
    fontFamily?: string;
    slotHeightPx?: number;
}

/** Sichtbarer Zeitbereich des Grids. */
type GridViewMode = 'day' | '3day' | 'week';

/** Eine dezente Hintergrund-Hilfslinie im Raster, siehe GridLayoutService.computeGridLines. */
interface GridLine {
    offsetPx: number;
    /** true bei vollen Stunden (kräftigere Linie), false bei den Zwischenschritten (z.B. 30-Min-Marke). */
    isHour: boolean;
    /** Uhrzeit, für die diese Linie steht (Anker beim Drag&Drop). */
    hours: number;
    minutes: number;
}

/** Ergebnis der Layout-Berechnung: Pixel-/Prozent-Werte für die Darstellung eines Events. */
interface EventLayout {
    event: CalendarEvent;
    topPx: number;
    heightPx: number;
    leftPercent: number;
    widthPercent: number;
}

declare class GridLayoutService {
    /** Liefert die sichtbaren Tage als Mitternachts-Daten, beginnend bei anchorDate. */
    computeVisibleRange(viewMode: GridViewMode, anchorDate: Date): Date[];
    /** Pixel-Offset eines Zeitpunkts relativ zum Spaltenanfang (Arbeitszeit-Fenster). */
    timeToOffset(time: Date, config: GridConfig): number;
    /** Liegt der Zeitpunkt innerhalb des Arbeitszeit-Fensters? Für die "Jetzt"-Linie: sonst würde
     * timeToOffset auf den Rand klemmen und eine falsche Uhrzeit an der falschen Stelle anzeigen. */
    isWithinWorkingHours(time: Date, config: GridConfig): boolean;
    /**
     * Layoutet alle Events einer Spalte (ein Tag bzw. ein Tag einer Person): auf den Tag
     * geclippt. Jeder Event nutzt die volle Spaltenbreite (eine Spalte gehört bereits genau
     * einem Tag/einer Person) — kein Nebeneinander-Splitting bei zeitlicher Überlappung.
     */
    layoutEventsForColumn(events: CalendarEvent[], columnDate: Date, config: GridConfig): EventLayout[];
    /** Die Hilfslinie, die einer Position (px ab Spaltenanfang) am nächsten liegt. */
    nearestGridLine(lines: GridLine[], topPx: number): GridLine;
    /** Zeitpunkt einer Hilfslinie an einem bestimmten Tag. */
    timeOnGridLine(line: GridLine, columnDate: Date): Date;
    /** Vergleicht zwei Zeitpunkte auf Kalendertag-Gleichheit (unabhängig von Uhrzeit). */
    isSameDay(a: Date, b: Date): boolean;
    /** ISO-8601-Kalenderwoche (die Woche mit dem ersten Donnerstag des Jahres ist KW 1). */
    getIsoWeekNumber(date: Date): number;
    /** Pixel-Offsets dezentere Hilfslinien im Abstand von gridLineIntervalMinutes (Default 5). Volle Stunden sind als isHour markiert. */
    computeGridLines(config: GridConfig): GridLine[];
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln (für explizite Höhen von Zeitachse/Spalten). */
    computeContentHeight(config: GridConfig): number;
    /**
     * Staucht/streckt die Stunden so, dass das Arbeitszeit-Fenster exakt in `availableHeightPx`
     * passt (kein Scrollen nötig). Ohne bekannte verfügbare Höhe (<= 0) bleibt config.pixelsPerHour
     * unverändert.
     */
    computeEffectivePixelsPerHour(config: GridConfig, availableHeightPx: number): number;
    private startOfDay;
    /** Letzter Zeitpunkt des Tages, NICHT Mitternacht des Folgetags (sonst kippt timeToOffset). */
    private endOfDay;
    private addDays;
    private clamp;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridLayoutService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<GridLayoutService>;
}

/** Eine Spalte im Grid: entweder ein Tag (columnMode 'date') oder eine Person/Ressource (columnMode 'resource'). */
interface GridColumn {
    key: string;
    label: string;
    date?: Date;
    resource?: CalendarResource;
}

/** Ein sichtbarer Tag mit seinen Sub-Spalten (1 im columnMode 'date', 1 pro Ressource im columnMode 'resource'). */
interface DayGroup {
    date: Date;
    weekNumber: number;
    isToday: boolean;
    columns: GridColumn[];
}

interface DragAnchor {
    line: GridLine;
    columnKey: string;
}
/** Interner, reaktiver State des Grids (Signals). Wird von GridCalendarComponent instanziiert, kein globaler Store. */
declare class GridStateService {
    private readonly layoutService;
    private readonly destroyRef;
    private readonly _events;
    private readonly _tasks;
    private readonly _resources;
    private readonly _viewMode;
    private readonly _columnMode;
    private readonly _anchorDate;
    private readonly _config;
    private readonly _containerHeightPx;
    private readonly _now;
    readonly events: _angular_core.Signal<CalendarEvent[]>;
    readonly tasks: _angular_core.Signal<CalendarTask[]>;
    readonly resources: _angular_core.Signal<CalendarResource[]>;
    readonly viewMode: _angular_core.Signal<GridViewMode>;
    readonly columnMode: _angular_core.Signal<GridColumnMode>;
    readonly anchorDate: _angular_core.Signal<Date>;
    readonly config: _angular_core.Signal<GridConfig>;
    readonly containerHeightPx: _angular_core.Signal<number>;
    /**
     * config, aber mit an die verfügbare Höhe angepasster pixelsPerHour, damit das
     * Arbeitszeit-Fenster ohne Scrollen exakt in den Container passt (siehe
     * GridLayoutService.computeEffectivePixelsPerHour).
     */
    readonly effectiveConfig: _angular_core.Signal<GridConfig>;
    /** 1/3/7 Tage ab anchorDate (rollierendes Fenster, kein fixer Wochenstart). */
    readonly visibleDates: _angular_core.Signal<Date[]>;
    /**
     * Ein Eintrag pro sichtbarem Tag. Im columnMode 'date' hat jeder Tag genau eine Sub-Spalte
     * (der ganze Tag), im columnMode 'resource' eine Sub-Spalte pro Person (Tag×Person-Raster,
     * eine gemeinsame Zeitachse für alle Tage/Personen).
     */
    readonly dayGroups: _angular_core.Signal<DayGroup[]>;
    /** Alle Sub-Spalten flach (für Lookups, z.B. beim Drag&Drop-Zielspalten-Abgleich). */
    readonly flatColumns: _angular_core.Signal<GridColumn[]>;
    /** Checklist-Tasks pro sichtbarer Datum-/Ressourcen-Spalte; Task-Daten enthalten keine Uhrzeit. */
    readonly tasksByColumn: _angular_core.Signal<Map<string, CalendarTask[]>>;
    /** Event-Layout je Sub-Spalte, berechnet über GridLayoutService (keine Business-Logik hier, nur Orchestrierung). */
    readonly layoutByColumn: _angular_core.Signal<Map<string, EventLayout[]>>;
    /** Aktueller Zeitpunkt fuer die Live-Zeit-Linie; aktualisiert sich nur an vollen Minuten. */
    readonly now: _angular_core.Signal<Date>;
    readonly nowOffsetPx: _angular_core.Signal<number>;
    /** false außerhalb des Arbeitszeit-Fensters: sonst würde die Linie irreführend am Rand kleben. */
    readonly isNowVisible: _angular_core.Signal<boolean>;
    /** Pixel-Offsets der dezenten Hilfslinien (unabhängig vom Drag&Drop-Snapping-Raster). */
    readonly gridLinesPx: _angular_core.Signal<GridLine[]>;
    private readonly _dragAnchor;
    /** Hilfslinie + Spalte, an der die Oberkante des gerade gezogenen Events hängt (Vorschau = Drop-Ergebnis). */
    readonly dragAnchor: _angular_core.Signal<DragAnchor | null>;
    setDragAnchor(anchor: DragAnchor | null): void;
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln, als explizite Höhe für Zeitachse/Spalten (entspricht containerHeightPx, kein Scrollen nötig). */
    readonly contentHeightPx: _angular_core.Signal<number>;
    constructor();
    private buildColumnsForDay;
    setEvents(events: CalendarEvent[]): void;
    setTasks(tasks: CalendarTask[]): void;
    setResources(resources: CalendarResource[]): void;
    setViewMode(viewMode: GridViewMode): void;
    setColumnMode(columnMode: GridColumnMode): void;
    setAnchorDate(anchorDate: Date): void;
    setConfig(config: GridConfig): void;
    setContainerHeightPx(heightPx: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridStateService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<GridStateService>;
}

/** Öffentlicher Library-Einstiegspunkt mit Event-Raster und datumsgelagerter Task-Zeile. */
declare class GridCalendar {
    private readonly hostElement;
    private readonly themeService;
    private readonly destroyRef;
    protected readonly layoutService: GridLayoutService;
    readonly state: GridStateService;
    private readonly bodyEl;
    readonly event: _angular_core.InputSignal<CalendarEvent | undefined>;
    readonly events: _angular_core.InputSignal<CalendarEvent[]>;
    readonly tasks: _angular_core.InputSignal<CalendarTask[]>;
    readonly showCompletedTasks: _angular_core.InputSignal<boolean>;
    readonly contentMode: _angular_core.InputSignal<GridContentMode>;
    readonly resource: _angular_core.InputSignal<CalendarResource | undefined>;
    readonly resources: _angular_core.InputSignal<CalendarResource[]>;
    readonly data: _angular_core.InputSignal<CalendarGridData>;
    readonly viewMode: _angular_core.InputSignal<GridViewMode>;
    readonly columnMode: _angular_core.InputSignal<GridColumnMode>;
    readonly anchorDate: _angular_core.InputSignal<Date>;
    readonly theme: _angular_core.InputSignal<GridTheme>;
    readonly config: _angular_core.InputSignal<GridConfig>;
    /** Veto-Hook für Drag&Drop (wird in Phase 4, Schritt 16 verwendet). */
    readonly canMoveEvent: _angular_core.InputSignal<(event: CalendarEvent) => boolean>;
    readonly eventsChange: _angular_core.OutputEmitterRef<CalendarEvent[]>;
    readonly tasksChange: _angular_core.OutputEmitterRef<CalendarTask[]>;
    readonly eventMoved: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventClicked: _angular_core.OutputEmitterRef<CalendarEvent>;
    /** Doppelklick auf einen Event: ID für einen Editor der Host-App. */
    readonly eventEditRequested: _angular_core.OutputEmitterRef<number>;
    readonly eventDeleted: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventUpdated: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventCreateRequested: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly taskCommentsRequested: _angular_core.OutputEmitterRef<number>;
    /** Pills-Zeile (Personen-Namen) wird nur in columnMode 'resource' gerendert. */
    protected readonly hasResourceColumns: _angular_core.Signal<boolean>;
    private readonly normalizedEvents;
    protected readonly normalizedResources: _angular_core.Signal<CalendarResource[]>;
    private readonly normalizedTasks;
    /** Puffer unterhalb der letzten Stundenlinie, damit der Personen-Rahmen sie nicht am Eck abschneidet. */
    protected readonly frameBottomBufferPx = 6;
    protected readonly taskFrameMinHeightPx: _angular_core.Signal<number>;
    constructor();
    /** Berechnet aus dem CDK-Drop-Event die neue Start-/Endzeit (und ggf. Ressource) und meldet sie nach außen. */
    onColumnDropped(dropEvent: CdkDragDrop<string>): void;
    /** Entfernt einen Event aus dem Array und meldet die Änderung nach außen (immutable). */
    onEventDeleted(event: CalendarEvent): void;
    /** Aktualisiert einen Event (z. B. durch Resize) und meldet die Änderung nach außen (immutable). */
    onEventUpdated(updatedEvent: CalendarEvent): void;
    onEventDrawn(request: EventDrawRequest): void;
    onTasksChanged(updatedTasks: CalendarTask[]): void;
    private nextDraftId;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridCalendar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GridCalendar, "glc-grid-calendar", never, { "event": { "alias": "event"; "required": false; "isSignal": true; }; "events": { "alias": "events"; "required": false; "isSignal": true; }; "tasks": { "alias": "tasks"; "required": false; "isSignal": true; }; "showCompletedTasks": { "alias": "showCompletedTasks"; "required": false; "isSignal": true; }; "contentMode": { "alias": "contentMode"; "required": false; "isSignal": true; }; "resource": { "alias": "resource"; "required": false; "isSignal": true; }; "resources": { "alias": "resources"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "viewMode": { "alias": "viewMode"; "required": false; "isSignal": true; }; "columnMode": { "alias": "columnMode"; "required": false; "isSignal": true; }; "anchorDate": { "alias": "anchorDate"; "required": false; "isSignal": true; }; "theme": { "alias": "theme"; "required": false; "isSignal": true; }; "config": { "alias": "config"; "required": false; "isSignal": true; }; "canMoveEvent": { "alias": "canMoveEvent"; "required": false; "isSignal": true; }; }, { "eventsChange": "eventsChange"; "tasksChange": "tasksChange"; "eventMoved": "eventMoved"; "eventClicked": "eventClicked"; "eventEditRequested": "eventEditRequested"; "eventDeleted": "eventDeleted"; "eventUpdated": "eventUpdated"; "eventCreateRequested": "eventCreateRequested"; "taskCommentsRequested": "taskCommentsRequested"; }, never, never, true, never>;
}

/** Setzt GridTheme-Werte als CSS Custom Properties auf einem Host-Element. Keine hartkodierten Werte hier. */
declare class ThemeService {
    apply(theme: GridTheme, hostElement: HTMLElement): void;
    private toCssVarName;
    private toCssValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ThemeService>;
}

interface HourMark {
    label: string;
    topPx: number;
}
declare class TimeAxisComponent {
    private readonly layoutService;
    readonly config: _angular_core.InputSignal<GridConfig>;
    /** Eine Markierung pro voller Stunde im Arbeitszeit-Fenster, Position via GridLayoutService. */
    readonly hourMarks: _angular_core.Signal<HourMark[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimeAxisComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimeAxisComponent, "glc-time-axis", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class GridHeaderComponent {
    readonly dayGroups: _angular_core.InputSignal<DayGroup[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GridHeaderComponent, "glc-grid-header", never, { "dayGroups": { "alias": "dayGroups"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class EventItemComponent {
    private readonly layoutService;
    private readonly state;
    private readonly destroyRef;
    private readonly elementRef;
    private readonly ngZone;
    readonly layout: _angular_core.InputSignal<EventLayout>;
    readonly columnDate: _angular_core.InputSignal<Date>;
    readonly config: _angular_core.InputSignal<GridConfig>;
    readonly deleted: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventClicked: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly editRequested: _angular_core.OutputEmitterRef<number>;
    readonly eventUpdated: _angular_core.OutputEmitterRef<CalendarEvent>;
    private readonly resizeTopLine;
    private readonly resizeBottomLine;
    private readonly dragPreviewSignal;
    private readonly gridLines;
    private resizeActive;
    private resizeStartY;
    private readonly root;
    private readonly titleMeasure;
    /** Titel passt nicht in die aktuelle Event-Breite: Kurztitel zeigen, Uhrzeit ausblenden. */
    protected readonly compact: _angular_core.WritableSignal<boolean>;
    protected readonly displayTitle: _angular_core.Signal<string>;
    readonly timeRange: _angular_core.Signal<string>;
    readonly effectiveTopPx: _angular_core.Signal<number>;
    readonly effectiveHeightPx: _angular_core.Signal<number>;
    readonly effectiveTimeRange: _angular_core.Signal<string>;
    onEventClick(event: MouseEvent): void;
    onEventDblClick(event: MouseEvent): void;
    onEventKeyDown(event: KeyboardEvent): void;
    onCdkDragStarted(): void;
    onCdkDragEnded(): void;
    /** CDK-Hook: liefert die Position (oben links) der Vorschau-Box – eingerastet auf Hilfslinie + Spalte. */
    readonly snapToGrid: (pointer: {
        x: number;
        y: number;
    }, _ref: DragRef, _size: DOMRect, pickup: {
        x: number;
        y: number;
    }) => {
        x: number;
        y: number;
    };
    private readonly onScrollWhileDragging;
    constructor();
    private updateCompact;
    /** Verankert die Box-Oberkante an der nächsten Hilfslinie der Spalte unter x (Vorschau = Drop-Ergebnis). */
    private anchorTo;
    onDeleteClick(event: MouseEvent): void;
    onResizeStart(event: MouseEvent, edge: 'top' | 'bottom'): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EventItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EventItemComponent, "glc-event-item", never, { "layout": { "alias": "layout"; "required": true; "isSignal": true; }; "columnDate": { "alias": "columnDate"; "required": true; "isSignal": true; }; "config": { "alias": "config"; "required": true; "isSignal": true; }; }, { "deleted": "deleted"; "eventClicked": "eventClicked"; "editRequested": "editRequested"; "eventUpdated": "eventUpdated"; }, never, never, true, never>;
}

declare class DayColumnComponent {
    private readonly layoutService;
    private readonly destroyRef;
    readonly columnKey: _angular_core.InputSignal<string>;
    readonly layouts: _angular_core.InputSignal<EventLayout[]>;
    readonly columnDate: _angular_core.InputSignal<Date>;
    readonly config: _angular_core.InputSignal<GridConfig>;
    readonly borderColor: _angular_core.InputSignal<string | undefined>;
    readonly resourceId: _angular_core.InputSignal<number | undefined>;
    readonly gridLinesPx: _angular_core.InputSignal<GridLine[]>;
    readonly dropped: _angular_core.OutputEmitterRef<CdkDragDrop<string, string, any>>;
    readonly eventClicked: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventEditRequested: _angular_core.OutputEmitterRef<number>;
    readonly eventDeleted: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventUpdated: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventDrawn: _angular_core.OutputEmitterRef<EventDrawRequest>;
    private readonly gridLines;
    private readonly drawStartLine;
    private readonly drawEndLine;
    /** Gezeichneter Bereich von Hilfslinie zu Hilfslinie, mindestens eine Linie hoch. */
    private readonly drawRange;
    protected readonly drawingLayout: _angular_core.Signal<{
        topPx: number;
        heightPx: number;
    } | null>;
    /** Hilfsuhr: Hilfslinie unter der Maus, nur über leerem Raster und ohne gedrückte Maustaste. */
    protected readonly hoverLine: _angular_core.WritableSignal<GridLine | null>;
    protected readonly hoverLabel: _angular_core.Signal<string>;
    onMouseMove(event: MouseEvent): void;
    /** Hilfslinie an einer Bildschirm-Y-Position (Linien beginnen an der Innenkante der Spalte). */
    private lineAt;
    onDropped(event: CdkDragDrop<string>): void;
    onDrawStart(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DayColumnComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DayColumnComponent, "glc-day-column", never, { "columnKey": { "alias": "columnKey"; "required": true; "isSignal": true; }; "layouts": { "alias": "layouts"; "required": true; "isSignal": true; }; "columnDate": { "alias": "columnDate"; "required": true; "isSignal": true; }; "config": { "alias": "config"; "required": true; "isSignal": true; }; "borderColor": { "alias": "borderColor"; "required": false; "isSignal": true; }; "resourceId": { "alias": "resourceId"; "required": false; "isSignal": true; }; "gridLinesPx": { "alias": "gridLinesPx"; "required": false; "isSignal": true; }; }, { "dropped": "dropped"; "eventClicked": "eventClicked"; "eventEditRequested": "eventEditRequested"; "eventDeleted": "eventDeleted"; "eventUpdated": "eventUpdated"; "eventDrawn": "eventDrawn"; }, never, never, true, never>;
}

interface TaskItemView {
    task: CalendarTask;
    completed: boolean;
    commentsCount: number;
    commentsLabel: string;
    resourceColor?: string;
}
interface TaskRowView extends TaskItemView {
    children: TaskItemView[];
    expandLabel: string;
    hasChildren: boolean;
    expanded: boolean;
}
declare class TaskListColumnComponent {
    readonly tasks: _angular_core.InputSignal<CalendarTask[]>;
    readonly resources: _angular_core.InputSignal<CalendarResource[]>;
    readonly showCompleted: _angular_core.InputSignal<boolean>;
    readonly tasksChange: _angular_core.OutputEmitterRef<CalendarTask[]>;
    readonly commentsRequested: _angular_core.OutputEmitterRef<number>;
    protected readonly expandedIds: _angular_core.WritableSignal<Set<number>>;
    protected readonly rows: _angular_core.Signal<TaskRowView[]>;
    private taskItem;
    protected toggleExpanded(id: number): void;
    protected toggleCompleted(id: number, completed: boolean): void;
    protected onCheckboxChange(id: number, event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TaskListColumnComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TaskListColumnComponent, "glc-task-list-column", never, { "tasks": { "alias": "tasks"; "required": false; "isSignal": true; }; "resources": { "alias": "resources"; "required": false; "isSignal": true; }; "showCompleted": { "alias": "showCompleted"; "required": false; "isSignal": true; }; }, { "tasksChange": "tasksChange"; "commentsRequested": "commentsRequested"; }, never, never, true, never>;
}

export { DayColumnComponent, EventItemComponent, GridCalendar, GridHeaderComponent, GridLayoutService, TaskListColumnComponent, ThemeService, TimeAxisComponent };
export type { CalendarEvent, CalendarGridData, CalendarResource, CalendarTask, CalendarTaskComment, DayGroup, EventDrawRequest, EventLayout, GridColumn, GridColumnMode, GridConfig, GridContentMode, GridLine, GridTheme, GridViewMode };
