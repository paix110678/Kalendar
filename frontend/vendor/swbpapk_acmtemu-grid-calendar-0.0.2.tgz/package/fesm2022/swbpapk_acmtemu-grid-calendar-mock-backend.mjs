import * as i0 from '@angular/core';
import { inject, Injectable, InjectionToken, makeEnvironmentProviders } from '@angular/core';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { of, throwError, delay } from 'rxjs';

/** In-Memory-Datenhaltung für das simulierte Backend. Kein echter Netzwerk-/Datenbankzugriff. */
class MockBackendStore {
    config = inject(MOCK_BACKEND_CONFIG);
    events = [...this.config.events];
    tasks = [...this.config.tasks];
    resources = [...this.config.resources];
    getEvents() {
        return [...this.events];
    }
    getResources() {
        return [...this.resources];
    }
    getTasks() {
        return [...this.tasks];
    }
    createTask(task) {
        const created = {
            id: this.generateTaskId(),
            name: task.name ?? '',
            date: task.date ?? todayDateKey$1(),
            resourceId: task.resourceId ?? this.resources[0]?.id ?? 0,
            parentId: task.parentId,
            completed: task.completed ?? false,
            comments: task.comments ?? [],
        };
        this.tasks.push(created);
        return created;
    }
    updateTask(id, patch) {
        const index = this.tasks.findIndex((task) => task.id === id);
        if (index === -1)
            return undefined;
        const updated = { ...this.tasks[index], ...patch, id };
        this.tasks[index] = updated;
        return updated;
    }
    deleteTask(id) {
        const index = this.tasks.findIndex((task) => task.id === id);
        if (index === -1)
            return false;
        this.tasks.splice(index, 1);
        this.tasks = this.tasks.filter((task) => task.parentId !== id);
        return true;
    }
    createEvent(event) {
        const created = {
            id: this.generateId(),
            title: event.title ?? '',
            shortTitle: event.shortTitle,
            start: event.start ?? new Date().toISOString(),
            end: event.end ?? new Date().toISOString(),
            resourceId: event.resourceId,
            category: event.category,
            color: event.color,
            imageUrl: event.imageUrl,
            meta: event.meta,
        };
        this.events.push(created);
        return created;
    }
    updateEvent(id, patch) {
        const index = this.events.findIndex((event) => event.id === id);
        if (index === -1) {
            return undefined;
        }
        const updated = { ...this.events[index], ...patch, id };
        this.events[index] = updated;
        return updated;
    }
    deleteEvent(id) {
        const index = this.events.findIndex((event) => event.id === id);
        if (index === -1) {
            return false;
        }
        this.events.splice(index, 1);
        return true;
    }
    generateId() {
        const positiveIds = this.events.map((event) => event.id).filter((id) => id > 0);
        return Math.max(0, ...positiveIds) + 1;
    }
    generateTaskId() {
        const positiveIds = this.tasks.map((task) => task.id).filter((id) => id > 0);
        return Math.max(0, ...positiveIds) + 1;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: MockBackendStore, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: MockBackendStore });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: MockBackendStore, decorators: [{
            type: Injectable
        }] });
function todayDateKey$1() {
    const date = new Date();
    const pad = (value) => String(value).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

/** Liefert einen ISO-String für "heute" um die angegebene Uhrzeit (Seed-Daten sind immer aktuell). */
function todayAt(hours, minutes = 0) {
    const date = new Date();
    date.setHours(hours, minutes, 0, 0);
    return date.toISOString();
}
const DEFAULT_MOCK_RESOURCES = [
    { id: 1, name: 'Anna', color: '#d9368f' },
    { id: 2, name: 'Ben', color: '#2f9e44' },
];
const DEFAULT_MOCK_EVENTS = [
    {
        id: 1,
        title: 'Kickoff Meeting',
        shortTitle: 'KOM',
        start: todayAt(9),
        end: todayAt(10),
        color: '#4a90d9',
        resourceId: 1,
    },
    {
        id: 2,
        title: 'Lunch',
        shortTitle: 'LCH',
        start: todayAt(12),
        end: todayAt(13),
        color: '#e0a030',
        resourceId: 2,
    },
];
function todayDateKey() {
    const date = new Date();
    const pad = (value) => String(value).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}
const DEFAULT_MOCK_TASKS = [
    {
        id: 1,
        name: 'Unterlagen vorbereiten',
        date: todayDateKey(),
        resourceId: 1,
        completed: false,
        comments: [{ id: 1, text: 'Bitte aktuelle Zahlen verwenden.', createdAt: new Date().toISOString(), author: 'Demo' }],
    },
    {
        id: 2,
        name: 'Agenda abstimmen',
        date: todayDateKey(),
        resourceId: 1,
        completed: false,
    },
    {
        id: 3,
        name: 'Raum vorbereiten',
        date: todayDateKey(),
        resourceId: 1,
        parentId: 2,
        completed: false,
    },
    {
        id: 4,
        name: 'Teilnehmerliste versenden',
        date: todayDateKey(),
        resourceId: 1,
        parentId: 2,
        completed: false,
    },
];

const DEFAULT_CONFIG = {
    events: DEFAULT_MOCK_EVENTS,
    tasks: DEFAULT_MOCK_TASKS,
    resources: DEFAULT_MOCK_RESOURCES,
    latencyMs: 300,
    basePath: '/api',
};
const MOCK_BACKEND_CONFIG = new InjectionToken('MOCK_BACKEND_CONFIG', {
    factory: () => DEFAULT_CONFIG,
});
/**
 * Registriert das simulierte Backend (Seed-Daten + In-Memory-Store). Der eigentliche Interceptor
 * muss zusätzlich per `provideHttpClient(withInterceptors([mockEventsInterceptor]))` aktiviert werden.
 */
function provideMockBackend(config = {}) {
    return makeEnvironmentProviders([
        { provide: MOCK_BACKEND_CONFIG, useValue: { ...DEFAULT_CONFIG, ...config } },
        MockBackendStore,
    ]);
}

/** Simuliert /api/events + /api/resources über einen In-Memory-Store, keine echten Netzwerkaufrufe. */
const mockEventsInterceptor = (req, next) => {
    const config = inject(MOCK_BACKEND_CONFIG);
    const basePath = config.basePath;
    if (!req.url.startsWith(basePath)) {
        return next(req);
    }
    const store = inject(MockBackendStore);
    const response = handleRequest(req, store, basePath);
    const event$ = response
        ? of(response)
        : throwError(() => new HttpErrorResponse({ status: 404, url: req.url, statusText: 'Not Found' }));
    return event$.pipe(delay(config.latencyMs));
};
function handleRequest(req, store, basePath) {
    const eventsUrl = `${basePath}/events`;
    const tasksUrl = `${basePath}/tasks`;
    const resourcesUrl = `${basePath}/resources`;
    if (req.url === eventsUrl && req.method === 'GET') {
        return new HttpResponse({ status: 200, body: store.getEvents() });
    }
    if (req.url === eventsUrl && req.method === 'POST') {
        return new HttpResponse({ status: 201, body: store.createEvent(req.body) });
    }
    if (req.url.startsWith(`${eventsUrl}/`)) {
        const id = Number(req.url.slice(eventsUrl.length + 1));
        if (!Number.isInteger(id) || id <= 0) {
            return null;
        }
        if (req.method === 'PATCH') {
            const updated = store.updateEvent(id, req.body);
            return updated ? new HttpResponse({ status: 200, body: updated }) : null;
        }
        if (req.method === 'DELETE') {
            return store.deleteEvent(id) ? new HttpResponse({ status: 204 }) : null;
        }
    }
    if (req.url === tasksUrl && req.method === 'GET') {
        return new HttpResponse({ status: 200, body: store.getTasks() });
    }
    if (req.url === tasksUrl && req.method === 'POST') {
        return new HttpResponse({ status: 201, body: store.createTask(req.body) });
    }
    if (req.url.startsWith(`${tasksUrl}/`)) {
        const id = Number(req.url.slice(tasksUrl.length + 1));
        if (!Number.isInteger(id) || id <= 0)
            return null;
        if (req.method === 'PATCH') {
            const updated = store.updateTask(id, req.body);
            return updated ? new HttpResponse({ status: 200, body: updated }) : null;
        }
        if (req.method === 'DELETE') {
            return store.deleteTask(id) ? new HttpResponse({ status: 204 }) : null;
        }
    }
    if (req.url === resourcesUrl && req.method === 'GET') {
        return new HttpResponse({ status: 200, body: store.getResources() });
    }
    return null;
}

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_MOCK_EVENTS, DEFAULT_MOCK_RESOURCES, DEFAULT_MOCK_TASKS, MOCK_BACKEND_CONFIG, MockBackendStore, mockEventsInterceptor, provideMockBackend };
//# sourceMappingURL=swbpapk_acmtemu-grid-calendar-mock-backend.mjs.map
