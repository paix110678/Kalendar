import * as i0 from '@angular/core';
import { Injectable, inject, DestroyRef, signal, computed, ElementRef, NgZone, input, output, viewChild, afterNextRender, ChangeDetectionStrategy, Component, effect } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CdkDrag, CdkDragPreview, CdkDropList, CdkDropListGroup } from '@angular/cdk/drag-drop';

const DAY_COUNT_BY_VIEW_MODE = {
    day: 1,
    '3day': 3,
    week: 7,
};
class GridLayoutService {
    /** Liefert die sichtbaren Tage als Mitternachts-Daten, beginnend bei anchorDate. */
    computeVisibleRange(viewMode, anchorDate) {
        const start = this.startOfDay(anchorDate);
        const count = DAY_COUNT_BY_VIEW_MODE[viewMode];
        return Array.from({ length: count }, (_, i) => this.addDays(start, i));
    }
    /** Pixel-Offset eines Zeitpunkts relativ zum Spaltenanfang (Arbeitszeit-Fenster). */
    timeToOffset(time, config) {
        const minutesSinceStart = time.getHours() * 60 + time.getMinutes() - config.workingHoursStart * 60;
        const totalMinutes = (config.workingHoursEnd - config.workingHoursStart) * 60;
        const clamped = Math.min(Math.max(minutesSinceStart, 0), totalMinutes);
        return (clamped / 60) * config.pixelsPerHour;
    }
    /** Liegt der Zeitpunkt innerhalb des Arbeitszeit-Fensters? Für die "Jetzt"-Linie: sonst würde
     * timeToOffset auf den Rand klemmen und eine falsche Uhrzeit an der falschen Stelle anzeigen. */
    isWithinWorkingHours(time, config) {
        const minutes = time.getHours() * 60 + time.getMinutes();
        return minutes >= config.workingHoursStart * 60 && minutes <= config.workingHoursEnd * 60;
    }
    /**
     * Layoutet alle Events einer Spalte (ein Tag bzw. ein Tag einer Person): auf den Tag
     * geclippt. Jeder Event nutzt die volle Spaltenbreite (eine Spalte gehört bereits genau
     * einem Tag/einer Person) — kein Nebeneinander-Splitting bei zeitlicher Überlappung.
     */
    layoutEventsForColumn(events, columnDate, config) {
        const dayStart = this.startOfDay(columnDate);
        const dayEnd = this.endOfDay(columnDate);
        return events
            .map((event) => ({
            event,
            start: this.clamp(new Date(event.start), dayStart, dayEnd),
            end: this.clamp(new Date(event.end), dayStart, dayEnd),
        }))
            .filter(({ start, end }) => end > start)
            .map(({ event, start, end }) => {
            const topPx = this.timeToOffset(start, config);
            return {
                event,
                topPx,
                heightPx: this.timeToOffset(end, config) - topPx,
                leftPercent: 0,
                widthPercent: 100,
            };
        });
    }
    /** Die Hilfslinie, die einer Position (px ab Spaltenanfang) am nächsten liegt. */
    nearestGridLine(lines, topPx) {
        return lines.reduce((best, line) => Math.abs(line.offsetPx - topPx) < Math.abs(best.offsetPx - topPx) ? line : best);
    }
    /** Zeitpunkt einer Hilfslinie an einem bestimmten Tag. */
    timeOnGridLine(line, columnDate) {
        const result = this.startOfDay(columnDate);
        result.setHours(line.hours, line.minutes, 0, 0);
        return result;
    }
    /** Vergleicht zwei Zeitpunkte auf Kalendertag-Gleichheit (unabhängig von Uhrzeit). */
    isSameDay(a, b) {
        return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
    }
    /** ISO-8601-Kalenderwoche (die Woche mit dem ersten Donnerstag des Jahres ist KW 1). */
    getIsoWeekNumber(date) {
        const target = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        const dayNumber = (target.getUTCDay() + 6) % 7; // Montag=0 .. Sonntag=6
        target.setUTCDate(target.getUTCDate() - dayNumber + 3); // Donnerstag derselben Woche
        const firstThursday = new Date(Date.UTC(target.getUTCFullYear(), 0, 4));
        const firstDayNumber = (firstThursday.getUTCDay() + 6) % 7;
        firstThursday.setUTCDate(firstThursday.getUTCDate() - firstDayNumber + 3);
        return 1 + Math.round((target.getTime() - firstThursday.getTime()) / (7 * 24 * 60 * 60 * 1000));
    }
    /** Pixel-Offsets dezentere Hilfslinien im Abstand von gridLineIntervalMinutes (Default 5). Volle Stunden sind als isHour markiert. */
    computeGridLines(config) {
        const interval = config.gridLineIntervalMinutes ?? 5;
        const totalMinutes = (config.workingHoursEnd - config.workingHoursStart) * 60;
        const lines = [];
        for (let minutes = 0; minutes <= totalMinutes; minutes += interval) {
            const minutesOfDay = config.workingHoursStart * 60 + minutes;
            lines.push({
                offsetPx: (minutes / 60) * config.pixelsPerHour,
                isHour: minutes % 60 === 0,
                hours: Math.floor(minutesOfDay / 60),
                minutes: minutesOfDay % 60,
            });
        }
        if (lines[lines.length - 1]?.offsetPx !== totalMinutes / 60 * config.pixelsPerHour) {
            lines.push({
                offsetPx: (totalMinutes / 60) * config.pixelsPerHour,
                isHour: config.workingHoursEnd % 1 === 0,
                hours: config.workingHoursEnd,
                minutes: 0,
            });
        }
        return lines;
    }
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln (für explizite Höhen von Zeitachse/Spalten). */
    computeContentHeight(config) {
        return (config.workingHoursEnd - config.workingHoursStart) * config.pixelsPerHour;
    }
    /**
     * Staucht/streckt die Stunden so, dass das Arbeitszeit-Fenster exakt in `availableHeightPx`
     * passt (kein Scrollen nötig). Ohne bekannte verfügbare Höhe (<= 0) bleibt config.pixelsPerHour
     * unverändert.
     */
    computeEffectivePixelsPerHour(config, availableHeightPx) {
        const totalHours = config.workingHoursEnd - config.workingHoursStart;
        if (totalHours <= 0 || availableHeightPx <= 0) {
            return config.pixelsPerHour;
        }
        return availableHeightPx / totalHours;
    }
    startOfDay(date) {
        const result = new Date(date);
        result.setHours(0, 0, 0, 0);
        return result;
    }
    /** Letzter Zeitpunkt des Tages, NICHT Mitternacht des Folgetags (sonst kippt timeToOffset). */
    endOfDay(date) {
        const result = new Date(date);
        result.setHours(23, 59, 59, 999);
        return result;
    }
    addDays(date, days) {
        const result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }
    clamp(date, min, max) {
        if (date < min)
            return min;
        if (date > max)
            return max;
        return date;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridLayoutService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridLayoutService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridLayoutService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const DEFAULT_CONFIG$1 = {
    workingHoursStart: 8,
    workingHoursEnd: 18,
    pixelsPerHour: 60,
};
/** Interner, reaktiver State des Grids (Signals). Wird von GridCalendarComponent instanziiert, kein globaler Store. */
class GridStateService {
    layoutService = inject(GridLayoutService);
    destroyRef = inject(DestroyRef);
    _events = signal([], ...(ngDevMode ? [{ debugName: "_events" }] : /* istanbul ignore next */ []));
    _tasks = signal([], ...(ngDevMode ? [{ debugName: "_tasks" }] : /* istanbul ignore next */ []));
    _resources = signal([], ...(ngDevMode ? [{ debugName: "_resources" }] : /* istanbul ignore next */ []));
    _viewMode = signal('week', ...(ngDevMode ? [{ debugName: "_viewMode" }] : /* istanbul ignore next */ []));
    _columnMode = signal('date', ...(ngDevMode ? [{ debugName: "_columnMode" }] : /* istanbul ignore next */ []));
    _anchorDate = signal(new Date(), ...(ngDevMode ? [{ debugName: "_anchorDate" }] : /* istanbul ignore next */ []));
    _config = signal(DEFAULT_CONFIG$1, ...(ngDevMode ? [{ debugName: "_config" }] : /* istanbul ignore next */ []));
    _containerHeightPx = signal(0, ...(ngDevMode ? [{ debugName: "_containerHeightPx" }] : /* istanbul ignore next */ []));
    _now = signal(new Date(), ...(ngDevMode ? [{ debugName: "_now" }] : /* istanbul ignore next */ []));
    events = this._events.asReadonly();
    tasks = this._tasks.asReadonly();
    resources = this._resources.asReadonly();
    viewMode = this._viewMode.asReadonly();
    columnMode = this._columnMode.asReadonly();
    anchorDate = this._anchorDate.asReadonly();
    config = this._config.asReadonly();
    containerHeightPx = this._containerHeightPx.asReadonly();
    /**
     * config, aber mit an die verfügbare Höhe angepasster pixelsPerHour, damit das
     * Arbeitszeit-Fenster ohne Scrollen exakt in den Container passt (siehe
     * GridLayoutService.computeEffectivePixelsPerHour).
     */
    effectiveConfig = computed(() => {
        const config = this._config();
        return {
            ...config,
            pixelsPerHour: this.layoutService.computeEffectivePixelsPerHour(config, this._containerHeightPx()),
        };
    }, ...(ngDevMode ? [{ debugName: "effectiveConfig" }] : /* istanbul ignore next */ []));
    /** 1/3/7 Tage ab anchorDate (rollierendes Fenster, kein fixer Wochenstart). */
    visibleDates = computed(() => this.layoutService.computeVisibleRange(this._viewMode(), this._anchorDate()), ...(ngDevMode ? [{ debugName: "visibleDates" }] : /* istanbul ignore next */ []));
    /**
     * Ein Eintrag pro sichtbarem Tag. Im columnMode 'date' hat jeder Tag genau eine Sub-Spalte
     * (der ganze Tag), im columnMode 'resource' eine Sub-Spalte pro Person (Tag×Person-Raster,
     * eine gemeinsame Zeitachse für alle Tage/Personen).
     */
    dayGroups = computed(() => {
        const columnMode = this._columnMode();
        const resources = this._resources();
        const now = this._now();
        return this.visibleDates().map((date) => ({
            date,
            weekNumber: this.layoutService.getIsoWeekNumber(date),
            isToday: this.layoutService.isSameDay(date, now),
            columns: this.buildColumnsForDay(date, columnMode, resources),
        }));
    }, ...(ngDevMode ? [{ debugName: "dayGroups" }] : /* istanbul ignore next */ []));
    /** Alle Sub-Spalten flach (für Lookups, z.B. beim Drag&Drop-Zielspalten-Abgleich). */
    flatColumns = computed(() => this.dayGroups().flatMap((group) => group.columns), ...(ngDevMode ? [{ debugName: "flatColumns" }] : /* istanbul ignore next */ []));
    /** Checklist-Tasks pro sichtbarer Datum-/Ressourcen-Spalte; Task-Daten enthalten keine Uhrzeit. */
    tasksByColumn = computed(() => {
        const tasks = this._tasks();
        const columnMode = this._columnMode();
        const tasksById = new Map(tasks.map((task) => [task.id, task]));
        return new Map(this.dayGroups().flatMap((group) => group.columns.map((column) => [
            column.key,
            tasks.filter((task) => {
                const groupingTask = task.parentId === undefined ? task : (tasksById.get(task.parentId) ?? task);
                return (groupingTask.date === localDateKey(group.date) &&
                    (columnMode !== 'resource' || groupingTask.resourceId === column.resource?.id));
            }),
        ])));
    }, ...(ngDevMode ? [{ debugName: "tasksByColumn" }] : /* istanbul ignore next */ []));
    /** Event-Layout je Sub-Spalte, berechnet über GridLayoutService (keine Business-Logik hier, nur Orchestrierung). */
    layoutByColumn = computed(() => {
        const result = new Map();
        const config = this.effectiveConfig();
        const events = this._events();
        for (const group of this.dayGroups()) {
            for (const column of group.columns) {
                const eventsForColumn = column.resource
                    ? events.filter((event) => event.resourceId === column.resource.id)
                    : events;
                result.set(column.key, this.layoutService.layoutEventsForColumn(eventsForColumn, group.date, config));
            }
        }
        return result;
    }, ...(ngDevMode ? [{ debugName: "layoutByColumn" }] : /* istanbul ignore next */ []));
    /** Aktueller Zeitpunkt fuer die Live-Zeit-Linie; aktualisiert sich nur an vollen Minuten. */
    now = this._now.asReadonly();
    nowOffsetPx = computed(() => this.layoutService.timeToOffset(this.now(), this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "nowOffsetPx" }] : /* istanbul ignore next */ []));
    /** false außerhalb des Arbeitszeit-Fensters: sonst würde die Linie irreführend am Rand kleben. */
    isNowVisible = computed(() => this.layoutService.isWithinWorkingHours(this.now(), this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "isNowVisible" }] : /* istanbul ignore next */ []));
    /** Pixel-Offsets der dezenten Hilfslinien (unabhängig vom Drag&Drop-Snapping-Raster). */
    gridLinesPx = computed(() => this.layoutService.computeGridLines(this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "gridLinesPx" }] : /* istanbul ignore next */ []));
    _dragAnchor = signal(null, ...(ngDevMode ? [{ debugName: "_dragAnchor" }] : /* istanbul ignore next */ []));
    /** Hilfslinie + Spalte, an der die Oberkante des gerade gezogenen Events hängt (Vorschau = Drop-Ergebnis). */
    dragAnchor = this._dragAnchor.asReadonly();
    setDragAnchor(anchor) {
        this._dragAnchor.set(anchor);
    }
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln, als explizite Höhe für Zeitachse/Spalten (entspricht containerHeightPx, kein Scrollen nötig). */
    contentHeightPx = computed(() => this.layoutService.computeContentHeight(this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "contentHeightPx" }] : /* istanbul ignore next */ []));
    constructor() {
        const refresh = () => this._now.set(new Date());
        const delayToNextMinute = 60_000 - (Date.now() % 60_000);
        const initialTimer = setTimeout(() => {
            refresh();
            const intervalTimer = setInterval(refresh, 60_000);
            this.destroyRef.onDestroy(() => clearInterval(intervalTimer));
        }, delayToNextMinute);
        this.destroyRef.onDestroy(() => clearTimeout(initialTimer));
    }
    buildColumnsForDay(date, columnMode, resources) {
        if (columnMode === 'resource') {
            return resources.map((resource) => ({
                key: `${date.toISOString()}__${resource.id}`,
                label: resource.name,
                date,
                resource,
            }));
        }
        return [{ key: date.toISOString(), label: '', date }];
    }
    setEvents(events) {
        this._events.set(events);
    }
    setTasks(tasks) {
        this._tasks.set(tasks);
    }
    setResources(resources) {
        this._resources.set(resources);
    }
    setViewMode(viewMode) {
        this._viewMode.set(viewMode);
    }
    setColumnMode(columnMode) {
        this._columnMode.set(columnMode);
    }
    setAnchorDate(anchorDate) {
        this._anchorDate.set(anchorDate);
    }
    setConfig(config) {
        this._config.set(config);
    }
    setContainerHeightPx(heightPx) {
        this._containerHeightPx.set(heightPx);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridStateService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridStateService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
function localDateKey(date) {
    const pad = (value) => String(value).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

const CSS_VAR_PREFIX = '--glc-';
/** Setzt GridTheme-Werte als CSS Custom Properties auf einem Host-Element. Keine hartkodierten Werte hier. */
class ThemeService {
    apply(theme, hostElement) {
        for (const [key, value] of Object.entries(theme)) {
            if (value === undefined)
                continue;
            hostElement.style.setProperty(this.toCssVarName(key), this.toCssValue(value));
        }
    }
    toCssVarName(key) {
        return CSS_VAR_PREFIX + key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
    }
    toCssValue(value) {
        return typeof value === 'number' ? `${value}px` : value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: ThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: ThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class EventItemComponent {
    layoutService = inject(GridLayoutService);
    state = inject(GridStateService, { optional: true });
    destroyRef = inject(DestroyRef);
    elementRef = inject((ElementRef));
    ngZone = inject(NgZone);
    layout = input.required(...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    columnDate = input.required(...(ngDevMode ? [{ debugName: "columnDate" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    deleted = output();
    eventClicked = output();
    editRequested = output();
    eventUpdated = output();
    resizeTopLine = signal(null, ...(ngDevMode ? [{ debugName: "resizeTopLine" }] : /* istanbul ignore next */ []));
    resizeBottomLine = signal(null, ...(ngDevMode ? [{ debugName: "resizeBottomLine" }] : /* istanbul ignore next */ []));
    dragPreviewSignal = signal(null, ...(ngDevMode ? [{ debugName: "dragPreviewSignal" }] : /* istanbul ignore next */ []));
    gridLines = computed(() => this.layoutService.computeGridLines(this.config()), ...(ngDevMode ? [{ debugName: "gridLines" }] : /* istanbul ignore next */ []));
    resizeActive = null;
    resizeStartY = 0;
    root = viewChild.required('root');
    titleMeasure = viewChild.required('titleMeasure');
    /** Titel passt nicht in die aktuelle Event-Breite: Kurztitel zeigen, Uhrzeit ausblenden. */
    compact = signal(false, ...(ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []));
    displayTitle = computed(() => {
        const { title, shortTitle } = this.layout().event;
        return this.compact() && shortTitle ? shortTitle : title;
    }, ...(ngDevMode ? [{ debugName: "displayTitle" }] : /* istanbul ignore next */ []));
    timeRange = computed(() => {
        const { start, end } = this.layout().event;
        if (!start || !end)
            return '';
        const format = (value) => new Date(value).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
        return `${format(start)} - ${format(end)}`;
    }, ...(ngDevMode ? [{ debugName: "timeRange" }] : /* istanbul ignore next */ []));
    effectiveTopPx = computed(() => this.resizeTopLine()?.offsetPx ?? this.layout().topPx, ...(ngDevMode ? [{ debugName: "effectiveTopPx" }] : /* istanbul ignore next */ []));
    effectiveHeightPx = computed(() => {
        const bottom = this.resizeBottomLine()?.offsetPx ?? this.layout().topPx + this.layout().heightPx;
        return bottom - this.effectiveTopPx();
    }, ...(ngDevMode ? [{ debugName: "effectiveHeightPx" }] : /* istanbul ignore next */ []));
    effectiveTimeRange = computed(() => {
        const preview = this.dragPreviewSignal();
        if (preview?.eventId === this.layout().event.id) {
            const duration = new Date(this.layout().event.end).getTime() - new Date(this.layout().event.start).getTime();
            const end = new Date(preview.start.getTime() + duration);
            return `${formatTime(preview.start)} - ${formatTime(end)}`;
        }
        const topLine = this.resizeTopLine();
        const bottomLine = this.resizeBottomLine();
        if (!topLine || !bottomLine) {
            return this.timeRange();
        }
        const startTime = this.layoutService.timeOnGridLine(topLine, this.columnDate());
        const endTime = this.layoutService.timeOnGridLine(bottomLine, this.columnDate());
        return `${formatTime(startTime)} - ${formatTime(endTime)}`;
    }, ...(ngDevMode ? [{ debugName: "effectiveTimeRange" }] : /* istanbul ignore next */ []));
    onEventClick(event) {
        const target = event.target;
        if (target.closest('.glc-event-item__delete, .glc-event-item__resize-handle'))
            return;
        event.stopPropagation();
        this.eventClicked.emit(this.layout().event);
    }
    onEventDblClick(event) {
        if (event.target.closest('.glc-event-item__delete, .glc-event-item__resize-handle'))
            return;
        event.stopPropagation();
        this.editRequested.emit(this.layout().event.id);
    }
    onEventKeyDown(event) {
        if (event.key !== 'Enter' && event.key !== ' ') {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        if (event.shiftKey) {
            this.editRequested.emit(this.layout().event.id);
            return;
        }
        this.eventClicked.emit(this.layout().event);
    }
    onCdkDragStarted() {
        this.state?.setDragAnchor(null);
        // Scrollen verschiebt die Linien unter der Box, ohne dass die Maus sich bewegt.
        this.elementRef.nativeElement.ownerDocument.addEventListener('scroll', this.onScrollWhileDragging, true);
    }
    onCdkDragEnded() {
        this.elementRef.nativeElement.ownerDocument.removeEventListener('scroll', this.onScrollWhileDragging, true);
        this.ngZone.run(() => this.dragPreviewSignal.set(null));
    }
    /** CDK-Hook: liefert die Position (oben links) der Vorschau-Box – eingerastet auf Hilfslinie + Spalte. */
    snapToGrid = (pointer, _ref, _size, pickup) => {
        const anchor = this.anchorTo(pointer.x, pointer.y - pickup.y);
        if (!anchor) {
            return { x: pointer.x - pickup.x, y: pointer.y - pickup.y };
        }
        return { x: anchor.columnRect.left, y: anchor.columnRect.top + anchor.line.offsetPx };
    };
    onScrollWhileDragging = () => {
        const preview = this.elementRef.nativeElement.ownerDocument.querySelector('.cdk-drag-preview');
        const rect = preview?.getBoundingClientRect();
        if (rect) {
            this.anchorTo(rect.left + rect.width / 2, rect.top);
        }
    };
    constructor() {
        this.destroyRef.onDestroy(() => this.elementRef.nativeElement.ownerDocument.removeEventListener('scroll', this.onScrollWhileDragging, true));
        // Breite ändert sich mit Fenster, Ansicht und Personenzahl; ein geänderter Titel ändert die Messbreite.
        afterNextRender(() => {
            this.updateCompact();
            if (typeof ResizeObserver === 'undefined') {
                return;
            }
            const observer = new ResizeObserver(() => this.updateCompact());
            observer.observe(this.root().nativeElement);
            observer.observe(this.titleMeasure().nativeElement);
            this.destroyRef.onDestroy(() => observer.disconnect());
        });
    }
    updateCompact() {
        const root = this.root().nativeElement;
        // Ohne Layout (Breite 0, z. B. noch nicht sichtbar) nichts entscheiden.
        if (root.clientWidth === 0) {
            this.compact.set(false);
            return;
        }
        const style = getComputedStyle(root);
        const available = root.clientWidth - (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0);
        this.compact.set(this.titleMeasure().nativeElement.offsetWidth > available);
    }
    /** Verankert die Box-Oberkante an der nächsten Hilfslinie der Spalte unter x (Vorschau = Drop-Ergebnis). */
    anchorTo(x, boxTopY) {
        const host = this.elementRef.nativeElement;
        const root = host.closest('glc-grid-calendar') ?? host.ownerDocument;
        const columns = [...root.querySelectorAll('.glc-day-column[data-column-key]')].map((element) => {
            const rect = element.getBoundingClientRect();
            // Events sitzen innerhalb des Spaltenrahmens (+1px wie im Layout): Vorschau genauso platzieren.
            const inner = new DOMRect(rect.left + element.clientLeft + 1, rect.top + element.clientTop, rect.width, rect.height);
            return { key: element.dataset['columnKey'], rect, inner };
        });
        if (!this.state || columns.length === 0) {
            return null;
        }
        const distance = (rect) => (x < rect.left ? rect.left - x : x > rect.right ? x - rect.right : 0);
        const column = columns.reduce((best, candidate) => (distance(candidate.rect) < distance(best.rect) ? candidate : best));
        const line = this.layoutService.nearestGridLine(this.gridLines(), boxTopY - column.inner.top);
        const start = this.layoutService.timeOnGridLine(line, this.columnDate());
        const event = this.layout().event;
        this.ngZone.run(() => {
            this.state?.setDragAnchor({ line, columnKey: column.key });
            this.dragPreviewSignal.set({ eventId: event.id, start });
        });
        const duration = new Date(event.end).getTime() - new Date(event.start).getTime();
        const previewTime = this.elementRef.nativeElement.ownerDocument.querySelector('.cdk-drag-preview .glc-event-item__time');
        if (previewTime) {
            previewTime.textContent = `${formatTime(start)} - ${formatTime(new Date(start.getTime() + duration))}`;
        }
        return { line, columnRect: column.inner };
    }
    onDeleteClick(event) {
        event.stopPropagation();
        this.deleted.emit(this.layout().event);
    }
    onResizeStart(event, edge) {
        event.preventDefault();
        event.stopPropagation();
        this.resizeActive = edge;
        this.resizeStartY = event.clientY;
        const lines = this.gridLines();
        const startTopPx = this.layout().topPx;
        const startBottomPx = startTopPx + this.layout().heightPx;
        this.resizeTopLine.set(this.layoutService.nearestGridLine(lines, startTopPx));
        this.resizeBottomLine.set(this.layoutService.nearestGridLine(lines, startBottomPx));
        const handleMouseMove = (moveEvent) => {
            if (this.resizeActive === null)
                return;
            const deltaY = moveEvent.clientY - this.resizeStartY;
            // Die bewegte Kante rastet auf die nächste Hilfslinie; mindestens eine Linie Abstand zur anderen Kante.
            if (this.resizeActive === 'bottom') {
                const topIndex = lines.indexOf(this.resizeTopLine());
                const index = lines.indexOf(this.layoutService.nearestGridLine(lines, startBottomPx + deltaY));
                this.resizeBottomLine.set(lines[Math.max(index, topIndex + 1)] ?? lines[lines.length - 1]);
            }
            else {
                const bottomIndex = lines.indexOf(this.resizeBottomLine());
                const index = lines.indexOf(this.layoutService.nearestGridLine(lines, startTopPx + deltaY));
                this.resizeTopLine.set(lines[Math.min(index, bottomIndex - 1)] ?? lines[0]);
            }
        };
        const handleMouseUp = () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
            const topLine = this.resizeTopLine();
            const bottomLine = this.resizeBottomLine();
            if (topLine && bottomLine && (topLine.offsetPx !== startTopPx || bottomLine.offsetPx !== startBottomPx)) {
                const updatedEvent = {
                    ...this.layout().event,
                    start: this.layoutService.timeOnGridLine(topLine, this.columnDate()).toISOString(),
                    end: this.layoutService.timeOnGridLine(bottomLine, this.columnDate()).toISOString(),
                };
                this.eventUpdated.emit(updatedEvent);
            }
            this.resizeTopLine.set(null);
            this.resizeBottomLine.set(null);
            this.resizeActive = null;
        };
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
        this.destroyRef.onDestroy(() => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: EventItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: EventItemComponent, isStandalone: true, selector: "glc-event-item", inputs: { layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: true, transformFunction: null }, columnDate: { classPropertyName: "columnDate", publicName: "columnDate", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { deleted: "deleted", eventClicked: "eventClicked", editRequested: "editRequested", eventUpdated: "eventUpdated" }, viewQueries: [{ propertyName: "root", first: true, predicate: ["root"], descendants: true, isSignal: true }, { propertyName: "titleMeasure", first: true, predicate: ["titleMeasure"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div
      #root
      class="glc-event-item"
      cdkDrag
      [cdkDragData]="layout().event"
      [cdkDragConstrainPosition]="snapToGrid"
      (cdkDragStarted)="onCdkDragStarted()"
      (cdkDragEnded)="onCdkDragEnded()"
      [style.top.px]="effectiveTopPx()"
      [style.height.px]="effectiveHeightPx()"
      [style.left]="'calc(' + layout().leftPercent + '% + 1px)'"
      [style.width]="'calc(' + layout().widthPercent + '% - 2px)'"
      [style.background-color]="layout().event.color"
      [class.glc-event-item--draft]="layout().event.isDraft"
      [class.glc-event-item--compact]="compact()"
      [attr.title]="layout().event.title || null"
      role="button"
      tabindex="0"
      [attr.aria-label]="layout().event.title + ', ' + effectiveTimeRange()"
      (click)="onEventClick($event)"
      (dblclick)="onEventDblClick($event)"
      (keydown)="onEventKeyDown($event)"
    >
      <button type="button" class="glc-event-item__delete" (click)="onDeleteClick($event)" aria-label="Löschen">×</button>

      @if (layout().event.imageUrl) {
        <img class="glc-event-item__image" [src]="layout().event.imageUrl" [alt]="layout().event.title" />
      }

      <span #titleMeasure class="glc-event-item__title-measure" aria-hidden="true">{{ layout().event.title }}</span>
      <span class="glc-event-item__title">{{ displayTitle() }}</span>
      @if (!compact()) {
        <span class="glc-event-item__time">{{ effectiveTimeRange() }}</span>
      }

      <div
        class="glc-event-item__resize-handle glc-event-item__resize-handle--top"
        (mousedown)="onResizeStart($event, 'top')"
        title="Zum Vergrößern nach oben ziehen"
      ></div>
      <div
        class="glc-event-item__resize-handle glc-event-item__resize-handle--bottom"
        (mousedown)="onResizeStart($event, 'bottom')"
        title="Zum Vergrößern nach unten ziehen"
      ></div>

    </div>
    <ng-template cdkDragPreview [matchSize]="true">
      <div class="glc-event-item glc-event-item--drag-preview" [style.background-color]="layout().event.color">
        <span class="glc-event-item__title">{{ displayTitle() }}</span>
        @if (!compact()) {
          <span class="glc-event-item__time">{{ effectiveTimeRange() }}</span>
        }
      </div>
    </ng-template>
  `, isInline: true, styles: [".glc-event-item{position:absolute;box-sizing:border-box;overflow:visible;border-radius:var(--glc-event-radius, 4px);background-color:var(--glc-color-event-default, #4a90d9);color:var(--glc-color-on-event, #fff);padding:2px 4px;font-family:var(--glc-font-family, inherit);font-size:.75rem;cursor:grab;-webkit-user-select:none;user-select:none}.glc-event-item:hover{box-shadow:0 2px 8px #0003}.glc-event-item--draft{background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, #fff) 5px,var(--glc-color-draft-secondary, #fff) 10px)}.glc-event-item--drag-preview{pointer-events:none;box-shadow:0 4px 12px #00000040;transition:none!important}.glc-event-item.cdk-drag-placeholder{opacity:0}.glc-event-item__delete{position:absolute;top:2px;right:2px;width:16px;height:16px;line-height:14px;padding:0;border:0;border-radius:50%;background:#00000040;color:inherit;cursor:pointer}.glc-event-item__delete:hover{background:#0006}.glc-event-item__image{display:block;width:100%;height:40%;object-fit:cover}.glc-event-item__title{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__title-measure{position:absolute;top:0;left:0;visibility:hidden;white-space:nowrap;pointer-events:none}.glc-event-item__time{display:block;font-size:.65rem;opacity:.85;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__resize-handle{position:absolute;left:0;right:0;height:4px;cursor:ns-resize;opacity:0;transition:opacity .2s;background:linear-gradient(to right,transparent,rgba(255,255,255,.5),transparent);z-index:10}.glc-event-item__resize-handle--top{top:0;border-radius:4px 4px 0 0}.glc-event-item__resize-handle--bottom{bottom:0;border-radius:0 0 4px 4px}.glc-event-item:hover .glc-event-item__resize-handle{opacity:1}\n"], dependencies: [{ kind: "directive", type: CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: CdkDragPreview, selector: "ng-template[cdkDragPreview]", inputs: ["data", "matchSize"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: EventItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-event-item', standalone: true, imports: [CdkDrag, CdkDragPreview], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div
      #root
      class="glc-event-item"
      cdkDrag
      [cdkDragData]="layout().event"
      [cdkDragConstrainPosition]="snapToGrid"
      (cdkDragStarted)="onCdkDragStarted()"
      (cdkDragEnded)="onCdkDragEnded()"
      [style.top.px]="effectiveTopPx()"
      [style.height.px]="effectiveHeightPx()"
      [style.left]="'calc(' + layout().leftPercent + '% + 1px)'"
      [style.width]="'calc(' + layout().widthPercent + '% - 2px)'"
      [style.background-color]="layout().event.color"
      [class.glc-event-item--draft]="layout().event.isDraft"
      [class.glc-event-item--compact]="compact()"
      [attr.title]="layout().event.title || null"
      role="button"
      tabindex="0"
      [attr.aria-label]="layout().event.title + ', ' + effectiveTimeRange()"
      (click)="onEventClick($event)"
      (dblclick)="onEventDblClick($event)"
      (keydown)="onEventKeyDown($event)"
    >
      <button type="button" class="glc-event-item__delete" (click)="onDeleteClick($event)" aria-label="Löschen">×</button>

      @if (layout().event.imageUrl) {
        <img class="glc-event-item__image" [src]="layout().event.imageUrl" [alt]="layout().event.title" />
      }

      <span #titleMeasure class="glc-event-item__title-measure" aria-hidden="true">{{ layout().event.title }}</span>
      <span class="glc-event-item__title">{{ displayTitle() }}</span>
      @if (!compact()) {
        <span class="glc-event-item__time">{{ effectiveTimeRange() }}</span>
      }

      <div
        class="glc-event-item__resize-handle glc-event-item__resize-handle--top"
        (mousedown)="onResizeStart($event, 'top')"
        title="Zum Vergrößern nach oben ziehen"
      ></div>
      <div
        class="glc-event-item__resize-handle glc-event-item__resize-handle--bottom"
        (mousedown)="onResizeStart($event, 'bottom')"
        title="Zum Vergrößern nach unten ziehen"
      ></div>

    </div>
    <ng-template cdkDragPreview [matchSize]="true">
      <div class="glc-event-item glc-event-item--drag-preview" [style.background-color]="layout().event.color">
        <span class="glc-event-item__title">{{ displayTitle() }}</span>
        @if (!compact()) {
          <span class="glc-event-item__time">{{ effectiveTimeRange() }}</span>
        }
      </div>
    </ng-template>
  `, styles: [".glc-event-item{position:absolute;box-sizing:border-box;overflow:visible;border-radius:var(--glc-event-radius, 4px);background-color:var(--glc-color-event-default, #4a90d9);color:var(--glc-color-on-event, #fff);padding:2px 4px;font-family:var(--glc-font-family, inherit);font-size:.75rem;cursor:grab;-webkit-user-select:none;user-select:none}.glc-event-item:hover{box-shadow:0 2px 8px #0003}.glc-event-item--draft{background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, #fff) 5px,var(--glc-color-draft-secondary, #fff) 10px)}.glc-event-item--drag-preview{pointer-events:none;box-shadow:0 4px 12px #00000040;transition:none!important}.glc-event-item.cdk-drag-placeholder{opacity:0}.glc-event-item__delete{position:absolute;top:2px;right:2px;width:16px;height:16px;line-height:14px;padding:0;border:0;border-radius:50%;background:#00000040;color:inherit;cursor:pointer}.glc-event-item__delete:hover{background:#0006}.glc-event-item__image{display:block;width:100%;height:40%;object-fit:cover}.glc-event-item__title{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__title-measure{position:absolute;top:0;left:0;visibility:hidden;white-space:nowrap;pointer-events:none}.glc-event-item__time{display:block;font-size:.65rem;opacity:.85;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__resize-handle{position:absolute;left:0;right:0;height:4px;cursor:ns-resize;opacity:0;transition:opacity .2s;background:linear-gradient(to right,transparent,rgba(255,255,255,.5),transparent);z-index:10}.glc-event-item__resize-handle--top{top:0;border-radius:4px 4px 0 0}.glc-event-item__resize-handle--bottom{bottom:0;border-radius:0 0 4px 4px}.glc-event-item:hover .glc-event-item__resize-handle{opacity:1}\n"] }]
        }], ctorParameters: () => [], propDecorators: { layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: true }] }], columnDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnDate", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], deleted: [{ type: i0.Output, args: ["deleted"] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], editRequested: [{ type: i0.Output, args: ["editRequested"] }], eventUpdated: [{ type: i0.Output, args: ["eventUpdated"] }], root: [{ type: i0.ViewChild, args: ['root', { isSignal: true }] }], titleMeasure: [{ type: i0.ViewChild, args: ['titleMeasure', { isSignal: true }] }] } });
function formatTime(value) {
    return value.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
}

class DayColumnComponent {
    layoutService = inject(GridLayoutService);
    destroyRef = inject(DestroyRef);
    columnKey = input.required(...(ngDevMode ? [{ debugName: "columnKey" }] : /* istanbul ignore next */ []));
    layouts = input.required(...(ngDevMode ? [{ debugName: "layouts" }] : /* istanbul ignore next */ []));
    columnDate = input.required(...(ngDevMode ? [{ debugName: "columnDate" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    borderColor = input(undefined, ...(ngDevMode ? [{ debugName: "borderColor" }] : /* istanbul ignore next */ []));
    resourceId = input(undefined, ...(ngDevMode ? [{ debugName: "resourceId" }] : /* istanbul ignore next */ []));
    gridLinesPx = input([], ...(ngDevMode ? [{ debugName: "gridLinesPx" }] : /* istanbul ignore next */ []));
    dropped = output();
    eventClicked = output();
    eventEditRequested = output();
    eventDeleted = output();
    eventUpdated = output();
    eventDrawn = output();
    gridLines = computed(() => this.layoutService.computeGridLines(this.config()), ...(ngDevMode ? [{ debugName: "gridLines" }] : /* istanbul ignore next */ []));
    drawStartLine = signal(null, ...(ngDevMode ? [{ debugName: "drawStartLine" }] : /* istanbul ignore next */ []));
    drawEndLine = signal(null, ...(ngDevMode ? [{ debugName: "drawEndLine" }] : /* istanbul ignore next */ []));
    /** Gezeichneter Bereich von Hilfslinie zu Hilfslinie, mindestens eine Linie hoch. */
    drawRange = computed(() => {
        const a = this.drawStartLine();
        const b = this.drawEndLine();
        if (!a || !b) {
            return null;
        }
        const lines = this.gridLines();
        let from = Math.min(lines.indexOf(a), lines.indexOf(b));
        let to = Math.max(lines.indexOf(a), lines.indexOf(b));
        if (from === to) {
            to = Math.min(to + 1, lines.length - 1);
            from = Math.min(from, to - 1);
        }
        return [lines[from], lines[to]];
    }, ...(ngDevMode ? [{ debugName: "drawRange" }] : /* istanbul ignore next */ []));
    drawingLayout = computed(() => {
        const range = this.drawRange();
        return range ? { topPx: range[0].offsetPx, heightPx: range[1].offsetPx - range[0].offsetPx } : null;
    }, ...(ngDevMode ? [{ debugName: "drawingLayout" }] : /* istanbul ignore next */ []));
    /** Hilfsuhr: Hilfslinie unter der Maus, nur über leerem Raster und ohne gedrückte Maustaste. */
    hoverLine = signal(null, ...(ngDevMode ? [{ debugName: "hoverLine" }] : /* istanbul ignore next */ []));
    hoverLabel = computed(() => {
        const line = this.hoverLine();
        return line ? `${String(line.hours).padStart(2, '0')}:${String(line.minutes).padStart(2, '0')}` : '';
    }, ...(ngDevMode ? [{ debugName: "hoverLabel" }] : /* istanbul ignore next */ []));
    onMouseMove(event) {
        // buttons !== 0: Zeichnen, Verschieben oder Resize läuft gerade.
        if (event.buttons !== 0 || event.target.closest('.glc-event-item')) {
            this.hoverLine.set(null);
            return;
        }
        this.hoverLine.set(this.lineAt(event.currentTarget, event.clientY));
    }
    /** Hilfslinie an einer Bildschirm-Y-Position (Linien beginnen an der Innenkante der Spalte). */
    lineAt(column, clientY) {
        const top = column.getBoundingClientRect().top + column.clientTop;
        return this.layoutService.nearestGridLine(this.gridLines(), clientY - top);
    }
    onDropped(event) {
        this.dropped.emit(event);
    }
    onDrawStart(event) {
        this.hoverLine.set(null);
        if (event.button !== 0 || event.target.closest('.glc-event-item')) {
            return;
        }
        event.preventDefault();
        const element = event.currentTarget;
        const lineAt = (clientY) => this.lineAt(element, clientY);
        const startLine = lineAt(event.clientY);
        this.drawStartLine.set(startLine);
        this.drawEndLine.set(startLine);
        const onMove = (moveEvent) => this.drawEndLine.set(lineAt(moveEvent.clientY));
        const stop = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            document.removeEventListener('keydown', onKeyDown);
            this.drawStartLine.set(null);
            this.drawEndLine.set(null);
        };
        const onUp = () => {
            const range = this.drawRange();
            if (range) {
                const startTime = this.layoutService.timeOnGridLine(range[0], this.columnDate());
                const endTime = this.layoutService.timeOnGridLine(range[1], this.columnDate());
                this.eventDrawn.emit({ start: startTime.toISOString(), end: endTime.toISOString(), resourceId: this.resourceId() });
            }
            stop();
        };
        const onKeyDown = (keyEvent) => {
            if (keyEvent.key === 'Escape') {
                stop();
            }
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        document.addEventListener('keydown', onKeyDown);
        this.destroyRef.onDestroy(stop);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: DayColumnComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: DayColumnComponent, isStandalone: true, selector: "glc-day-column", inputs: { columnKey: { classPropertyName: "columnKey", publicName: "columnKey", isSignal: true, isRequired: true, transformFunction: null }, layouts: { classPropertyName: "layouts", publicName: "layouts", isSignal: true, isRequired: true, transformFunction: null }, columnDate: { classPropertyName: "columnDate", publicName: "columnDate", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, borderColor: { classPropertyName: "borderColor", publicName: "borderColor", isSignal: true, isRequired: false, transformFunction: null }, resourceId: { classPropertyName: "resourceId", publicName: "resourceId", isSignal: true, isRequired: false, transformFunction: null }, gridLinesPx: { classPropertyName: "gridLinesPx", publicName: "gridLinesPx", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dropped: "dropped", eventClicked: "eventClicked", eventEditRequested: "eventEditRequested", eventDeleted: "eventDeleted", eventUpdated: "eventUpdated", eventDrawn: "eventDrawn" }, ngImport: i0, template: `
    <div
      class="glc-day-column"
      cdkDropList
      cdkDropListSortingDisabled
      [attr.data-column-key]="columnKey()"
      [cdkDropListData]="columnKey()"
      (cdkDropListDropped)="onDropped($event)"
      (mousedown)="onDrawStart($event)"
      (mousemove)="onMouseMove($event)"
      (mouseleave)="hoverLine.set(null)"
      [style.border-left]="borderColor() ? '3px solid ' + borderColor() : null"
      [style.border-right]="borderColor() ? '3px solid ' + borderColor() : null"
      [style.border-bottom]="borderColor() ? '3px solid ' + borderColor() : null"
      [style.border-radius]="borderColor() ? '0 0 8px 8px' : null"
    >
      @for (line of gridLinesPx(); track line.offsetPx) {
        <div
          class="glc-day-column__gridline"
          [class.glc-day-column__gridline--hour]="line.isHour"
          [style.top.px]="line.offsetPx"
        ></div>
      }
      @for (layout of layouts(); track layout.event.id) {
        <glc-event-item
          [layout]="layout"
          [columnDate]="columnDate()"
          [config]="config()"
          (eventClicked)="eventClicked.emit($event)"
          (editRequested)="eventEditRequested.emit($event)"
          (deleted)="eventDeleted.emit($event)"
          (eventUpdated)="eventUpdated.emit($event)"
        />
      }
      @if (drawingLayout(); as layout) {
        <div
          class="glc-day-column__draft"
          [style.top.px]="layout.topPx"
          [style.height.px]="layout.heightPx"
        ></div>
      }
      @if (hoverLine(); as line) {
        <div class="glc-day-column__hover-line" [style.top.px]="line.offsetPx">
          <span class="glc-day-column__hover-time">{{ hoverLabel() }}</span>
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;flex:1 1 0;min-width:0;height:100%;border-radius:8px}.glc-day-column{position:relative;box-sizing:border-box;width:100%;height:100%}.glc-day-column__gridline{position:absolute;left:0;right:0;border-top:1px solid transparent;pointer-events:none}.glc-day-column__gridline--hour{border-top:1px solid var(--glc-color-border, #ccc)}.glc-day-column__hover-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-primary, #333);pointer-events:none}.glc-day-column__hover-time{position:absolute;left:0;bottom:2px;display:inline-block;white-space:nowrap;padding:.05rem .35rem;border-radius:4px;background:var(--glc-color-hover-bg, #000);color:var(--glc-color-hover-text, #fff);font-size:.65rem;font-weight:600;pointer-events:none}.glc-day-column__draft{position:absolute;left:1px;right:1px;box-sizing:border-box;border:1px solid var(--glc-color-draft-border, #1c7ed6);border-radius:var(--glc-event-radius, 4px);background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, #fff) 5px,var(--glc-color-draft-secondary, #fff) 10px);pointer-events:none}\n"], dependencies: [{ kind: "directive", type: CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "component", type: EventItemComponent, selector: "glc-event-item", inputs: ["layout", "columnDate", "config"], outputs: ["deleted", "eventClicked", "editRequested", "eventUpdated"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: DayColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-day-column', standalone: true, imports: [CdkDropList, EventItemComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div
      class="glc-day-column"
      cdkDropList
      cdkDropListSortingDisabled
      [attr.data-column-key]="columnKey()"
      [cdkDropListData]="columnKey()"
      (cdkDropListDropped)="onDropped($event)"
      (mousedown)="onDrawStart($event)"
      (mousemove)="onMouseMove($event)"
      (mouseleave)="hoverLine.set(null)"
      [style.border-left]="borderColor() ? '3px solid ' + borderColor() : null"
      [style.border-right]="borderColor() ? '3px solid ' + borderColor() : null"
      [style.border-bottom]="borderColor() ? '3px solid ' + borderColor() : null"
      [style.border-radius]="borderColor() ? '0 0 8px 8px' : null"
    >
      @for (line of gridLinesPx(); track line.offsetPx) {
        <div
          class="glc-day-column__gridline"
          [class.glc-day-column__gridline--hour]="line.isHour"
          [style.top.px]="line.offsetPx"
        ></div>
      }
      @for (layout of layouts(); track layout.event.id) {
        <glc-event-item
          [layout]="layout"
          [columnDate]="columnDate()"
          [config]="config()"
          (eventClicked)="eventClicked.emit($event)"
          (editRequested)="eventEditRequested.emit($event)"
          (deleted)="eventDeleted.emit($event)"
          (eventUpdated)="eventUpdated.emit($event)"
        />
      }
      @if (drawingLayout(); as layout) {
        <div
          class="glc-day-column__draft"
          [style.top.px]="layout.topPx"
          [style.height.px]="layout.heightPx"
        ></div>
      }
      @if (hoverLine(); as line) {
        <div class="glc-day-column__hover-line" [style.top.px]="line.offsetPx">
          <span class="glc-day-column__hover-time">{{ hoverLabel() }}</span>
        </div>
      }
    </div>
  `, styles: [":host{display:block;flex:1 1 0;min-width:0;height:100%;border-radius:8px}.glc-day-column{position:relative;box-sizing:border-box;width:100%;height:100%}.glc-day-column__gridline{position:absolute;left:0;right:0;border-top:1px solid transparent;pointer-events:none}.glc-day-column__gridline--hour{border-top:1px solid var(--glc-color-border, #ccc)}.glc-day-column__hover-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-primary, #333);pointer-events:none}.glc-day-column__hover-time{position:absolute;left:0;bottom:2px;display:inline-block;white-space:nowrap;padding:.05rem .35rem;border-radius:4px;background:var(--glc-color-hover-bg, #000);color:var(--glc-color-hover-text, #fff);font-size:.65rem;font-weight:600;pointer-events:none}.glc-day-column__draft{position:absolute;left:1px;right:1px;box-sizing:border-box;border:1px solid var(--glc-color-draft-border, #1c7ed6);border-radius:var(--glc-event-radius, 4px);background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, #fff) 5px,var(--glc-color-draft-secondary, #fff) 10px);pointer-events:none}\n"] }]
        }], propDecorators: { columnKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnKey", required: true }] }], layouts: [{ type: i0.Input, args: [{ isSignal: true, alias: "layouts", required: true }] }], columnDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnDate", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], borderColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "borderColor", required: false }] }], resourceId: [{ type: i0.Input, args: [{ isSignal: true, alias: "resourceId", required: false }] }], gridLinesPx: [{ type: i0.Input, args: [{ isSignal: true, alias: "gridLinesPx", required: false }] }], dropped: [{ type: i0.Output, args: ["dropped"] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], eventEditRequested: [{ type: i0.Output, args: ["eventEditRequested"] }], eventDeleted: [{ type: i0.Output, args: ["eventDeleted"] }], eventUpdated: [{ type: i0.Output, args: ["eventUpdated"] }], eventDrawn: [{ type: i0.Output, args: ["eventDrawn"] }] } });

class GridHeaderComponent {
    dayGroups = input.required(...(ngDevMode ? [{ debugName: "dayGroups" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: GridHeaderComponent, isStandalone: true, selector: "glc-grid-header", inputs: { dayGroups: { classPropertyName: "dayGroups", publicName: "dayGroups", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <div class="glc-grid-header">
      @for (group of dayGroups(); track group.date.toISOString()) {
        <div class="glc-grid-header__day" [style.flex-grow]="group.columns.length">
          <div class="glc-grid-header__day-row">
            <span class="glc-grid-header__day-label">
              <span class="glc-grid-header__day-label-date">{{ group.date | date: 'EEEE dd.MM.' }}</span>
              <span class="glc-grid-header__day-label-week">KW {{ group.weekNumber }}</span>
            </span>
            @if (group.isToday) {
              <span class="glc-grid-header__today-badge">HEUTE</span>
            }
          </div>
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;flex:1 1 auto;min-width:0}.glc-grid-header{display:flex;width:100%;gap:var(--glc-columns-gap, 8px)}.glc-grid-header__day{flex:1 1 0;min-width:0;display:flex;flex-direction:column;font-family:var(--glc-font-family, inherit)}.glc-grid-header__day-row{display:flex;align-items:center;gap:.5rem;padding:var(--glc-header-padding, .5rem);flex-wrap:nowrap}.glc-grid-header__day-label{display:flex;flex-direction:column;line-height:1.25;min-width:0;flex:1 1 auto;text-align:left}.glc-grid-header__day-label-date{font-weight:600;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__day-label-week{font-weight:400;font-size:.75rem;opacity:.7;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__today-badge{flex-shrink:0;background:var(--glc-color-primary, #d9364f);color:#fff;font-size:.7rem;padding:.1rem .4rem;border-radius:1rem}\n"], dependencies: [{ kind: "pipe", type: DatePipe, name: "date" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-grid-header', standalone: true, imports: [DatePipe], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="glc-grid-header">
      @for (group of dayGroups(); track group.date.toISOString()) {
        <div class="glc-grid-header__day" [style.flex-grow]="group.columns.length">
          <div class="glc-grid-header__day-row">
            <span class="glc-grid-header__day-label">
              <span class="glc-grid-header__day-label-date">{{ group.date | date: 'EEEE dd.MM.' }}</span>
              <span class="glc-grid-header__day-label-week">KW {{ group.weekNumber }}</span>
            </span>
            @if (group.isToday) {
              <span class="glc-grid-header__today-badge">HEUTE</span>
            }
          </div>
        </div>
      }
    </div>
  `, styles: [":host{display:block;flex:1 1 auto;min-width:0}.glc-grid-header{display:flex;width:100%;gap:var(--glc-columns-gap, 8px)}.glc-grid-header__day{flex:1 1 0;min-width:0;display:flex;flex-direction:column;font-family:var(--glc-font-family, inherit)}.glc-grid-header__day-row{display:flex;align-items:center;gap:.5rem;padding:var(--glc-header-padding, .5rem);flex-wrap:nowrap}.glc-grid-header__day-label{display:flex;flex-direction:column;line-height:1.25;min-width:0;flex:1 1 auto;text-align:left}.glc-grid-header__day-label-date{font-weight:600;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__day-label-week{font-weight:400;font-size:.75rem;opacity:.7;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__today-badge{flex-shrink:0;background:var(--glc-color-primary, #d9364f);color:#fff;font-size:.7rem;padding:.1rem .4rem;border-radius:1rem}\n"] }]
        }], propDecorators: { dayGroups: [{ type: i0.Input, args: [{ isSignal: true, alias: "dayGroups", required: true }] }] } });

class TimeAxisComponent {
    layoutService = inject(GridLayoutService);
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** Eine Markierung pro voller Stunde im Arbeitszeit-Fenster, Position via GridLayoutService. */
    hourMarks = computed(() => {
        const config = this.config();
        return this.layoutService
            .computeGridLines({ ...config, gridLineIntervalMinutes: 60 })
            .filter((line) => line.isHour)
            .map((line) => ({
            label: `${line.hours.toString().padStart(2, '0')}:${line.minutes.toString().padStart(2, '0')}`,
            topPx: line.offsetPx,
        }));
    }, ...(ngDevMode ? [{ debugName: "hourMarks" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TimeAxisComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: TimeAxisComponent, isStandalone: true, selector: "glc-time-axis", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <div class="glc-time-axis">
      @for (mark of hourMarks(); track mark.label) {
        <div class="glc-time-axis__mark" [style.top.px]="mark.topPx">{{ mark.label }}</div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;flex:0 0 auto;width:var(--glc-time-axis-width, 3.5rem)}.glc-time-axis{position:relative;width:100%;height:100%;font-family:var(--glc-font-family, inherit);color:var(--glc-color-border, #666)}.glc-time-axis__mark{position:absolute;left:0;right:0;box-sizing:border-box;transform:translateY(-50%);font-size:.75rem;font-weight:700;color:var(--glc-color-hour-line, #222);text-align:right;padding-right:.35rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TimeAxisComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-time-axis', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="glc-time-axis">
      @for (mark of hourMarks(); track mark.label) {
        <div class="glc-time-axis__mark" [style.top.px]="mark.topPx">{{ mark.label }}</div>
      }
    </div>
  `, styles: [":host{display:block;flex:0 0 auto;width:var(--glc-time-axis-width, 3.5rem)}.glc-time-axis{position:relative;width:100%;height:100%;font-family:var(--glc-font-family, inherit);color:var(--glc-color-border, #666)}.glc-time-axis__mark{position:absolute;left:0;right:0;box-sizing:border-box;transform:translateY(-50%);font-size:.75rem;font-weight:700;color:var(--glc-color-hour-line, #222);text-align:right;padding-right:.35rem}\n"] }]
        }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }] } });

class TaskListColumnComponent {
    tasks = input([], ...(ngDevMode ? [{ debugName: "tasks" }] : /* istanbul ignore next */ []));
    resources = input([], ...(ngDevMode ? [{ debugName: "resources" }] : /* istanbul ignore next */ []));
    showCompleted = input(false, ...(ngDevMode ? [{ debugName: "showCompleted" }] : /* istanbul ignore next */ []));
    tasksChange = output();
    commentsRequested = output();
    expandedIds = signal(new Set(), ...(ngDevMode ? [{ debugName: "expandedIds" }] : /* istanbul ignore next */ []));
    rows = computed(() => {
        const tasks = this.tasks();
        const resourceColors = new Map(this.resources().map((resource) => [resource.id, resource.color]));
        const childrenByParent = new Map();
        for (const task of tasks) {
            if (task.parentId === undefined)
                continue;
            const children = childrenByParent.get(task.parentId) ?? [];
            children.push(task);
            childrenByParent.set(task.parentId, children);
        }
        return tasks
            .filter((task) => task.parentId === undefined)
            .map((task) => {
            const children = childrenByParent.get(task.id) ?? [];
            const completed = children.length > 0 ? children.every((child) => child.completed) : task.completed;
            const view = {
                ...this.taskItem(task, completed, resourceColors),
                expandLabel: `${task.name}, ${children.length} Untertasks ${this.expandedIds().has(task.id) ? 'einklappen' : 'ausklappen'}`,
                hasChildren: children.length > 0,
                expanded: this.expandedIds().has(task.id),
                children: children
                    .filter(() => this.showCompleted() || !completed)
                    .map((child) => this.taskItem(child, child.completed, resourceColors)),
            };
            return view;
        })
            .filter((row) => this.showCompleted() || !row.completed);
    }, ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    taskItem(task, completed, resourceColors) {
        const commentsCount = task.comments?.length ?? 0;
        const resourceColor = resourceColors.get(task.resourceId);
        return {
            task,
            completed,
            commentsCount,
            commentsLabel: commentsCount ? `Notizen anzeigen (${commentsCount})` : 'Notiz hinzufuegen',
            resourceColor,
        };
    }
    toggleExpanded(id) {
        this.expandedIds.update((expanded) => {
            const next = new Set(expanded);
            if (next.has(id))
                next.delete(id);
            else
                next.add(id);
            return next;
        });
    }
    toggleCompleted(id, completed) {
        const tasks = this.tasks();
        const target = tasks.find((task) => task.id === id);
        if (!target)
            return;
        const children = tasks.filter((task) => task.parentId === id);
        if (children.length)
            return;
        const updated = tasks.map((task) => (task.id === id ? { ...task, completed } : task));
        if (target.parentId !== undefined) {
            const parentChildren = updated.filter((task) => task.parentId === target.parentId);
            const parentCompleted = parentChildren.every((child) => child.completed);
            this.tasksChange.emit(updated.map((task) => (task.id === target.parentId ? { ...task, completed: parentCompleted } : task)));
            return;
        }
        this.tasksChange.emit(updated);
    }
    onCheckboxChange(id, event) {
        this.toggleCompleted(id, event.target.checked);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TaskListColumnComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: TaskListColumnComponent, isStandalone: true, selector: "glc-task-list-column", inputs: { tasks: { classPropertyName: "tasks", publicName: "tasks", isSignal: true, isRequired: false, transformFunction: null }, resources: { classPropertyName: "resources", publicName: "resources", isSignal: true, isRequired: false, transformFunction: null }, showCompleted: { classPropertyName: "showCompleted", publicName: "showCompleted", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { tasksChange: "tasksChange", commentsRequested: "commentsRequested" }, ngImport: i0, template: `
    <section class="glc-task-list-column" aria-label="Tasks für diese Person und diesen Tag">
      @for (row of rows(); track row.task.id) {
        <div
          class="glc-task-list-column__group"
          [style.--glc-task-color]="row.resourceColor"
        >
          <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="row.commentsLabel" (click)="commentsRequested.emit(row.task.id)">{{ row.commentsCount }}</button>
          <article
            class="glc-task-list-column__card"
            [class.glc-task-list-column__card--completed]="row.completed"
          >
            @if (row.hasChildren) {
              <span
                class="glc-task-list-column__name glc-task-list-column__name--expandable"
                role="button"
                tabindex="0"
                [attr.aria-label]="row.expandLabel"
                [attr.aria-expanded]="row.expanded"
                (click)="toggleExpanded(row.task.id)"
                (keydown.enter)="toggleExpanded(row.task.id)"
                (keydown.space)="toggleExpanded(row.task.id); $event.preventDefault()"
              >{{ row.task.name }}</span>
            } @else {
              <span class="glc-task-list-column__name">{{ row.task.name }}</span>
            }
            <input
              type="checkbox"
              [checked]="row.completed"
              [disabled]="row.hasChildren"
              [attr.aria-label]="row.task.name"
              (change)="onCheckboxChange(row.task.id, $event)"
            />
          </article>
          @if (row.expanded) {
            <div class="glc-task-list-column__children">
              @for (child of row.children; track child.task.id) {
                <article
                  class="glc-task-list-column__card glc-task-list-column__card--child"
                  [class.glc-task-list-column__card--completed]="child.completed"
                  [style.--glc-task-color]="child.resourceColor"
                >
                  <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="child.commentsLabel" (click)="commentsRequested.emit(child.task.id)">{{ child.commentsCount }}</button>
                  <span class="glc-task-list-column__name">{{ child.task.name }}</span>
                  <input
                    type="checkbox"
                    [checked]="child.completed"
                    [attr.aria-label]="child.task.name"
                    (change)="onCheckboxChange(child.task.id, $event)"
                  />
                </article>
              }
            </div>
          }
        </div>
      } @empty {
      }
    </section>
  `, isInline: true, styles: ["@charset \"UTF-8\";:host{display:block;box-sizing:border-box;flex:1 1 0;min-width:0;overflow:visible;container-type:inline-size}.glc-task-list-column{display:flex;flex-direction:column;gap:.35rem;box-sizing:border-box;min-width:0;overflow:visible;padding:0 .55rem 0 1px}.glc-task-list-column__group{position:relative;min-width:0;overflow:visible;border:1px solid var(--glc-color-border, #ccc);border-left:3px solid var(--glc-task-color, var(--glc-color-task-default, #495057));border-radius:var(--glc-task-radius, 4px);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 18%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card{position:relative;display:flex;align-items:center;gap:.3rem;min-width:0;min-height:28px;padding:.25rem .2rem .25rem .4rem;line-height:1.35;font-family:var(--glc-font-family, inherit);font-size:.75rem}.glc-task-list-column__card--child{min-height:26px;padding-left:.65rem;border-top:1px solid color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 30%,transparent);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 10%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card--completed .glc-task-list-column__name{text-decoration:line-through;opacity:.75}.glc-task-list-column__children{box-sizing:border-box;padding-left:.5rem;border-left:1px solid var(--glc-color-border, #ccc)}.glc-task-list-column__name{flex:1 1 auto;min-width:0;border:0;padding:0;background:transparent;color:inherit;font:inherit;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:left}.glc-task-list-column__name--expandable{cursor:pointer;text-decoration:underline dotted;text-underline-offset:2px}.glc-task-list-column__note-action{position:absolute;top:-.0625rem;right:-.5625rem;z-index:1;display:grid;box-sizing:border-box;place-items:center;width:1rem;height:1rem;padding:0;transform:translateY(-50%);cursor:pointer}.glc-task-list-column__comment-count{border:1px solid var(--glc-task-color, var(--glc-color-task-count, #d9364f));border-radius:50%;background:var(--glc-color-task-count-background, #fff);color:var(--glc-task-color, var(--glc-color-task-count, #d9364f));font-family:var(--glc-font-family, inherit);font-size:.65rem;font-weight:600;line-height:1}.glc-task-list-column__comment-count:hover{background:var(--glc-color-task-count-background, #fff)}.glc-task-list-column input[type=checkbox]{display:inline-grid;flex:0 0 1rem;width:1rem;height:1rem;place-items:center;margin:0 0 0 .25rem;appearance:none;border:1px solid var(--glc-task-color, var(--glc-color-border, #ccc));border-radius:50%;background:var(--glc-color-background, #fff);cursor:pointer}.glc-task-list-column input[type=checkbox]:after{content:\"\\2713\";color:var(--glc-task-color, var(--glc-color-success, #2f9e44));font-size:.75rem;font-weight:700;line-height:1;transform:scale(0)}.glc-task-list-column input[type=checkbox]:checked{border-color:var(--glc-task-color, var(--glc-color-success, #2f9e44))}.glc-task-list-column input[type=checkbox]:checked:after{transform:scale(1)}.glc-task-list-column input[type=checkbox]:disabled{cursor:default}.glc-task-list-column input[type=checkbox]:focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px}.glc-task-list-column :focus:not(:focus-visible){outline:none}.glc-task-list-column :focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px;border-radius:2px}@container (max-width: 72px){.glc-task-list-column__children{padding-left:.25rem}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TaskListColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-task-list-column', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <section class="glc-task-list-column" aria-label="Tasks für diese Person und diesen Tag">
      @for (row of rows(); track row.task.id) {
        <div
          class="glc-task-list-column__group"
          [style.--glc-task-color]="row.resourceColor"
        >
          <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="row.commentsLabel" (click)="commentsRequested.emit(row.task.id)">{{ row.commentsCount }}</button>
          <article
            class="glc-task-list-column__card"
            [class.glc-task-list-column__card--completed]="row.completed"
          >
            @if (row.hasChildren) {
              <span
                class="glc-task-list-column__name glc-task-list-column__name--expandable"
                role="button"
                tabindex="0"
                [attr.aria-label]="row.expandLabel"
                [attr.aria-expanded]="row.expanded"
                (click)="toggleExpanded(row.task.id)"
                (keydown.enter)="toggleExpanded(row.task.id)"
                (keydown.space)="toggleExpanded(row.task.id); $event.preventDefault()"
              >{{ row.task.name }}</span>
            } @else {
              <span class="glc-task-list-column__name">{{ row.task.name }}</span>
            }
            <input
              type="checkbox"
              [checked]="row.completed"
              [disabled]="row.hasChildren"
              [attr.aria-label]="row.task.name"
              (change)="onCheckboxChange(row.task.id, $event)"
            />
          </article>
          @if (row.expanded) {
            <div class="glc-task-list-column__children">
              @for (child of row.children; track child.task.id) {
                <article
                  class="glc-task-list-column__card glc-task-list-column__card--child"
                  [class.glc-task-list-column__card--completed]="child.completed"
                  [style.--glc-task-color]="child.resourceColor"
                >
                  <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="child.commentsLabel" (click)="commentsRequested.emit(child.task.id)">{{ child.commentsCount }}</button>
                  <span class="glc-task-list-column__name">{{ child.task.name }}</span>
                  <input
                    type="checkbox"
                    [checked]="child.completed"
                    [attr.aria-label]="child.task.name"
                    (change)="onCheckboxChange(child.task.id, $event)"
                  />
                </article>
              }
            </div>
          }
        </div>
      } @empty {
      }
    </section>
  `, styles: ["@charset \"UTF-8\";:host{display:block;box-sizing:border-box;flex:1 1 0;min-width:0;overflow:visible;container-type:inline-size}.glc-task-list-column{display:flex;flex-direction:column;gap:.35rem;box-sizing:border-box;min-width:0;overflow:visible;padding:0 .55rem 0 1px}.glc-task-list-column__group{position:relative;min-width:0;overflow:visible;border:1px solid var(--glc-color-border, #ccc);border-left:3px solid var(--glc-task-color, var(--glc-color-task-default, #495057));border-radius:var(--glc-task-radius, 4px);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 18%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card{position:relative;display:flex;align-items:center;gap:.3rem;min-width:0;min-height:28px;padding:.25rem .2rem .25rem .4rem;line-height:1.35;font-family:var(--glc-font-family, inherit);font-size:.75rem}.glc-task-list-column__card--child{min-height:26px;padding-left:.65rem;border-top:1px solid color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 30%,transparent);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 10%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card--completed .glc-task-list-column__name{text-decoration:line-through;opacity:.75}.glc-task-list-column__children{box-sizing:border-box;padding-left:.5rem;border-left:1px solid var(--glc-color-border, #ccc)}.glc-task-list-column__name{flex:1 1 auto;min-width:0;border:0;padding:0;background:transparent;color:inherit;font:inherit;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:left}.glc-task-list-column__name--expandable{cursor:pointer;text-decoration:underline dotted;text-underline-offset:2px}.glc-task-list-column__note-action{position:absolute;top:-.0625rem;right:-.5625rem;z-index:1;display:grid;box-sizing:border-box;place-items:center;width:1rem;height:1rem;padding:0;transform:translateY(-50%);cursor:pointer}.glc-task-list-column__comment-count{border:1px solid var(--glc-task-color, var(--glc-color-task-count, #d9364f));border-radius:50%;background:var(--glc-color-task-count-background, #fff);color:var(--glc-task-color, var(--glc-color-task-count, #d9364f));font-family:var(--glc-font-family, inherit);font-size:.65rem;font-weight:600;line-height:1}.glc-task-list-column__comment-count:hover{background:var(--glc-color-task-count-background, #fff)}.glc-task-list-column input[type=checkbox]{display:inline-grid;flex:0 0 1rem;width:1rem;height:1rem;place-items:center;margin:0 0 0 .25rem;appearance:none;border:1px solid var(--glc-task-color, var(--glc-color-border, #ccc));border-radius:50%;background:var(--glc-color-background, #fff);cursor:pointer}.glc-task-list-column input[type=checkbox]:after{content:\"\\2713\";color:var(--glc-task-color, var(--glc-color-success, #2f9e44));font-size:.75rem;font-weight:700;line-height:1;transform:scale(0)}.glc-task-list-column input[type=checkbox]:checked{border-color:var(--glc-task-color, var(--glc-color-success, #2f9e44))}.glc-task-list-column input[type=checkbox]:checked:after{transform:scale(1)}.glc-task-list-column input[type=checkbox]:disabled{cursor:default}.glc-task-list-column input[type=checkbox]:focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px}.glc-task-list-column :focus:not(:focus-visible){outline:none}.glc-task-list-column :focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px;border-radius:2px}@container (max-width: 72px){.glc-task-list-column__children{padding-left:.25rem}}\n"] }]
        }], propDecorators: { tasks: [{ type: i0.Input, args: [{ isSignal: true, alias: "tasks", required: false }] }], resources: [{ type: i0.Input, args: [{ isSignal: true, alias: "resources", required: false }] }], showCompleted: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCompleted", required: false }] }], tasksChange: [{ type: i0.Output, args: ["tasksChange"] }], commentsRequested: [{ type: i0.Output, args: ["commentsRequested"] }] } });

const DEFAULT_CONFIG = {
    workingHoursStart: 8,
    workingHoursEnd: 18,
    pixelsPerHour: 60,
};
const TASK_ROOT_ROW_HEIGHT_PX = 38;
const TASK_CHILD_ROW_HEIGHT_PX = 35;
const TASK_GROUP_GAP_PX = 6;
const TASK_MODE_TOP_INSET_PX = 8;
const TASK_RESOURCE_FRAME_BOTTOM_PX = 3;
/** Öffentlicher Library-Einstiegspunkt mit Event-Raster und datumsgelagerter Task-Zeile. */
class GridCalendar {
    hostElement = inject((ElementRef));
    themeService = inject(ThemeService);
    destroyRef = inject(DestroyRef);
    layoutService = inject(GridLayoutService);
    state = inject(GridStateService);
    bodyEl = viewChild('bodyEl', ...(ngDevMode ? [{ debugName: "bodyEl" }] : /* istanbul ignore next */ []));
    event = input(undefined, ...(ngDevMode ? [{ debugName: "event" }] : /* istanbul ignore next */ []));
    events = input([], ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    tasks = input([], ...(ngDevMode ? [{ debugName: "tasks" }] : /* istanbul ignore next */ []));
    showCompletedTasks = input(false, ...(ngDevMode ? [{ debugName: "showCompletedTasks" }] : /* istanbul ignore next */ []));
    contentMode = input('both', ...(ngDevMode ? [{ debugName: "contentMode" }] : /* istanbul ignore next */ []));
    resource = input(undefined, ...(ngDevMode ? [{ debugName: "resource" }] : /* istanbul ignore next */ []));
    resources = input([], ...(ngDevMode ? [{ debugName: "resources" }] : /* istanbul ignore next */ []));
    data = input({}, ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    viewMode = input('week', ...(ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []));
    columnMode = input('date', ...(ngDevMode ? [{ debugName: "columnMode" }] : /* istanbul ignore next */ []));
    anchorDate = input(new Date(), ...(ngDevMode ? [{ debugName: "anchorDate" }] : /* istanbul ignore next */ []));
    theme = input({}, ...(ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []));
    config = input(DEFAULT_CONFIG, ...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** Veto-Hook für Drag&Drop (wird in Phase 4, Schritt 16 verwendet). */
    canMoveEvent = input(() => true, ...(ngDevMode ? [{ debugName: "canMoveEvent" }] : /* istanbul ignore next */ []));
    eventsChange = output();
    tasksChange = output();
    eventMoved = output();
    eventClicked = output();
    /** Doppelklick auf einen Event: ID für einen Editor der Host-App. */
    eventEditRequested = output();
    eventDeleted = output();
    eventUpdated = output();
    eventCreateRequested = output();
    taskCommentsRequested = output();
    /** Pills-Zeile (Personen-Namen) wird nur in columnMode 'resource' gerendert. */
    hasResourceColumns = computed(() => this.state.dayGroups().some((group) => group.columns.some((column) => !!column.resource)), ...(ngDevMode ? [{ debugName: "hasResourceColumns" }] : /* istanbul ignore next */ []));
    normalizedEvents = computed(() => mergeById(this.data().events ?? [], this.events(), this.event()), ...(ngDevMode ? [{ debugName: "normalizedEvents" }] : /* istanbul ignore next */ []));
    normalizedResources = computed(() => mergeById(this.data().resources ?? [], this.resources(), this.resource()), ...(ngDevMode ? [{ debugName: "normalizedResources" }] : /* istanbul ignore next */ []));
    normalizedTasks = computed(() => mergeById(this.data().tasks ?? [], this.tasks()), ...(ngDevMode ? [{ debugName: "normalizedTasks" }] : /* istanbul ignore next */ []));
    /** Puffer unterhalb der letzten Stundenlinie, damit der Personen-Rahmen sie nicht am Eck abschneidet. */
    frameBottomBufferPx = 6;
    taskFrameMinHeightPx = computed(() => {
        const showCompleted = this.showCompletedTasks();
        const columnHeights = [...this.state.tasksByColumn().values()].map((tasks) => estimateTaskColumnHeight(tasks, showCompleted));
        return Math.max(TASK_ROOT_ROW_HEIGHT_PX + TASK_MODE_TOP_INSET_PX, ...columnHeights);
    }, ...(ngDevMode ? [{ debugName: "taskFrameMinHeightPx" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => this.state.setEvents(this.normalizedEvents()));
        effect(() => this.state.setTasks(this.normalizedTasks()));
        effect(() => this.state.setResources(this.normalizedResources()));
        effect(() => this.state.setViewMode(this.viewMode()));
        effect(() => this.state.setColumnMode(this.columnMode()));
        effect(() => this.state.setAnchorDate(this.anchorDate()));
        effect(() => this.state.setConfig(this.config()));
        effect(() => this.themeService.apply(this.theme(), this.hostElement.nativeElement));
        // Misst die verfügbare Höhe des Grid-Bodys, damit GridStateService die Stunden ohne
        // Scrollen exakt in den Container stauchen kann (siehe effectiveConfig).
        afterNextRender(() => {
            const element = this.bodyEl()?.nativeElement;
            if (!element || typeof ResizeObserver === 'undefined') {
                return;
            }
            const observer = new ResizeObserver((entries) => {
                const height = entries[0]?.contentRect.height ?? 0;
                this.state.setContainerHeightPx(height);
            });
            observer.observe(element);
            this.destroyRef.onDestroy(() => observer.disconnect());
        });
    }
    /** Berechnet aus dem CDK-Drop-Event die neue Start-/Endzeit (und ggf. Ressource) und meldet sie nach außen. */
    onColumnDropped(dropEvent) {
        const calendarEvent = dropEvent.item.data;
        if (!this.canMoveEvent()(calendarEvent)) {
            return;
        }
        const anchor = this.state.dragAnchor();
        this.state.setDragAnchor(null);
        // Zielspalte = Spalte, in der die Vorschau eingerastet war (nicht die unter dem Mauszeiger).
        const targetKey = anchor?.columnKey ?? dropEvent.container.data;
        const targetColumn = this.state.flatColumns().find((column) => column.key === targetKey);
        if (!targetColumn) {
            return;
        }
        const config = this.state.effectiveConfig();
        const referenceDate = targetColumn.date ?? this.state.visibleDates()[0];
        // Ohne Bewegung bleibt der Event auf seiner bisherigen Linie.
        const line = anchor?.line ??
            this.layoutService.nearestGridLine(this.state.gridLinesPx(), this.layoutService.timeToOffset(new Date(calendarEvent.start), config));
        const newStart = this.layoutService.timeOnGridLine(line, referenceDate);
        const durationMs = new Date(calendarEvent.end).getTime() - new Date(calendarEvent.start).getTime();
        const newEnd = new Date(newStart.getTime() + durationMs);
        const updatedEvent = {
            ...calendarEvent,
            start: newStart.toISOString(),
            end: newEnd.toISOString(),
            resourceId: targetColumn.resource?.id ?? calendarEvent.resourceId,
        };
        const updatedEvents = this.events().map((existing) => (existing.id === updatedEvent.id ? updatedEvent : existing));
        this.eventsChange.emit(updatedEvents);
        this.eventMoved.emit(updatedEvent);
    }
    /** Entfernt einen Event aus dem Array und meldet die Änderung nach außen (immutable). */
    onEventDeleted(event) {
        const updatedEvents = this.events().filter((existing) => existing.id !== event.id);
        this.eventsChange.emit(updatedEvents);
        this.eventDeleted.emit(event);
    }
    /** Aktualisiert einen Event (z. B. durch Resize) und meldet die Änderung nach außen (immutable). */
    onEventUpdated(updatedEvent) {
        const updatedEvents = this.events().map((existing) => (existing.id === updatedEvent.id ? updatedEvent : existing));
        this.eventsChange.emit(updatedEvents);
        this.eventUpdated.emit(updatedEvent);
    }
    onEventDrawn(request) {
        const draft = {
            id: this.nextDraftId(),
            title: '',
            start: request.start,
            end: request.end,
            resourceId: request.resourceId,
            isDraft: true,
        };
        this.eventsChange.emit([...this.normalizedEvents(), draft]);
        this.eventCreateRequested.emit(draft);
    }
    onTasksChanged(updatedTasks) {
        const updatedIds = new Set(updatedTasks.map((task) => task.id));
        const tasks = [...this.normalizedTasks().filter((task) => !updatedIds.has(task.id)), ...updatedTasks];
        this.tasksChange.emit(tasks);
    }
    nextDraftId() {
        const negativeIds = this.normalizedEvents().map((event) => event.id).filter((id) => id < 0);
        return Math.min(0, ...negativeIds) - 1;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridCalendar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: GridCalendar, isStandalone: true, selector: "glc-grid-calendar", inputs: { event: { classPropertyName: "event", publicName: "event", isSignal: true, isRequired: false, transformFunction: null }, events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: false, transformFunction: null }, tasks: { classPropertyName: "tasks", publicName: "tasks", isSignal: true, isRequired: false, transformFunction: null }, showCompletedTasks: { classPropertyName: "showCompletedTasks", publicName: "showCompletedTasks", isSignal: true, isRequired: false, transformFunction: null }, contentMode: { classPropertyName: "contentMode", publicName: "contentMode", isSignal: true, isRequired: false, transformFunction: null }, resource: { classPropertyName: "resource", publicName: "resource", isSignal: true, isRequired: false, transformFunction: null }, resources: { classPropertyName: "resources", publicName: "resources", isSignal: true, isRequired: false, transformFunction: null }, data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, viewMode: { classPropertyName: "viewMode", publicName: "viewMode", isSignal: true, isRequired: false, transformFunction: null }, columnMode: { classPropertyName: "columnMode", publicName: "columnMode", isSignal: true, isRequired: false, transformFunction: null }, anchorDate: { classPropertyName: "anchorDate", publicName: "anchorDate", isSignal: true, isRequired: false, transformFunction: null }, theme: { classPropertyName: "theme", publicName: "theme", isSignal: true, isRequired: false, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: false, transformFunction: null }, canMoveEvent: { classPropertyName: "canMoveEvent", publicName: "canMoveEvent", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { eventsChange: "eventsChange", tasksChange: "tasksChange", eventMoved: "eventMoved", eventClicked: "eventClicked", eventEditRequested: "eventEditRequested", eventDeleted: "eventDeleted", eventUpdated: "eventUpdated", eventCreateRequested: "eventCreateRequested", taskCommentsRequested: "taskCommentsRequested" }, providers: [GridStateService], viewQueries: [{ propertyName: "bodyEl", first: true, predicate: ["bodyEl"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div
      class="glc-grid-calendar"
    >
      <div class="glc-grid-calendar__header-row">
        <div class="glc-grid-calendar__header-spacer"></div>
        <div class="glc-grid-calendar__columns">
          <glc-grid-header
            [dayGroups]="state.dayGroups()"
          />
        </div>
      </div>
      @if (hasResourceColumns()) {
        <div class="glc-grid-calendar__pills-row">
          <div class="glc-grid-calendar__header-spacer"></div>
          <div class="glc-grid-calendar__columns">
            @for (group of state.dayGroups(); track group.date.toISOString()) {
              <div
                class="glc-grid-calendar__pills-day-group"
                [style.flex-grow]="group.columns.length"
              >
                @for (column of group.columns; track column.key) {
                  @let resourceColor = column.resource?.color;
                  <div
                    class="glc-grid-calendar__pill-cell"
                    [style.border-top]="resourceColor ? '3px solid ' + resourceColor : null"
                    [style.border-left]="resourceColor ? '3px solid ' + resourceColor : null"
                    [style.border-right]="resourceColor ? '3px solid ' + resourceColor : null"
                    [style.border-radius]="resourceColor ? '8px 8px 0 0' : null"
                  >
                    @if (column.resource) {
                      <span class="glc-grid-calendar__pill" [style.background-color]="column.resource.color">
                        {{ column.label }}
                      </span>
                    }
                  </div>
                }
              </div>
            }
          </div>
        </div>
      }
      <div class="glc-grid-calendar__grid-content" [hidden]="contentMode() === 'tasks'">
        <div class="glc-grid-calendar__body" #bodyEl>
        <glc-time-axis [config]="state.effectiveConfig()" [style.height.px]="state.contentHeightPx() + frameBottomBufferPx" />
        @if (state.isNowVisible()) {
          <div class="glc-grid-calendar__now-badge-wrap" [style.top.px]="state.nowOffsetPx()">
            <span class="glc-grid-calendar__now-badge">{{ state.now() | date: 'HH:mm' }}</span>
          </div>
        }
        <div class="glc-grid-calendar__columns" cdkDropListGroup>
          @for (group of state.dayGroups(); track group.date.toISOString()) {
            <div
              class="glc-grid-calendar__day-group"
              [style.flex-grow]="group.columns.length"
              [style.height.px]="state.contentHeightPx() + frameBottomBufferPx"
            >
              @for (column of group.columns; track column.key) {
                <glc-day-column
                  [columnKey]="column.key"
                  [layouts]="state.layoutByColumn().get(column.key) ?? []"
                  [columnDate]="group.date"
                  [config]="state.effectiveConfig()"
                  [borderColor]="column.resource?.color"
                  [resourceId]="column.resource?.id"
                  [gridLinesPx]="state.gridLinesPx()"
                  [style.height.px]="state.contentHeightPx() + frameBottomBufferPx"
                  (eventClicked)="eventClicked.emit($event)"
                  (eventEditRequested)="eventEditRequested.emit($event)"
                  (eventDeleted)="onEventDeleted($event)"
                  (eventUpdated)="onEventUpdated($event)"
                  (eventDrawn)="onEventDrawn($event)"
                  (dropped)="onColumnDropped($event)"
                />
              }
              @if (group.isToday && state.isNowVisible()) {
                <div class="glc-grid-calendar__now-line" [style.top.px]="state.nowOffsetPx()"></div>
              }
            </div>
          }
        </div>
      </div>
      </div>
      @if (contentMode() !== 'grid') {
      <div class="glc-grid-calendar__tasks-row" [class.glc-grid-calendar__tasks-row--full]="contentMode() === 'tasks'">
        <div class="glc-grid-calendar__header-spacer"></div>
        <div class="glc-grid-calendar__columns">
          @for (group of state.dayGroups(); track group.date.toISOString()) {
              <div
                class="glc-grid-calendar__day-group"
                [style.flex-grow]="group.columns.length"
                [style.min-height.px]="contentMode() === 'tasks' ? taskFrameMinHeightPx() : null"
              >
              @for (column of group.columns; track column.key) {
                @let taskFrameColor = column.resource?.color;
                <glc-task-list-column
                  [tasks]="state.tasksByColumn().get(column.key) ?? []"
                  [resources]="normalizedResources()"
                  [showCompleted]="showCompletedTasks()"
                  [style.border-left]="contentMode() === 'tasks' && taskFrameColor ? '3px solid ' + taskFrameColor : null"
                  [style.border-right]="contentMode() === 'tasks' && taskFrameColor ? '3px solid ' + taskFrameColor : null"
                  [style.border-bottom]="contentMode() === 'tasks' && taskFrameColor ? '3px solid ' + taskFrameColor : null"
                  [style.border-radius]="contentMode() === 'tasks' && taskFrameColor ? '0 0 8px 8px' : null"
                  (tasksChange)="onTasksChanged($event)"
                  (commentsRequested)="taskCommentsRequested.emit($event)"
                />
              }
            </div>
          }
        </div>
      </div>
      }
    </div>
  `, isInline: true, styles: [".glc-grid-calendar{display:flex;flex-direction:column;width:100%;height:100%;font-family:var(--glc-font-family, inherit)}.glc-grid-calendar__grid-content{display:flex;flex:1 1 auto;flex-direction:column;min-height:0}.glc-grid-calendar__grid-content[hidden]{display:none}.glc-grid-calendar__header-row{display:flex;flex:0 0 auto}.glc-grid-calendar__header-spacer{flex:0 0 var(--glc-time-axis-width, 3.5rem)}.glc-grid-calendar__pills-row{display:flex;flex:0 0 auto}.glc-grid-calendar__pill-cell{box-sizing:border-box;flex:1 1 0;min-width:0;display:flex;align-items:center;justify-content:center;padding:.4rem}.glc-grid-calendar__pill{display:inline-block;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:center;color:#fff;font-size:.75rem;font-weight:600;padding:.3rem .75rem;border-radius:999px}.glc-grid-calendar__body{position:relative;display:flex;flex:1 1 auto;min-height:0;overflow:visible}.glc-grid-calendar__tasks-row{display:flex;flex:0 0 auto;padding-top:.85rem}.glc-grid-calendar__tasks-row:not(.glc-grid-calendar__tasks-row--full)>.glc-grid-calendar__columns{border-top:1px solid var(--glc-color-border, #ccc)}.glc-grid-calendar__tasks-row--full{box-sizing:border-box;flex:1 1 0;min-height:0;overflow:visible;border-top:0;padding-top:0}.glc-grid-calendar__tasks-row--full>.glc-grid-calendar__columns{height:100%;align-items:flex-start}.glc-grid-calendar__columns{display:flex;flex:1 1 0;min-width:0;gap:var(--glc-columns-gap, 8px);padding:0 var(--glc-columns-padding-inline, 8px)}.glc-grid-calendar__day-group{display:flex;position:relative;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__pills-day-group{display:flex;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__now-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-now, #e03131);pointer-events:none}.glc-grid-calendar__now-badge-wrap{position:absolute;left:0;width:var(--glc-time-axis-width, 3.5rem);box-sizing:border-box;transform:translateY(-50%);display:flex;justify-content:flex-end;overflow:hidden;z-index:2;pointer-events:none}.glc-grid-calendar__now-badge{display:inline-block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.75rem;font-weight:700;color:#fff;background:var(--glc-color-now, #e03131);border-radius:4px;padding:.05rem .35rem}\n"], dependencies: [{ kind: "component", type: GridHeaderComponent, selector: "glc-grid-header", inputs: ["dayGroups"] }, { kind: "component", type: TimeAxisComponent, selector: "glc-time-axis", inputs: ["config"] }, { kind: "component", type: DayColumnComponent, selector: "glc-day-column", inputs: ["columnKey", "layouts", "columnDate", "config", "borderColor", "resourceId", "gridLinesPx"], outputs: ["dropped", "eventClicked", "eventEditRequested", "eventDeleted", "eventUpdated", "eventDrawn"] }, { kind: "component", type: TaskListColumnComponent, selector: "glc-task-list-column", inputs: ["tasks", "resources", "showCompleted"], outputs: ["tasksChange", "commentsRequested"] }, { kind: "directive", type: CdkDropListGroup, selector: "[cdkDropListGroup]", inputs: ["cdkDropListGroupDisabled"], exportAs: ["cdkDropListGroup"] }, { kind: "pipe", type: DatePipe, name: "date" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridCalendar, decorators: [{
            type: Component,
            args: [{ selector: 'glc-grid-calendar', standalone: true, imports: [GridHeaderComponent, TimeAxisComponent, DayColumnComponent, TaskListColumnComponent, CdkDropListGroup, DatePipe], providers: [GridStateService], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div
      class="glc-grid-calendar"
    >
      <div class="glc-grid-calendar__header-row">
        <div class="glc-grid-calendar__header-spacer"></div>
        <div class="glc-grid-calendar__columns">
          <glc-grid-header
            [dayGroups]="state.dayGroups()"
          />
        </div>
      </div>
      @if (hasResourceColumns()) {
        <div class="glc-grid-calendar__pills-row">
          <div class="glc-grid-calendar__header-spacer"></div>
          <div class="glc-grid-calendar__columns">
            @for (group of state.dayGroups(); track group.date.toISOString()) {
              <div
                class="glc-grid-calendar__pills-day-group"
                [style.flex-grow]="group.columns.length"
              >
                @for (column of group.columns; track column.key) {
                  @let resourceColor = column.resource?.color;
                  <div
                    class="glc-grid-calendar__pill-cell"
                    [style.border-top]="resourceColor ? '3px solid ' + resourceColor : null"
                    [style.border-left]="resourceColor ? '3px solid ' + resourceColor : null"
                    [style.border-right]="resourceColor ? '3px solid ' + resourceColor : null"
                    [style.border-radius]="resourceColor ? '8px 8px 0 0' : null"
                  >
                    @if (column.resource) {
                      <span class="glc-grid-calendar__pill" [style.background-color]="column.resource.color">
                        {{ column.label }}
                      </span>
                    }
                  </div>
                }
              </div>
            }
          </div>
        </div>
      }
      <div class="glc-grid-calendar__grid-content" [hidden]="contentMode() === 'tasks'">
        <div class="glc-grid-calendar__body" #bodyEl>
        <glc-time-axis [config]="state.effectiveConfig()" [style.height.px]="state.contentHeightPx() + frameBottomBufferPx" />
        @if (state.isNowVisible()) {
          <div class="glc-grid-calendar__now-badge-wrap" [style.top.px]="state.nowOffsetPx()">
            <span class="glc-grid-calendar__now-badge">{{ state.now() | date: 'HH:mm' }}</span>
          </div>
        }
        <div class="glc-grid-calendar__columns" cdkDropListGroup>
          @for (group of state.dayGroups(); track group.date.toISOString()) {
            <div
              class="glc-grid-calendar__day-group"
              [style.flex-grow]="group.columns.length"
              [style.height.px]="state.contentHeightPx() + frameBottomBufferPx"
            >
              @for (column of group.columns; track column.key) {
                <glc-day-column
                  [columnKey]="column.key"
                  [layouts]="state.layoutByColumn().get(column.key) ?? []"
                  [columnDate]="group.date"
                  [config]="state.effectiveConfig()"
                  [borderColor]="column.resource?.color"
                  [resourceId]="column.resource?.id"
                  [gridLinesPx]="state.gridLinesPx()"
                  [style.height.px]="state.contentHeightPx() + frameBottomBufferPx"
                  (eventClicked)="eventClicked.emit($event)"
                  (eventEditRequested)="eventEditRequested.emit($event)"
                  (eventDeleted)="onEventDeleted($event)"
                  (eventUpdated)="onEventUpdated($event)"
                  (eventDrawn)="onEventDrawn($event)"
                  (dropped)="onColumnDropped($event)"
                />
              }
              @if (group.isToday && state.isNowVisible()) {
                <div class="glc-grid-calendar__now-line" [style.top.px]="state.nowOffsetPx()"></div>
              }
            </div>
          }
        </div>
      </div>
      </div>
      @if (contentMode() !== 'grid') {
      <div class="glc-grid-calendar__tasks-row" [class.glc-grid-calendar__tasks-row--full]="contentMode() === 'tasks'">
        <div class="glc-grid-calendar__header-spacer"></div>
        <div class="glc-grid-calendar__columns">
          @for (group of state.dayGroups(); track group.date.toISOString()) {
              <div
                class="glc-grid-calendar__day-group"
                [style.flex-grow]="group.columns.length"
                [style.min-height.px]="contentMode() === 'tasks' ? taskFrameMinHeightPx() : null"
              >
              @for (column of group.columns; track column.key) {
                @let taskFrameColor = column.resource?.color;
                <glc-task-list-column
                  [tasks]="state.tasksByColumn().get(column.key) ?? []"
                  [resources]="normalizedResources()"
                  [showCompleted]="showCompletedTasks()"
                  [style.border-left]="contentMode() === 'tasks' && taskFrameColor ? '3px solid ' + taskFrameColor : null"
                  [style.border-right]="contentMode() === 'tasks' && taskFrameColor ? '3px solid ' + taskFrameColor : null"
                  [style.border-bottom]="contentMode() === 'tasks' && taskFrameColor ? '3px solid ' + taskFrameColor : null"
                  [style.border-radius]="contentMode() === 'tasks' && taskFrameColor ? '0 0 8px 8px' : null"
                  (tasksChange)="onTasksChanged($event)"
                  (commentsRequested)="taskCommentsRequested.emit($event)"
                />
              }
            </div>
          }
        </div>
      </div>
      }
    </div>
  `, styles: [".glc-grid-calendar{display:flex;flex-direction:column;width:100%;height:100%;font-family:var(--glc-font-family, inherit)}.glc-grid-calendar__grid-content{display:flex;flex:1 1 auto;flex-direction:column;min-height:0}.glc-grid-calendar__grid-content[hidden]{display:none}.glc-grid-calendar__header-row{display:flex;flex:0 0 auto}.glc-grid-calendar__header-spacer{flex:0 0 var(--glc-time-axis-width, 3.5rem)}.glc-grid-calendar__pills-row{display:flex;flex:0 0 auto}.glc-grid-calendar__pill-cell{box-sizing:border-box;flex:1 1 0;min-width:0;display:flex;align-items:center;justify-content:center;padding:.4rem}.glc-grid-calendar__pill{display:inline-block;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:center;color:#fff;font-size:.75rem;font-weight:600;padding:.3rem .75rem;border-radius:999px}.glc-grid-calendar__body{position:relative;display:flex;flex:1 1 auto;min-height:0;overflow:visible}.glc-grid-calendar__tasks-row{display:flex;flex:0 0 auto;padding-top:.85rem}.glc-grid-calendar__tasks-row:not(.glc-grid-calendar__tasks-row--full)>.glc-grid-calendar__columns{border-top:1px solid var(--glc-color-border, #ccc)}.glc-grid-calendar__tasks-row--full{box-sizing:border-box;flex:1 1 0;min-height:0;overflow:visible;border-top:0;padding-top:0}.glc-grid-calendar__tasks-row--full>.glc-grid-calendar__columns{height:100%;align-items:flex-start}.glc-grid-calendar__columns{display:flex;flex:1 1 0;min-width:0;gap:var(--glc-columns-gap, 8px);padding:0 var(--glc-columns-padding-inline, 8px)}.glc-grid-calendar__day-group{display:flex;position:relative;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__pills-day-group{display:flex;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__now-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-now, #e03131);pointer-events:none}.glc-grid-calendar__now-badge-wrap{position:absolute;left:0;width:var(--glc-time-axis-width, 3.5rem);box-sizing:border-box;transform:translateY(-50%);display:flex;justify-content:flex-end;overflow:hidden;z-index:2;pointer-events:none}.glc-grid-calendar__now-badge{display:inline-block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.75rem;font-weight:700;color:#fff;background:var(--glc-color-now, #e03131);border-radius:4px;padding:.05rem .35rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { bodyEl: [{ type: i0.ViewChild, args: ['bodyEl', { isSignal: true }] }], event: [{ type: i0.Input, args: [{ isSignal: true, alias: "event", required: false }] }], events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: false }] }], tasks: [{ type: i0.Input, args: [{ isSignal: true, alias: "tasks", required: false }] }], showCompletedTasks: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCompletedTasks", required: false }] }], contentMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentMode", required: false }] }], resource: [{ type: i0.Input, args: [{ isSignal: true, alias: "resource", required: false }] }], resources: [{ type: i0.Input, args: [{ isSignal: true, alias: "resources", required: false }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], viewMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "viewMode", required: false }] }], columnMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnMode", required: false }] }], anchorDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "anchorDate", required: false }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: false }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: false }] }], canMoveEvent: [{ type: i0.Input, args: [{ isSignal: true, alias: "canMoveEvent", required: false }] }], eventsChange: [{ type: i0.Output, args: ["eventsChange"] }], tasksChange: [{ type: i0.Output, args: ["tasksChange"] }], eventMoved: [{ type: i0.Output, args: ["eventMoved"] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], eventEditRequested: [{ type: i0.Output, args: ["eventEditRequested"] }], eventDeleted: [{ type: i0.Output, args: ["eventDeleted"] }], eventUpdated: [{ type: i0.Output, args: ["eventUpdated"] }], eventCreateRequested: [{ type: i0.Output, args: ["eventCreateRequested"] }], taskCommentsRequested: [{ type: i0.Output, args: ["taskCommentsRequested"] }] } });
function mergeById(...sources) {
    const values = new Map();
    for (const source of sources) {
        const entries = Array.isArray(source) ? source : source ? [source] : [];
        for (const entry of entries) {
            values.set(entry.id, entry);
        }
    }
    return [...values.values()];
}
function estimateTaskColumnHeight(tasks, showCompleted) {
    const childrenByParent = new Map();
    for (const task of tasks) {
        if (task.parentId === undefined)
            continue;
        const children = childrenByParent.get(task.parentId) ?? [];
        children.push(task);
        childrenByParent.set(task.parentId, children);
    }
    let height = TASK_MODE_TOP_INSET_PX;
    let visibleRoots = 0;
    for (const task of tasks) {
        if (task.parentId !== undefined)
            continue;
        const children = childrenByParent.get(task.id) ?? [];
        const completed = children.length ? children.every((child) => child.completed) : task.completed;
        if (!showCompleted && completed)
            continue;
        if (visibleRoots)
            height += TASK_GROUP_GAP_PX;
        visibleRoots++;
        height += TASK_ROOT_ROW_HEIGHT_PX + children.length * TASK_CHILD_ROW_HEIGHT_PX;
    }
    return height + TASK_RESOURCE_FRAME_BOTTOM_PX;
}

/*
 * Public API Surface of grid-calendar
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DayColumnComponent, EventItemComponent, GridCalendar, GridHeaderComponent, GridLayoutService, TaskListColumnComponent, ThemeService, TimeAxisComponent };
//# sourceMappingURL=swbpapk_acmtemu-grid-calendar.mjs.map
