import * as lucide_angular from 'lucide-angular';
import * as _angular_core from '@angular/core';

interface PlanDay {
    readonly id: string;
    readonly name: string;
    readonly color?: string;
}
interface PlanTimeSlot {
    readonly id: string;
    readonly start: string;
    readonly end: string;
    readonly label?: string;
}
interface PlanCategory {
    readonly id: string;
    readonly name: string;
}
interface PlanSubject {
    readonly id: string;
    readonly categoryId: string;
    readonly name: string;
    readonly color: string;
}
interface PlanCell {
    readonly dayId: string;
    readonly timeSlotId: string;
}
interface PlanEntry extends PlanCell {
    readonly subjectId: string;
    readonly hidden?: boolean;
}
interface PlanEntryChange extends PlanCell {
    readonly subjectId: string | null;
}

declare class PlanLearn {
    readonly planName: _angular_core.InputSignal<string>;
    readonly days: _angular_core.InputSignal<readonly PlanDay[]>;
    readonly timeSlots: _angular_core.InputSignal<readonly PlanTimeSlot[]>;
    readonly categories: _angular_core.InputSignal<readonly PlanCategory[]>;
    readonly subjects: _angular_core.InputSignal<readonly PlanSubject[]>;
    readonly entries: _angular_core.InputSignal<readonly PlanEntry[]>;
    readonly showPeriods: _angular_core.InputSignal<boolean>;
    readonly entryChange: _angular_core.OutputEmitterRef<PlanEntryChange>;
    readonly hideRequested: _angular_core.OutputEmitterRef<PlanEntry>;
    protected readonly hideIcon: lucide_angular.LucideIconData;
    protected readonly showIcon: lucide_angular.LucideIconData;
    protected readonly categoryId: _angular_core.WritableSignal<string>;
    protected readonly activeCell: _angular_core.WritableSignal<PlanCell | null>;
    protected readonly dragging: _angular_core.WritableSignal<boolean>;
    private scrollGesture;
    private blockCellClick;
    private readonly picker;
    protected readonly availableSubjects: _angular_core.Signal<PlanSubject[]>;
    protected readonly rows: _angular_core.Signal<{
        slot: PlanTimeSlot;
        period: string;
        cells: {
            day: PlanDay;
            entry: PlanEntry | undefined;
            subject: PlanSubject | undefined;
        }[];
    }[]>;
    protected readonly activeLabel: _angular_core.Signal<string>;
    protected readonly activeEntry: _angular_core.Signal<PlanEntry | undefined>;
    protected setCategory(value: string): void;
    protected toggleVisibility(entry: PlanEntry): void;
    protected startScroll(event: PointerEvent): void;
    protected moveScroll(event: PointerEvent): void;
    protected endScroll(event: PointerEvent): void;
    protected openCell(dayId: string, timeSlotId: string): void;
    protected chooseSubject(subjectId: string | null): void;
    protected closePicker(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PlanLearn, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PlanLearn, "lib-plan-learn", never, { "planName": { "alias": "planName"; "required": false; "isSignal": true; }; "days": { "alias": "days"; "required": false; "isSignal": true; }; "timeSlots": { "alias": "timeSlots"; "required": false; "isSignal": true; }; "categories": { "alias": "categories"; "required": false; "isSignal": true; }; "subjects": { "alias": "subjects"; "required": false; "isSignal": true; }; "entries": { "alias": "entries"; "required": false; "isSignal": true; }; "showPeriods": { "alias": "showPeriods"; "required": false; "isSignal": true; }; }, { "entryChange": "entryChange"; "hideRequested": "hideRequested"; }, never, never, true, never>;
}

export { PlanLearn };
export type { PlanCategory, PlanCell, PlanDay, PlanEntry, PlanEntryChange, PlanSubject, PlanTimeSlot };
