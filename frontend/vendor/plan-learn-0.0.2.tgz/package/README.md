# plan-learn

Bearbeitbares Wochenraster als Standalone-Komponente `PlanLearn`
(Selector `lib-plan-learn`). Alle Daten kommen vom Konsumenten; die Library
veraendert keine Input-Arrays. Es sind keine Backend-Dienste erforderlich.

## Installation

Das gebaute Paket in einem Angular-21.2-Projekt installieren:

```sh
npm install /pfad/zu/plan-learn-0.0.2.tgz
```

Peer-Abhaengigkeiten sind `@angular/common`, `@angular/core` (jeweils `^21.2.0`)
und `lucide-angular` (`>=0.468.0`). Der Workspace prueft die Icons mit
`lucide-angular` 1.0. npm installiert fehlende Peers normalerweise automatisch.
Es gibt keinen globalen Provider und kein zusaetzliches Stylesheet einzubinden.
`PlanLearn` wird in die `imports` der konsumierenden Standalone-Komponente aufgenommen.

## Verwendung

```html
<lib-plan-learn
	[planName]="planName"
	[days]="days"
	[timeSlots]="timeSlots"
	[categories]="categories"
	[subjects]="subjects"
	[entries]="entries()"
	[showPeriods]="true"
	(entryChange)="updateEntry($event)"
	(hideRequested)="requestHide($event)"
/>
```

`PlanLearn` und alle folgenden Typen werden aus `plan-learn` importiert.

### Vollstaendiges Beispiel

```ts
import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import {
	PlanLearn,
	type PlanCategory,
	type PlanDay,
	type PlanEntry,
	type PlanEntryChange,
	type PlanSubject,
	type PlanTimeSlot,
} from 'plan-learn';

@Component({
	selector: 'app-week-plan',
	imports: [PlanLearn],
	changeDetection: ChangeDetectionStrategy.OnPush,
	template: `
		<lib-plan-learn
			planName="Klasse 7a"
			[days]="days"
			[timeSlots]="timeSlots"
			[categories]="categories"
			[subjects]="subjects"
			[entries]="entries()"
			[showPeriods]="true"
			(entryChange)="updateEntry($event)"
			(hideRequested)="requestHide($event)"
		/>
	`,
})
export class WeekPlan {
	readonly days: readonly PlanDay[] = [
		{ id: 'mo', name: 'Montag' },
		{ id: 'di', name: 'Dienstag' },
	];
	readonly timeSlots: readonly PlanTimeSlot[] = [
		{ id: '1', start: '08:00', end: '08:45' },
		{ id: '2', start: '08:50', end: '09:35' },
	];
	readonly categories: readonly PlanCategory[] = [
		{ id: 'science', name: 'Natur & Technik' },
	];
	readonly subjects: readonly PlanSubject[] = [
		{ id: 'math', categoryId: 'science', name: 'Mathematik', color: '#dfb35e' },
	];
	readonly entries = signal<readonly PlanEntry[]>([
		{ dayId: 'mo', timeSlotId: '1', subjectId: 'math' },
	]);

	updateEntry(change: PlanEntryChange): void {
		this.entries.update((entries) => {
			const remaining = entries.filter((entry) =>
				entry.dayId !== change.dayId || entry.timeSlotId !== change.timeSlotId);
			return change.subjectId === null ? remaining : [
				...remaining,
				{ dayId: change.dayId, timeSlotId: change.timeSlotId, subjectId: change.subjectId },
			];
		});
	}

	requestHide(changed: PlanEntry): void {
		this.entries.update((entries) => entries.map((entry) =>
			entry.dayId === changed.dayId && entry.timeSlotId === changed.timeSlotId
				? changed : entry));
	}
}
```

### Inputs

| Input | Typ | Bedeutung |
| --- | --- | --- |
| `planName` | `string` | Titel, Standard: `Stundenplan` |
| `days` | `readonly PlanDay[]` | Spalten mit `id`, `name`, optional `color` |
| `timeSlots` | `readonly PlanTimeSlot[]` | Zeilen mit `id`, `start`, `end`, optional `label` fuer die Stundenspalte |
| `categories` | `readonly PlanCategory[]` | Kategorien mit `id`, `name` |
| `subjects` | `readonly PlanSubject[]` | Faecher mit `id`, `categoryId`, `name`, CSS-`color` |
| `entries` | `readonly PlanEntry[]` | Belegungen mit `dayId`, `timeSlotId`, `subjectId`, optional `hidden` |
| `showPeriods` | `boolean` | Stundenspalte anzeigen, Standard: `true` |

IDs muessen je Datentyp eindeutig sein. Pro Tag und Zeitbereich ist genau ein
Fach vorgesehen. Eintraege referenzieren vorhandene Tage, Zeitbereiche und
Faecher; `categoryId` referenziert eine Kategorie. Die Reihenfolge der Inputs
bestimmt die Reihenfolge der Zeilen, Spalten und Auswahloptionen. Zeitangaben
sind Anzeigetexte und werden unveraendert dargestellt.

## Events

- `entryChange: PlanEntryChange`: `{ dayId, timeSlotId, subjectId }` bei einer
	Fachauswahl. `subjectId: null` bedeutet Entfernen. Der Konsument aktualisiert
	`entries` unveraenderlich und reicht den neuen Wert wieder als Input hinein.
- `hideRequested: PlanEntry`: Sichtbarkeitswunsch fuer genau eine Belegung mit dem
	neuen `hidden`-Wert (`true`: ausblenden, `false`: einblenden). Der Konsument
	uebernimmt den Status in `entries` und reicht ihn als Input zurueck. Dadurch
	wechseln Icon und Tooltip zwischen Ausblenden und Einblenden. Die Library
	entfernt oder versteckt das Fach nicht selbst.

Die Kategorie filtert nur die Fachauswahl, niemals den bestehenden Plan.
`Alle Kategorien` bietet alle Faecher an. Ein vollstaendig vorbelegter Kalender
bleibt genauso bearbeitbar wie ein leerer. Escape oder Schliessen bricht die
Auswahl ohne Aenderung ab. Der native Dialog haelt den Fokus innerhalb der
Auswahl und gibt ihn anschliessend an die ausloesende Zelle zurueck.

## Darstellung

Die Komponente nutzt kompakte Spaltenbreiten ohne unnoetiges Strecken:
140 px pro Tag, 72 px fuer die Zeit und optional 48 px fuer die Stunde.
Bei zu wenig Platz wird das Raster horizontal scrollbar, waehrend Zeit und
optionale Stundennummern links stehen bleiben. Bei vertikalem Scrollen bleibt
die Kopfzeile stehen. Die horizontale Scrollleiste ist farblich hervorgehoben.
Die Tage lassen sich auch mit gedrueckter linker Maustaste ziehen oder auf
Touchgeraeten nativ wischen. Nach dem Ziehen wird kein Fachdialog geoeffnet;
ein normaler Klick bearbeitet weiterhin die Zelle.
Die Hoehe laesst sich ueber `--plan-max-height` anpassen
(Standard `72vh`), ebenso die Farben ueber `--plan-ink`, `--plan-line` und
`--plan-accent`. Fachfarben dienen als Markierungen, nicht als Textfarben.

Build und Demo-Anweisungen stehen in der [Workspace-Dokumentation](../../README.md).
