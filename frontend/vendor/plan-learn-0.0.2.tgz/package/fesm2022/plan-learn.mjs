import * as i0 from '@angular/core';
import { input, output, signal, viewChild, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from 'lucide-angular';
import { EyeOff, Eye, LucideAngularModule } from 'lucide-angular';

class PlanLearn {
    planName = input('Stundenplan', ...(ngDevMode ? [{ debugName: "planName" }] : /* istanbul ignore next */ []));
    days = input([], ...(ngDevMode ? [{ debugName: "days" }] : /* istanbul ignore next */ []));
    timeSlots = input([], ...(ngDevMode ? [{ debugName: "timeSlots" }] : /* istanbul ignore next */ []));
    categories = input([], ...(ngDevMode ? [{ debugName: "categories" }] : /* istanbul ignore next */ []));
    subjects = input([], ...(ngDevMode ? [{ debugName: "subjects" }] : /* istanbul ignore next */ []));
    entries = input([], ...(ngDevMode ? [{ debugName: "entries" }] : /* istanbul ignore next */ []));
    showPeriods = input(true, ...(ngDevMode ? [{ debugName: "showPeriods" }] : /* istanbul ignore next */ []));
    entryChange = output();
    hideRequested = output();
    hideIcon = EyeOff;
    showIcon = Eye;
    categoryId = signal('', ...(ngDevMode ? [{ debugName: "categoryId" }] : /* istanbul ignore next */ []));
    activeCell = signal(null, ...(ngDevMode ? [{ debugName: "activeCell" }] : /* istanbul ignore next */ []));
    dragging = signal(false, ...(ngDevMode ? [{ debugName: "dragging" }] : /* istanbul ignore next */ []));
    scrollGesture = null;
    blockCellClick = false;
    picker = viewChild('picker', ...(ngDevMode ? [{ debugName: "picker" }] : /* istanbul ignore next */ []));
    availableSubjects = computed(() => this.subjects().filter((subject) => !this.categoryId() || subject.categoryId === this.categoryId()), ...(ngDevMode ? [{ debugName: "availableSubjects" }] : /* istanbul ignore next */ []));
    rows = computed(() => {
        const subjects = new Map(this.subjects().map((subject) => [subject.id, subject]));
        const entries = new Map();
        for (const entry of this.entries()) {
            const day = entries.get(entry.dayId) ?? new Map();
            day.set(entry.timeSlotId, entry);
            entries.set(entry.dayId, day);
        }
        return this.timeSlots().map((slot, index) => ({
            slot,
            period: slot.label ?? String(index + 1),
            cells: this.days().map((day) => {
                const entry = entries.get(day.id)?.get(slot.id);
                return { day, entry, subject: entry ? subjects.get(entry.subjectId) : undefined };
            }),
        }));
    }, ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    activeLabel = computed(() => {
        const cell = this.activeCell();
        const day = this.days().find((item) => item.id === cell?.dayId);
        const slot = this.timeSlots().find((item) => item.id === cell?.timeSlotId);
        return day && slot ? `${day.name}, ${slot.start} - ${slot.end}` : '';
    }, ...(ngDevMode ? [{ debugName: "activeLabel" }] : /* istanbul ignore next */ []));
    activeEntry = computed(() => {
        const cell = this.activeCell();
        return this.entries().find((entry) => entry.dayId === cell?.dayId && entry.timeSlotId === cell?.timeSlotId);
    }, ...(ngDevMode ? [{ debugName: "activeEntry" }] : /* istanbul ignore next */ []));
    setCategory(value) {
        this.categoryId.set(value);
    }
    toggleVisibility(entry) {
        this.hideRequested.emit({ ...entry, hidden: !entry.hidden });
    }
    startScroll(event) {
        this.blockCellClick = false;
        const scroller = event.currentTarget;
        const target = event.target;
        if (event.pointerType !== 'mouse' || event.button !== 0 ||
            scroller.scrollWidth <= scroller.clientWidth ||
            target.closest('.period, .time, .hide-button'))
            return;
        const bounds = scroller.getBoundingClientRect();
        if (event.clientY >= bounds.top + scroller.clientTop + scroller.clientHeight ||
            event.clientX >= bounds.left + scroller.clientLeft + scroller.clientWidth)
            return;
        this.scrollGesture = {
            pointerId: event.pointerId,
            startX: event.clientX,
            startY: event.clientY,
            scrollLeft: scroller.scrollLeft,
        };
    }
    moveScroll(event) {
        const gesture = this.scrollGesture;
        if (!gesture || event.pointerId !== gesture.pointerId)
            return;
        if ((event.buttons & 1) === 0) {
            this.endScroll(event);
            return;
        }
        const distance = event.clientX - gesture.startX;
        if (!this.dragging()) {
            if (Math.abs(distance) < 6 || Math.abs(distance) <= Math.abs(event.clientY - gesture.startY))
                return;
            this.dragging.set(true);
            this.blockCellClick = true;
            event.currentTarget.setPointerCapture(event.pointerId);
        }
        event.preventDefault();
        event.currentTarget.scrollLeft = gesture.scrollLeft - distance;
    }
    endScroll(event) {
        if (this.scrollGesture?.pointerId !== event.pointerId)
            return;
        const scroller = event.currentTarget;
        this.scrollGesture = null;
        this.dragging.set(false);
        if (scroller.hasPointerCapture(event.pointerId))
            scroller.releasePointerCapture(event.pointerId);
        setTimeout(() => { this.blockCellClick = false; });
    }
    openCell(dayId, timeSlotId) {
        if (this.blockCellClick)
            return;
        this.activeCell.set({ dayId, timeSlotId });
        this.picker()?.nativeElement.showModal();
    }
    chooseSubject(subjectId) {
        const cell = this.activeCell();
        if (!cell || (subjectId !== null && !this.availableSubjects().some((subject) => subject.id === subjectId)))
            return;
        this.entryChange.emit({ ...cell, subjectId });
        this.closePicker();
    }
    closePicker() {
        this.picker()?.nativeElement.close();
        this.activeCell.set(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: PlanLearn, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: PlanLearn, isStandalone: true, selector: "lib-plan-learn", inputs: { planName: { classPropertyName: "planName", publicName: "planName", isSignal: true, isRequired: false, transformFunction: null }, days: { classPropertyName: "days", publicName: "days", isSignal: true, isRequired: false, transformFunction: null }, timeSlots: { classPropertyName: "timeSlots", publicName: "timeSlots", isSignal: true, isRequired: false, transformFunction: null }, categories: { classPropertyName: "categories", publicName: "categories", isSignal: true, isRequired: false, transformFunction: null }, subjects: { classPropertyName: "subjects", publicName: "subjects", isSignal: true, isRequired: false, transformFunction: null }, entries: { classPropertyName: "entries", publicName: "entries", isSignal: true, isRequired: false, transformFunction: null }, showPeriods: { classPropertyName: "showPeriods", publicName: "showPeriods", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { entryChange: "entryChange", hideRequested: "hideRequested" }, host: { properties: { "class.with-periods": "showPeriods()" } }, viewQueries: [{ propertyName: "picker", first: true, predicate: ["picker"], descendants: true, isSignal: true }], ngImport: i0, template: "<header class=\"plan-header\">\r\n  <h2>{{ planName() }}</h2>\r\n  <label class=\"category\">Kategorie\r\n    <select #categorySelect [value]=\"categoryId()\" (change)=\"setCategory(categorySelect.value)\">\r\n      <option value=\"\">Alle Kategorien</option>\r\n      @for (category of categories(); track category.id) {\r\n        <option [value]=\"category.id\">{{ category.name }}</option>\r\n      }\r\n    </select>\r\n  </label>\r\n</header>\r\n\r\n<div class=\"schedule\" tabindex=\"0\" role=\"region\" [attr.aria-label]=\"planName()\"\r\n  [class.dragging]=\"dragging()\" (pointerdown)=\"startScroll($event)\"\r\n  (pointermove)=\"moveScroll($event)\" (pointerup)=\"endScroll($event)\"\r\n  (pointercancel)=\"endScroll($event)\" (lostpointercapture)=\"endScroll($event)\">\r\n  <table [style.width.px]=\"days().length * 140 + (showPeriods() ? 120 : 72)\">\r\n    <caption class=\"visually-hidden\">{{ planName() }}</caption>\r\n    <colgroup>\r\n      @if (showPeriods()) { <col class=\"period-col\" /> }\r\n      <col class=\"time-col\" />\r\n      @for (day of days(); track day.id) { <col /> }\r\n    </colgroup>\r\n    <thead>\r\n      <tr>\r\n        @if (showPeriods()) { <th class=\"period\" scope=\"col\">Stunde</th> }\r\n        <th class=\"time\" scope=\"col\">Zeit</th>\r\n        @for (day of days(); track day.id) {\r\n          <th class=\"day\" scope=\"col\" [style.--day-color]=\"day.color ?? '#d9e7df'\">{{ day.name }}</th>\r\n        }\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      @for (row of rows(); track row.slot.id) {\r\n        <tr>\r\n          @if (showPeriods()) { <th class=\"period\" scope=\"row\">{{ row.period }}</th> }\r\n          <th class=\"time\" [attr.scope]=\"showPeriods() ? null : 'row'\">\r\n            <span>{{ row.slot.start }}</span><span class=\"end-time\">{{ row.slot.end }}</span>\r\n          </th>\r\n          @for (cell of row.cells; track cell.day.id) {\r\n            <td>\r\n              <div class=\"cell-content\" [class.occupied]=\"!!cell.entry\"\r\n                [style.--subject-color]=\"cell.subject?.color ?? '#ccd6d0'\">\r\n                <button type=\"button\" class=\"cell-button\"\r\n                  [title]=\"cell.subject?.name ?? ''\"\r\n                  [attr.aria-label]=\"cell.day.name + ', ' + row.slot.start + ' - ' + row.slot.end + ': ' + (cell.subject?.name ?? 'Fach auswaehlen')\"\r\n                  (click)=\"openCell(cell.day.id, row.slot.id)\">\r\n                  @if (cell.entry) {\r\n                    <span class=\"subject-name\">{{ cell.subject?.name ?? 'Unbekanntes Fach' }}</span>\r\n                  } @else {\r\n                    <span class=\"add-mark\" aria-hidden=\"true\">+</span>\r\n                  }\r\n                </button>\r\n                @if (cell.entry; as entry) {\r\n                  <button type=\"button\" class=\"hide-button\"\r\n                    [title]=\"entry.hidden ? 'Einblenden' : 'Ausblenden'\"\r\n                    [attr.aria-label]=\"(cell.subject?.name ?? 'Fach') + (entry.hidden ? ' einblenden, ' : ' ausblenden, ') + cell.day.name + ', ' + row.slot.start\"\r\n                    [attr.aria-pressed]=\"!!entry.hidden\"\r\n                    (click)=\"toggleVisibility(entry)\">\r\n                    <lucide-icon [img]=\"entry.hidden ? showIcon : hideIcon\" [size]=\"16\" aria-hidden=\"true\" />\r\n                  </button>\r\n                }\r\n              </div>\r\n            </td>\r\n          }\r\n        </tr>\r\n      } @empty {\r\n        <tr><td class=\"empty\" [attr.colspan]=\"days().length + (showPeriods() ? 2 : 1)\">Keine Zeitbereiche vorhanden.</td></tr>\r\n      }\r\n    </tbody>\r\n  </table>\r\n</div>\r\n\r\n<dialog #picker aria-label=\"Fach auswaehlen\" (close)=\"activeCell.set(null)\"\r\n  (keydown.escape)=\"closePicker(); $event.preventDefault()\">\r\n  <form method=\"dialog\" class=\"dialog-header\">\r\n    <div><h3>Fach auswaehlen</h3><p>{{ activeLabel() }}</p></div>\r\n    <button class=\"close-button\" aria-label=\"Auswahl schliessen\" title=\"Schliessen\">&times;</button>\r\n  </form>\r\n  <div class=\"subject-list\">\r\n    @for (subject of availableSubjects(); track subject.id) {\r\n      <button type=\"button\" class=\"subject-option\" (click)=\"chooseSubject(subject.id)\">\r\n        <span class=\"swatch\" [style.background]=\"subject.color\" aria-hidden=\"true\"></span>\r\n        {{ subject.name }}\r\n      </button>\r\n    } @empty {\r\n      <p class=\"empty\">Keine Faecher in dieser Kategorie.</p>\r\n    }\r\n  </div>\r\n  @if (activeEntry()) {\r\n    <button type=\"button\" class=\"remove-button\" (click)=\"chooseSubject(null)\">Eintrag entfernen</button>\r\n  }\r\n</dialog>\r\n", styles: [":host{--plan-ink: #20352b;--plan-line: #d3ddd6;--plan-accent: #1b654b;display:block;width:fit-content;max-width:100%;min-width:0;color:var(--plan-ink);font-family:inherit}*{box-sizing:border-box}button,select{font:inherit;color:inherit}button{cursor:pointer}button:focus-visible,select:focus-visible,.schedule:focus-visible{outline:3px solid var(--plan-accent);outline-offset:-3px}.plan-header{display:flex;flex-wrap:wrap;align-items:end;gap:16px;justify-content:space-between;margin-bottom:20px}h2{font-size:1.5rem;margin:0;overflow-wrap:anywhere}.category{display:grid;gap:6px;font-size:.85rem;font-weight:600;max-width:100%}select{background:#fff;border:1px solid #879c8f;border-radius:4px;padding:10px 28px 10px 8px;width:180px;max-width:100%}.schedule{overflow:auto;max-height:var(--plan-max-height, 72vh);border:1px solid var(--plan-line);background:#fff;isolation:isolate}.schedule{scrollbar-color:#708b7b #e4ece6;scrollbar-width:auto;touch-action:pan-x pan-y}.schedule::-webkit-scrollbar{height:14px;width:14px}.schedule::-webkit-scrollbar-track{background:#e4ece6}.schedule::-webkit-scrollbar-thumb{background:#708b7b;border:3px solid #e4ece6;border-radius:7px}.schedule::-webkit-scrollbar-thumb:hover{background:#405f4c}.schedule.dragging,.schedule.dragging button{cursor:grabbing;-webkit-user-select:none;user-select:none}table{width:100%;table-layout:fixed;border-spacing:0;font-size:.9rem}.period-col{width:48px}.time-col{width:72px}th,td{border-right:1px solid var(--plan-line);border-bottom:1px solid var(--plan-line)}tr>:last-child{border-right:0}tbody tr:last-child>*{border-bottom:0}thead th{position:sticky;top:0;z-index:3;height:52px;background:#eef3ef;padding:10px 6px;overflow-wrap:anywhere}thead .day{font-weight:500}.period,.time{position:sticky;z-index:2;background:#f7f9f7;text-align:center;padding:10px 4px}.period{left:0;font-weight:600;font-variant-numeric:tabular-nums}.time{left:0;font-weight:500;font-variant-numeric:tabular-nums;box-shadow:2px 0 0 var(--plan-line)}:host.with-periods .time{left:48px}thead .period,thead .time{z-index:4;background:#eef3ef}thead .period{font-size:.75rem;white-space:nowrap}.time span{display:block;line-height:1.4}.end-time{color:#607066;margin-top:5px}td{padding:6px 3px;vertical-align:middle}.cell-content{height:calc(2.8em + 5px);display:flex;align-items:center;border-radius:4px}.cell-content.occupied{background:var(--subject-color);color:#17251d}.cell-button{display:flex;align-items:center;min-width:0;height:100%;border:0;background:transparent;padding:0 5px;flex:1;text-align:left;border-radius:4px}.cell-button:hover{background:#0000000a}.subject-name{font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.add-mark{display:block;width:100%;text-align:center;color:#687c70;font-size:1.4rem}.hide-button{display:grid;place-items:center;flex:0 0 24px;width:24px;height:28px;margin-right:2px;padding:0;border:0;border-radius:4px;background:transparent}.hide-button:hover{background:#fff6}.hide-button lucide-icon{display:flex}.empty{padding:24px;color:#52665a}dialog{color:var(--plan-ink);background:#fff;width:440px;max-width:calc(100vw - 32px);max-height:85dvh;border:1px solid var(--plan-line);border-radius:8px;padding:24px;box-shadow:0 20px 70px #102f2633}dialog::backdrop{background:#10251c70}.dialog-header{display:flex;justify-content:space-between;gap:16px;align-items:start;margin-bottom:20px}h3{margin:0;font-size:1.15rem;overflow-wrap:anywhere}.dialog-header p{color:#52665a;margin:8px 0 0;font-size:.85rem}.close-button{border:0;background:#edf2ee;border-radius:4px;font-size:1.5rem;flex:0 0 36px;height:36px}.subject-list{display:grid;gap:8px}.subject-option{display:flex;align-items:center;gap:12px;border:1px solid var(--plan-line);background:#fff;padding:14px;text-align:left;border-radius:4px;overflow-wrap:anywhere}.subject-option:hover{background:#edf3ee}.swatch{width:16px;height:16px;flex:0 0 16px;border-radius:3px;border:1px solid #0002}.remove-button{border:1px solid #bca3a0;border-radius:4px;background:#fff;color:#91362b;padding:10px 14px;margin-top:20px}.visually-hidden{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip-path:inset(50%);white-space:nowrap}@media(max-width:480px){.plan-header{align-items:stretch}.category,select{width:100%}dialog{padding:18px}}\n"], dependencies: [{ kind: "ngmodule", type: LucideAngularModule }, { kind: "component", type: i1.LucideAngularComponent, selector: "lucide-angular, lucide-icon, i-lucide, span-lucide", inputs: ["class", "name", "img", "color", "absoluteStrokeWidth", "size", "strokeWidth"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: PlanLearn, decorators: [{
            type: Component,
            args: [{ selector: 'lib-plan-learn', imports: [LucideAngularModule], changeDetection: ChangeDetectionStrategy.OnPush, host: { '[class.with-periods]': 'showPeriods()' }, template: "<header class=\"plan-header\">\r\n  <h2>{{ planName() }}</h2>\r\n  <label class=\"category\">Kategorie\r\n    <select #categorySelect [value]=\"categoryId()\" (change)=\"setCategory(categorySelect.value)\">\r\n      <option value=\"\">Alle Kategorien</option>\r\n      @for (category of categories(); track category.id) {\r\n        <option [value]=\"category.id\">{{ category.name }}</option>\r\n      }\r\n    </select>\r\n  </label>\r\n</header>\r\n\r\n<div class=\"schedule\" tabindex=\"0\" role=\"region\" [attr.aria-label]=\"planName()\"\r\n  [class.dragging]=\"dragging()\" (pointerdown)=\"startScroll($event)\"\r\n  (pointermove)=\"moveScroll($event)\" (pointerup)=\"endScroll($event)\"\r\n  (pointercancel)=\"endScroll($event)\" (lostpointercapture)=\"endScroll($event)\">\r\n  <table [style.width.px]=\"days().length * 140 + (showPeriods() ? 120 : 72)\">\r\n    <caption class=\"visually-hidden\">{{ planName() }}</caption>\r\n    <colgroup>\r\n      @if (showPeriods()) { <col class=\"period-col\" /> }\r\n      <col class=\"time-col\" />\r\n      @for (day of days(); track day.id) { <col /> }\r\n    </colgroup>\r\n    <thead>\r\n      <tr>\r\n        @if (showPeriods()) { <th class=\"period\" scope=\"col\">Stunde</th> }\r\n        <th class=\"time\" scope=\"col\">Zeit</th>\r\n        @for (day of days(); track day.id) {\r\n          <th class=\"day\" scope=\"col\" [style.--day-color]=\"day.color ?? '#d9e7df'\">{{ day.name }}</th>\r\n        }\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      @for (row of rows(); track row.slot.id) {\r\n        <tr>\r\n          @if (showPeriods()) { <th class=\"period\" scope=\"row\">{{ row.period }}</th> }\r\n          <th class=\"time\" [attr.scope]=\"showPeriods() ? null : 'row'\">\r\n            <span>{{ row.slot.start }}</span><span class=\"end-time\">{{ row.slot.end }}</span>\r\n          </th>\r\n          @for (cell of row.cells; track cell.day.id) {\r\n            <td>\r\n              <div class=\"cell-content\" [class.occupied]=\"!!cell.entry\"\r\n                [style.--subject-color]=\"cell.subject?.color ?? '#ccd6d0'\">\r\n                <button type=\"button\" class=\"cell-button\"\r\n                  [title]=\"cell.subject?.name ?? ''\"\r\n                  [attr.aria-label]=\"cell.day.name + ', ' + row.slot.start + ' - ' + row.slot.end + ': ' + (cell.subject?.name ?? 'Fach auswaehlen')\"\r\n                  (click)=\"openCell(cell.day.id, row.slot.id)\">\r\n                  @if (cell.entry) {\r\n                    <span class=\"subject-name\">{{ cell.subject?.name ?? 'Unbekanntes Fach' }}</span>\r\n                  } @else {\r\n                    <span class=\"add-mark\" aria-hidden=\"true\">+</span>\r\n                  }\r\n                </button>\r\n                @if (cell.entry; as entry) {\r\n                  <button type=\"button\" class=\"hide-button\"\r\n                    [title]=\"entry.hidden ? 'Einblenden' : 'Ausblenden'\"\r\n                    [attr.aria-label]=\"(cell.subject?.name ?? 'Fach') + (entry.hidden ? ' einblenden, ' : ' ausblenden, ') + cell.day.name + ', ' + row.slot.start\"\r\n                    [attr.aria-pressed]=\"!!entry.hidden\"\r\n                    (click)=\"toggleVisibility(entry)\">\r\n                    <lucide-icon [img]=\"entry.hidden ? showIcon : hideIcon\" [size]=\"16\" aria-hidden=\"true\" />\r\n                  </button>\r\n                }\r\n              </div>\r\n            </td>\r\n          }\r\n        </tr>\r\n      } @empty {\r\n        <tr><td class=\"empty\" [attr.colspan]=\"days().length + (showPeriods() ? 2 : 1)\">Keine Zeitbereiche vorhanden.</td></tr>\r\n      }\r\n    </tbody>\r\n  </table>\r\n</div>\r\n\r\n<dialog #picker aria-label=\"Fach auswaehlen\" (close)=\"activeCell.set(null)\"\r\n  (keydown.escape)=\"closePicker(); $event.preventDefault()\">\r\n  <form method=\"dialog\" class=\"dialog-header\">\r\n    <div><h3>Fach auswaehlen</h3><p>{{ activeLabel() }}</p></div>\r\n    <button class=\"close-button\" aria-label=\"Auswahl schliessen\" title=\"Schliessen\">&times;</button>\r\n  </form>\r\n  <div class=\"subject-list\">\r\n    @for (subject of availableSubjects(); track subject.id) {\r\n      <button type=\"button\" class=\"subject-option\" (click)=\"chooseSubject(subject.id)\">\r\n        <span class=\"swatch\" [style.background]=\"subject.color\" aria-hidden=\"true\"></span>\r\n        {{ subject.name }}\r\n      </button>\r\n    } @empty {\r\n      <p class=\"empty\">Keine Faecher in dieser Kategorie.</p>\r\n    }\r\n  </div>\r\n  @if (activeEntry()) {\r\n    <button type=\"button\" class=\"remove-button\" (click)=\"chooseSubject(null)\">Eintrag entfernen</button>\r\n  }\r\n</dialog>\r\n", styles: [":host{--plan-ink: #20352b;--plan-line: #d3ddd6;--plan-accent: #1b654b;display:block;width:fit-content;max-width:100%;min-width:0;color:var(--plan-ink);font-family:inherit}*{box-sizing:border-box}button,select{font:inherit;color:inherit}button{cursor:pointer}button:focus-visible,select:focus-visible,.schedule:focus-visible{outline:3px solid var(--plan-accent);outline-offset:-3px}.plan-header{display:flex;flex-wrap:wrap;align-items:end;gap:16px;justify-content:space-between;margin-bottom:20px}h2{font-size:1.5rem;margin:0;overflow-wrap:anywhere}.category{display:grid;gap:6px;font-size:.85rem;font-weight:600;max-width:100%}select{background:#fff;border:1px solid #879c8f;border-radius:4px;padding:10px 28px 10px 8px;width:180px;max-width:100%}.schedule{overflow:auto;max-height:var(--plan-max-height, 72vh);border:1px solid var(--plan-line);background:#fff;isolation:isolate}.schedule{scrollbar-color:#708b7b #e4ece6;scrollbar-width:auto;touch-action:pan-x pan-y}.schedule::-webkit-scrollbar{height:14px;width:14px}.schedule::-webkit-scrollbar-track{background:#e4ece6}.schedule::-webkit-scrollbar-thumb{background:#708b7b;border:3px solid #e4ece6;border-radius:7px}.schedule::-webkit-scrollbar-thumb:hover{background:#405f4c}.schedule.dragging,.schedule.dragging button{cursor:grabbing;-webkit-user-select:none;user-select:none}table{width:100%;table-layout:fixed;border-spacing:0;font-size:.9rem}.period-col{width:48px}.time-col{width:72px}th,td{border-right:1px solid var(--plan-line);border-bottom:1px solid var(--plan-line)}tr>:last-child{border-right:0}tbody tr:last-child>*{border-bottom:0}thead th{position:sticky;top:0;z-index:3;height:52px;background:#eef3ef;padding:10px 6px;overflow-wrap:anywhere}thead .day{font-weight:500}.period,.time{position:sticky;z-index:2;background:#f7f9f7;text-align:center;padding:10px 4px}.period{left:0;font-weight:600;font-variant-numeric:tabular-nums}.time{left:0;font-weight:500;font-variant-numeric:tabular-nums;box-shadow:2px 0 0 var(--plan-line)}:host.with-periods .time{left:48px}thead .period,thead .time{z-index:4;background:#eef3ef}thead .period{font-size:.75rem;white-space:nowrap}.time span{display:block;line-height:1.4}.end-time{color:#607066;margin-top:5px}td{padding:6px 3px;vertical-align:middle}.cell-content{height:calc(2.8em + 5px);display:flex;align-items:center;border-radius:4px}.cell-content.occupied{background:var(--subject-color);color:#17251d}.cell-button{display:flex;align-items:center;min-width:0;height:100%;border:0;background:transparent;padding:0 5px;flex:1;text-align:left;border-radius:4px}.cell-button:hover{background:#0000000a}.subject-name{font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.add-mark{display:block;width:100%;text-align:center;color:#687c70;font-size:1.4rem}.hide-button{display:grid;place-items:center;flex:0 0 24px;width:24px;height:28px;margin-right:2px;padding:0;border:0;border-radius:4px;background:transparent}.hide-button:hover{background:#fff6}.hide-button lucide-icon{display:flex}.empty{padding:24px;color:#52665a}dialog{color:var(--plan-ink);background:#fff;width:440px;max-width:calc(100vw - 32px);max-height:85dvh;border:1px solid var(--plan-line);border-radius:8px;padding:24px;box-shadow:0 20px 70px #102f2633}dialog::backdrop{background:#10251c70}.dialog-header{display:flex;justify-content:space-between;gap:16px;align-items:start;margin-bottom:20px}h3{margin:0;font-size:1.15rem;overflow-wrap:anywhere}.dialog-header p{color:#52665a;margin:8px 0 0;font-size:.85rem}.close-button{border:0;background:#edf2ee;border-radius:4px;font-size:1.5rem;flex:0 0 36px;height:36px}.subject-list{display:grid;gap:8px}.subject-option{display:flex;align-items:center;gap:12px;border:1px solid var(--plan-line);background:#fff;padding:14px;text-align:left;border-radius:4px;overflow-wrap:anywhere}.subject-option:hover{background:#edf3ee}.swatch{width:16px;height:16px;flex:0 0 16px;border-radius:3px;border:1px solid #0002}.remove-button{border:1px solid #bca3a0;border-radius:4px;background:#fff;color:#91362b;padding:10px 14px;margin-top:20px}.visually-hidden{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip-path:inset(50%);white-space:nowrap}@media(max-width:480px){.plan-header{align-items:stretch}.category,select{width:100%}dialog{padding:18px}}\n"] }]
        }], propDecorators: { planName: [{ type: i0.Input, args: [{ isSignal: true, alias: "planName", required: false }] }], days: [{ type: i0.Input, args: [{ isSignal: true, alias: "days", required: false }] }], timeSlots: [{ type: i0.Input, args: [{ isSignal: true, alias: "timeSlots", required: false }] }], categories: [{ type: i0.Input, args: [{ isSignal: true, alias: "categories", required: false }] }], subjects: [{ type: i0.Input, args: [{ isSignal: true, alias: "subjects", required: false }] }], entries: [{ type: i0.Input, args: [{ isSignal: true, alias: "entries", required: false }] }], showPeriods: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPeriods", required: false }] }], entryChange: [{ type: i0.Output, args: ["entryChange"] }], hideRequested: [{ type: i0.Output, args: ["hideRequested"] }], picker: [{ type: i0.ViewChild, args: ['picker', { isSignal: true }] }] } });

/*
 * Public API Surface of plan-learn
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PlanLearn };
//# sourceMappingURL=plan-learn.mjs.map
