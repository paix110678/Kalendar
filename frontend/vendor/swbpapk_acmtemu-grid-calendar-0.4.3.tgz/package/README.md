# @swbpapk_acmtemu/grid-calendar

Private Angular calendar grid package published to GitHub Packages. It provides date/resource columns, a shared time axis, date-only checklist tasks, five-minute grid-line anchoring, event drawing, drag-and-drop, and resizing. The library does not make HTTP requests; each host application owns persistence for events, tasks, and comments.

## Requirements

- Angular `^21.2.0`
- Angular CDK `^21.2.0`

## Install in another product

Add this to the consuming project's `.npmrc` (do not commit a literal token):

```ini
@swbpapk_acmtemu:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_PACKAGES_TOKEN}
```

Set `GITHUB_PACKAGES_TOKEN` in the developer/CI environment to a GitHub classic personal access token with `read:packages` and access to this private repository/package. In GitHub Actions, prefer `GITHUB_TOKEN` with `packages: read` and grant the consuming repository access to the package.

### Grant a different GitHub account access

After the first package release, open the package page under the owner's GitHub profile or organization, then open **Package settings → Manage access**. Grant the consuming account at least **Read** access. If the package inherits access from the repository, either grant that account repository read access or configure granular package permissions and grant access to the account/package directly. Do not share the publishing token.

For local development in the consuming account, create a classic personal access token with `read:packages` and access to the package, then expose it as `GITHUB_PACKAGES_TOKEN` for npm. For that account's GitHub Actions, store the token as an Actions secret and use it as `NODE_AUTH_TOKEN`; its default `GITHUB_TOKEN` cannot read this package until the consuming repository has been granted package Actions access.

Then install:

```bash
npm install @swbpapk_acmtemu/grid-calendar
```

The `grid-calendar/mock-backend` secondary entry point is also published in the same package. It is an in-memory demo/test backend, not a production persistence layer.

## Basic use

```typescript
import { Component, signal } from '@angular/core';
import { CalendarEvent, CalendarTask, GridCalendar } from '@swbpapk_acmtemu/grid-calendar';

@Component({
  standalone: true,
  imports: [GridCalendar],
  template: `
    <glc-grid-calendar
      [events]="events()"
      [tasks]="tasks()"
      [resources]="resources"
      viewMode="week"
      columnMode="resource"
      (eventsChange)="events.set($event)"
      (tasksChange)="tasks.set($event)"
      (eventCreateRequested)="createInBackend($event)"
      (eventEditRequested)="openEditor($event)"
    />
  `,
})
export class CalendarPage {
  readonly events = signal<CalendarEvent[]>([]);
  readonly tasks = signal<CalendarTask[]>([]);
  readonly resources = [];

  createInBackend(draft: CalendarEvent): void {
    // Persist the draft in the host app, then replace its negative ID with the server ID.
  }

  openEditor(eventId: number): void {
    // Load/edit the event in the host app.
  }
}
```

See the repository's `docs/USAGE.md` for inputs, outputs, models, interaction and theming details.

## Upgrading from 0.0.2 to 0.1.0

This release contains breaking changes:

- The internal components (`EventItemComponent`, `DayColumnComponent`, `GridHeaderComponent`, `TimeAxisComponent`, `TaskListColumnComponent`) are no longer exported. Use `GridCalendar`.
- `grid-calendar/mock-backend`: `DEFAULT_MOCK_EVENTS`, `DEFAULT_MOCK_TASKS` and `DEFAULT_MOCK_RESOURCES` were replaced by `createMockEvents()`, `createMockTasks()` and `createMockResources()`. The interceptor now answers 400/404/405 and matches `basePath` exactly.
- `GridTheme`: `slotHeightPx` was removed; new keys such as `colorText`, `colorOnEvent`, `colorScheme` and `eventRadius` were added.
- Events are drawn as a tinted card with an accent bar; `event.color` and `resource.color` are accents only. `--glc-color-on-event` now defaults to the theme text color.

New: `labels` input, pointer/touch support for drawing and resizing, keyboard resize (`Alt+Arrow`), `toDateKey()`, a dark-theme-ready surface and responsive header/event/task layouts.

## Release

The current package version is `0.3.0`. The GitHub Actions workflow publishes only when a tag matching `grid-calendar-v*` is pushed, and the tag version must equal `projects/grid-calendar/package.json`'s version. To publish this version:

```bash
git tag grid-calendar-v0.3.0
git push origin grid-calendar-v0.3.0
```

To create a local installable archive without publishing it, build the library and run:

```bash
npm pack ./dist/grid-calendar
```

The workflow builds the Angular package and publishes `dist/grid-calendar` to `https://npm.pkg.github.com` using the repository's `GITHUB_TOKEN`. Keep the repository/package private and verify package access under the GitHub package settings before granting consumer repositories access.
