import * as i0 from '@angular/core';
import { inject, Injectable, InjectionToken, makeEnvironmentProviders } from '@angular/core';
import { toDateKey } from '@swbpapk_acmtemu/grid-calendar';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { throwError, of, delay } from 'rxjs';

/** In-Memory-Datenhaltung für das simulierte Backend. Kein echter Netzwerk-/Datenbankzugriff. */
class MockBackendStore {
    config = inject(MOCK_BACKEND_CONFIG);
    // Tiefe Kopien: weder Seed noch Antworten teilen Objekte mit dem Aufrufer, wie bei einer echten Serialisierung.
    events = structuredClone(this.config.events);
    tasks = structuredClone(this.config.tasks);
    resources = structuredClone(this.config.resources);
    getEvents() {
        return structuredClone(this.events);
    }
    getResources() {
        return structuredClone(this.resources);
    }
    getTasks() {
        return structuredClone(this.tasks);
    }
    createTask(task) {
        const created = {
            id: this.generateTaskId(),
            name: task.name ?? '',
            date: task.date ?? toDateKey(new Date()),
            resourceId: task.resourceId ?? this.resources[0]?.id ?? 0,
            parentId: task.parentId,
            completed: task.completed ?? false,
            comments: task.comments ?? [],
        };
        this.tasks.push(structuredClone(created));
        return structuredClone(created);
    }
    updateTask(id, patch) {
        const index = this.tasks.findIndex((task) => task.id === id);
        if (index === -1)
            return undefined;
        const updated = { ...this.tasks[index], ...structuredClone(patch), id };
        this.tasks[index] = updated;
        return structuredClone(updated);
    }
    deleteTask(id) {
        const index = this.tasks.findIndex((task) => task.id === id);
        if (index === -1)
            return false;
        this.tasks.splice(index, 1);
        this.tasks = this.tasks.filter((task) => task.parentId !== id);
        return true;
    }
    createEvent(event) {
        const created = {
            id: this.generateId(),
            title: event.title ?? '',
            shortTitle: event.shortTitle,
            start: event.start ?? new Date().toISOString(),
            end: event.end ?? new Date().toISOString(),
            resourceId: event.resourceId,
            category: event.category,
            color: event.color,
            imageUrl: event.imageUrl,
            meta: event.meta,
        };
        this.events.push(structuredClone(created));
        return structuredClone(created);
    }
    updateEvent(id, patch) {
        const index = this.events.findIndex((event) => event.id === id);
        if (index === -1) {
            return undefined;
        }
        const updated = { ...this.events[index], ...structuredClone(patch), id };
        this.events[index] = updated;
        return structuredClone(updated);
    }
    deleteEvent(id) {
        const index = this.events.findIndex((event) => event.id === id);
        if (index === -1) {
            return false;
        }
        this.events.splice(index, 1);
        return true;
    }
    generateId() {
        const positiveIds = this.events.map((event) => event.id).filter((id) => id > 0);
        return Math.max(0, ...positiveIds) + 1;
    }
    generateTaskId() {
        const positiveIds = this.tasks.map((task) => task.id).filter((id) => id > 0);
        return Math.max(0, ...positiveIds) + 1;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: MockBackendStore, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: MockBackendStore });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: MockBackendStore, decorators: [{
            type: Injectable
        }] });

/** ISO-String für den Tag von `now` um die angegebene Uhrzeit. */
function todayAt(now, hours, minutes = 0) {
    const date = new Date(now);
    date.setHours(hours, minutes, 0, 0);
    return date.toISOString();
}
function createMockResources() {
    return [
        { id: 1, name: 'Anna', color: '#d9368f' },
        { id: 2, name: 'Ben', color: '#2f9e44' },
    ];
}
/** Seed-Events relativ zu `now` (Default: jetzt), damit sie beim Start immer "heute" liegen. */
function createMockEvents(now = new Date()) {
    return [
        {
            id: 1,
            title: 'Kickoff Meeting',
            shortTitle: 'KOM',
            start: todayAt(now, 9),
            end: todayAt(now, 10),
            color: '#4a90d9',
            resourceId: 1,
        },
        {
            id: 2,
            title: 'Lunch',
            shortTitle: 'LCH',
            start: todayAt(now, 12),
            end: todayAt(now, 13),
            color: '#e0a030',
            resourceId: 2,
        },
    ];
}
/** Seed-Tasks für den Tag von `now` (Default: jetzt). */
function createMockTasks(now = new Date()) {
    const date = toDateKey(now);
    return [
        {
            id: 1,
            name: 'Unterlagen vorbereiten',
            date,
            resourceId: 1,
            completed: false,
            comments: [{ id: 1, text: 'Bitte aktuelle Zahlen verwenden.', createdAt: now.toISOString(), author: 'Demo' }],
        },
        { id: 2, name: 'Agenda abstimmen', date, resourceId: 1, completed: false },
        { id: 3, name: 'Raum vorbereiten', date, resourceId: 1, parentId: 2, completed: false },
        { id: 4, name: 'Teilnehmerliste versenden', date, resourceId: 1, parentId: 2, completed: false },
    ];
}

/** Frische Defaults pro Aufruf, damit Seed-Daten nicht beim Import eingefroren werden. */
function createDefaultConfig() {
    return {
        events: createMockEvents(),
        tasks: createMockTasks(),
        resources: createMockResources(),
        latencyMs: 300,
        basePath: '/api',
    };
}
const MOCK_BACKEND_CONFIG = new InjectionToken('MOCK_BACKEND_CONFIG', {
    factory: createDefaultConfig,
});
/**
 * Registriert das simulierte Backend (Seed-Daten + In-Memory-Store). Der eigentliche Interceptor
 * muss zusätzlich per `provideHttpClient(withInterceptors([mockEventsInterceptor]))` aktiviert werden.
 */
function provideMockBackend(config = {}) {
    return makeEnvironmentProviders([
        { provide: MOCK_BACKEND_CONFIG, useValue: { ...createDefaultConfig(), ...config } },
        MockBackendStore,
    ]);
}

/** Simuliert /api/events, /api/tasks und /api/resources über einen In-Memory-Store, keine echten Netzwerkaufrufe. */
const mockEventsInterceptor = (req, next) => {
    const config = inject(MOCK_BACKEND_CONFIG);
    const basePath = config.basePath;
    if (req.url !== basePath && !req.url.startsWith(`${basePath}/`)) {
        return next(req);
    }
    const store = inject(MockBackendStore);
    const result = handleRequest(req, store, basePath);
    const result$ = result instanceof HttpErrorResponse ? throwError(() => result) : of(result);
    return result$.pipe(delay(config.latencyMs));
};
function handleRequest(req, store, basePath) {
    const fail = (status, statusText) => new HttpErrorResponse({ status, statusText, url: req.url });
    const collections = {
        events: {
            list: () => store.getEvents(),
            create: (body) => store.createEvent(body),
            update: (id, body) => store.updateEvent(id, body),
            remove: (id) => store.deleteEvent(id),
        },
        tasks: {
            list: () => store.getTasks(),
            create: (body) => store.createTask(body),
            update: (id, body) => store.updateTask(id, body),
            remove: (id) => store.deleteTask(id),
        },
        resources: { list: () => store.getResources() },
    };
    const [, name, rawId, ...extra] = req.url.slice(basePath.length).split('/');
    const collection = Object.hasOwn(collections, name) ? collections[name] : undefined;
    if (!collection || extra.length > 0) {
        return fail(404, 'Not Found');
    }
    if (rawId === undefined) {
        if (req.method === 'GET') {
            return new HttpResponse({ status: 200, body: collection.list() });
        }
        if (req.method === 'POST' && collection.create) {
            return isRecord(req.body)
                ? new HttpResponse({ status: 201, body: collection.create(req.body) })
                : fail(400, 'Bad Request');
        }
        return fail(405, 'Method Not Allowed');
    }
    const id = Number(rawId);
    if (!Number.isInteger(id) || id <= 0) {
        return fail(404, 'Not Found');
    }
    if (req.method === 'PATCH' && collection.update) {
        if (!isRecord(req.body)) {
            return fail(400, 'Bad Request');
        }
        const updated = collection.update(id, req.body);
        return updated ? new HttpResponse({ status: 200, body: updated }) : fail(404, 'Not Found');
    }
    if (req.method === 'DELETE' && collection.remove) {
        return collection.remove(id) ? new HttpResponse({ status: 204 }) : fail(404, 'Not Found');
    }
    return fail(405, 'Method Not Allowed');
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Generated bundle index. Do not edit.
 */

export { MOCK_BACKEND_CONFIG, MockBackendStore, createMockEvents, createMockResources, createMockTasks, mockEventsInterceptor, provideMockBackend };
//# sourceMappingURL=swbpapk_acmtemu-grid-calendar-mock-backend.mjs.map
