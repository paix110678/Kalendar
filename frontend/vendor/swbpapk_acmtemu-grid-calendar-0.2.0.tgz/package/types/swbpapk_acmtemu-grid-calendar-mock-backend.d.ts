import * as i0 from '@angular/core';
import { InjectionToken, EnvironmentProviders } from '@angular/core';
import { CalendarEvent, CalendarTask, CalendarResource } from '@swbpapk_acmtemu/grid-calendar';
import { HttpInterceptorFn } from '@angular/common/http';

/** Konfiguration des simulierten Backends: Event-/Task-Seeds, kuenstliche Latenz, Basis-Pfad. */
interface MockBackendConfig {
    events?: CalendarEvent[];
    tasks?: CalendarTask[];
    resources?: CalendarResource[];
    latencyMs?: number;
    basePath?: string;
}
declare const MOCK_BACKEND_CONFIG: InjectionToken<Required<MockBackendConfig>>;
/**
 * Registriert das simulierte Backend (Seed-Daten + In-Memory-Store). Der eigentliche Interceptor
 * muss zusätzlich per `provideHttpClient(withInterceptors([mockEventsInterceptor]))` aktiviert werden.
 */
declare function provideMockBackend(config?: MockBackendConfig): EnvironmentProviders;

/** In-Memory-Datenhaltung für das simulierte Backend. Kein echter Netzwerk-/Datenbankzugriff. */
declare class MockBackendStore {
    private readonly config;
    private events;
    private tasks;
    private readonly resources;
    getEvents(): CalendarEvent[];
    getResources(): CalendarResource[];
    getTasks(): CalendarTask[];
    createTask(task: Partial<CalendarTask>): CalendarTask;
    updateTask(id: number, patch: Partial<CalendarTask>): CalendarTask | undefined;
    deleteTask(id: number): boolean;
    isEventLocked(id: number): boolean;
    createEvent(event: Partial<CalendarEvent>): CalendarEvent;
    updateEvent(id: number, patch: Partial<CalendarEvent>): CalendarEvent | undefined;
    deleteEvent(id: number): boolean;
    private generateId;
    private generateTaskId;
    static ɵfac: i0.ɵɵFactoryDeclaration<MockBackendStore, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MockBackendStore>;
}

/** Simuliert /api/events, /api/tasks und /api/resources über einen In-Memory-Store, keine echten Netzwerkaufrufe. */
declare const mockEventsInterceptor: HttpInterceptorFn;

declare function createMockResources(): CalendarResource[];
/** Seed-Events relativ zu `now` (Default: jetzt), damit sie beim Start immer "heute" liegen. */
declare function createMockEvents(now?: Date): CalendarEvent[];
/** Seed-Tasks für den Tag von `now` (Default: jetzt). */
declare function createMockTasks(now?: Date): CalendarTask[];

export { MOCK_BACKEND_CONFIG, MockBackendStore, createMockEvents, createMockResources, createMockTasks, mockEventsInterceptor, provideMockBackend };
export type { MockBackendConfig };
