import * as i0 from '@angular/core';
import { Injectable, signal, inject, DestroyRef, computed, linkedSignal, ElementRef, NgZone, ChangeDetectorRef, input, output, viewChild, afterNextRender, ChangeDetectionStrategy, Component, model, effect } from '@angular/core';
import { CdkDrag, CdkDragPreview, CdkDropList, CdkDropListGroup } from '@angular/cdk/drag-drop';
import { DatePipe } from '@angular/common';
import * as i1 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';

const DEFAULT_GRID_LINE_INTERVAL_MINUTES = 5;
const DEFAULT_GRID_CONFIG = {
    workingHoursStart: 8,
    workingHoursEnd: 18,
    pixelsPerHour: 60,
};

// Zeilenhöhen der Task-Liste in px; müssen zum SCSS von TaskListColumnComponent passen.
const TASK_ROOT_ROW_HEIGHT_PX = 38;
const TASK_CHILD_ROW_HEIGHT_PX = 35;
const TASK_GROUP_GAP_PX = 6;
const TASK_MODE_TOP_INSET_PX = 8;
const TASK_RESOURCE_FRAME_BOTTOM_PX = 3;
// Muss mit den Gaps in grid-calendar.scss übereinstimmen.
const DAY_GROUP_GAP_PX = 8;
const DAY_COLUMN_GAP_PX = 3;
const DAY_COUNT_BY_VIEW_MODE = {
    day: 1,
    '3day': 3,
    week: 7,
};
class GridLayoutService {
    /** Alter am Geburtstag im dargestellten Kalenderjahr. */
    birthdayAge(birthday, date) {
        return date.getFullYear() - Number(birthday.birthDate.slice(0, 4));
    }
    birthdaysOnDate(birthdays, date) {
        const monthDay = `${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        return birthdays.filter((birthday) => birthday.birthDate.slice(5) === monthDay);
    }
    /** Liefert die sichtbaren Tage als Mitternachts-Daten, beginnend bei anchorDate. */
    computeVisibleRange(viewMode, anchorDate) {
        const start = this.startOfDay(anchorDate);
        const count = DAY_COUNT_BY_VIEW_MODE[viewMode];
        return Array.from({ length: count }, (_, i) => this.addDays(start, i));
    }
    /** Verschiebt den Anker um die Länge der Ansicht (Tag 1, 3 Tage 3, Woche 7 Tage). */
    shiftAnchor(anchorDate, viewMode, direction) {
        return this.addDays(this.startOfDay(anchorDate), direction * DAY_COUNT_BY_VIEW_MODE[viewMode]);
    }
    /** Pixel-Offset eines Zeitpunkts relativ zum Spaltenanfang (Arbeitszeit-Fenster). */
    timeToOffset(time, config) {
        const minutesSinceStart = time.getHours() * 60 + time.getMinutes() - config.workingHoursStart * 60;
        const totalMinutes = (config.workingHoursEnd - config.workingHoursStart) * 60;
        const clamped = Math.min(Math.max(minutesSinceStart, 0), totalMinutes);
        return (clamped / 60) * config.pixelsPerHour;
    }
    /** Liegt der Zeitpunkt innerhalb des Arbeitszeit-Fensters? Für die "Jetzt"-Linie: sonst würde
     * timeToOffset auf den Rand klemmen und eine falsche Uhrzeit an der falschen Stelle anzeigen. */
    isWithinWorkingHours(time, config) {
        const minutes = time.getHours() * 60 + time.getMinutes();
        return minutes >= config.workingHoursStart * 60 && minutes <= config.workingHoursEnd * 60;
    }
    /**
     * Layoutet alle Events einer Spalte (ein Tag bzw. ein Tag einer Person): auf den Tag
     * geclippt. Jeder Event nutzt die volle Spaltenbreite (eine Spalte gehört bereits genau
     * einem Tag/einer Person) — kein Nebeneinander-Splitting bei zeitlicher Überlappung.
     */
    layoutEventsForColumn(events, columnDate, config) {
        const dayStart = this.startOfDay(columnDate);
        const dayEnd = this.endOfDay(columnDate);
        return events
            .map((event) => ({
            event,
            start: this.clamp(new Date(event.start), dayStart, dayEnd),
            end: this.clamp(new Date(event.end), dayStart, dayEnd),
        }))
            .filter(({ start, end }) => end > start)
            .map(({ event, start, end }) => {
            const topPx = this.timeToOffset(start, config);
            return {
                event,
                topPx,
                heightPx: this.timeToOffset(end, config) - topPx,
                leftPercent: 0,
                widthPercent: 100,
            };
        })
            .filter((layout) => layout.heightPx > 0);
    }
    /** Die Hilfslinie, die einer Position (px ab Spaltenanfang) am nächsten liegt. */
    nearestGridLine(lines, topPx) {
        return lines.reduce((best, line) => Math.abs(line.offsetPx - topPx) < Math.abs(best.offsetPx - topPx) ? line : best);
    }
    /**
     * Neue Hilfslinie für die bewegte Kante beim Resize: rastet auf die nächste Linie zu `edgePx`,
     * hält aber mindestens eine Linie Abstand zur anderen Kante (`otherLine`).
     */
    resizeEdgeLine(lines, edge, edgePx, otherLine) {
        const index = lines.indexOf(this.nearestGridLine(lines, edgePx));
        const otherIndex = lines.indexOf(otherLine);
        return edge === 'bottom'
            ? (lines[Math.max(index, otherIndex + 1)] ?? lines[lines.length - 1])
            : (lines[Math.min(index, otherIndex - 1)] ?? lines[0]);
    }
    /** Gezeichneter Bereich von Linie `a` zu Linie `b` in Linienreihenfolge, mindestens eine Linie hoch. */
    drawRange(lines, a, b) {
        const last = lines.length - 1;
        let from = Math.min(lines.indexOf(a), lines.indexOf(b));
        let to = Math.max(lines.indexOf(a), lines.indexOf(b));
        if (from === to) {
            to = Math.min(to + 1, last);
            from = Math.max(0, Math.min(from, to - 1));
        }
        return [lines[from], lines[to]];
    }
    /** Zeitpunkt einer Hilfslinie an einem bestimmten Tag. */
    timeOnGridLine(line, columnDate) {
        const result = this.startOfDay(columnDate);
        result.setHours(line.hours, line.minutes, 0, 0);
        return result;
    }
    /** Uhrzeit als 24-Stunden-Text `HH:mm` (lokale Zeit, unabhängig von der Browser-Locale). */
    formatTime(time) {
        return this.formatClock(time.getHours(), time.getMinutes());
    }
    /** Beschriftung einer Hilfslinie als `HH:mm`. */
    formatGridLineTime(line) {
        return this.formatClock(line.hours, line.minutes);
    }
    /** Vergleicht zwei Zeitpunkte auf Kalendertag-Gleichheit (unabhängig von Uhrzeit). */
    isSameDay(a, b) {
        return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
    }
    /** Berührende Kanten (Ende = Start) gelten nicht als Überlappung. */
    overlapsAny(candidate, others) {
        const start = new Date(candidate.start).getTime();
        const end = new Date(candidate.end).getTime();
        return others.some((other) => start < new Date(other.end).getTime() && new Date(other.start).getTime() < end);
    }
    /** ISO-8601-Kalenderwoche (die Woche mit dem ersten Donnerstag des Jahres ist KW 1). */
    getIsoWeekNumber(date) {
        const target = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        const dayNumber = (target.getUTCDay() + 6) % 7; // Montag=0 .. Sonntag=6
        target.setUTCDate(target.getUTCDate() - dayNumber + 3); // Donnerstag derselben Woche
        const firstThursday = new Date(Date.UTC(target.getUTCFullYear(), 0, 4));
        const firstDayNumber = (firstThursday.getUTCDay() + 6) % 7;
        firstThursday.setUTCDate(firstThursday.getUTCDate() - firstDayNumber + 3);
        return 1 + Math.round((target.getTime() - firstThursday.getTime()) / (7 * 24 * 60 * 60 * 1000));
    }
    /** Pixel-Offsets dezentere Hilfslinien im Abstand von gridLineIntervalMinutes (Default 5). Volle Stunden sind als isHour markiert. */
    computeGridLines(config) {
        const configured = config.gridLineIntervalMinutes;
        const interval = configured !== undefined && Number.isFinite(configured) && configured > 0 ? configured : DEFAULT_GRID_LINE_INTERVAL_MINUTES;
        const totalMinutes = (config.workingHoursEnd - config.workingHoursStart) * 60;
        if (totalMinutes <= 0) {
            return [{ offsetPx: 0, isHour: true, hours: config.workingHoursStart, minutes: 0 }];
        }
        const lines = [];
        for (let minutes = 0; minutes <= totalMinutes; minutes += interval) {
            const minutesOfDay = config.workingHoursStart * 60 + minutes;
            lines.push({
                offsetPx: (minutes / 60) * config.pixelsPerHour,
                isHour: minutes % 60 === 0,
                hours: Math.floor(minutesOfDay / 60),
                minutes: minutesOfDay % 60,
            });
        }
        if (lines[lines.length - 1]?.offsetPx !== totalMinutes / 60 * config.pixelsPerHour) {
            lines.push({
                offsetPx: (totalMinutes / 60) * config.pixelsPerHour,
                isHour: config.workingHoursEnd % 1 === 0,
                hours: config.workingHoursEnd,
                minutes: 0,
            });
        }
        return lines;
    }
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln (für explizite Höhen von Zeitachse/Spalten). */
    computeContentHeight(config) {
        return (config.workingHoursEnd - config.workingHoursStart) * config.pixelsPerHour;
    }
    /**
     * Staucht/streckt die Stunden so, dass das Arbeitszeit-Fenster exakt in `availableHeightPx`
     * passt (kein Scrollen nötig). Ohne bekannte verfügbare Höhe (<= 0) bleibt config.pixelsPerHour
     * unverändert.
     */
    computeEffectivePixelsPerHour(config, availableHeightPx) {
        const totalHours = config.workingHoursEnd - config.workingHoursStart;
        if (totalHours <= 0 || availableHeightPx <= 0) {
            return config.pixelsPerHour;
        }
        return availableHeightPx / totalHours;
    }
    /** Geschätzte Höhe einer Task-Spalte: sichtbare Hauptaufgaben samt Unteraufgaben, Abstände und Rahmen. */
    estimateTaskColumnHeight(tasks, showCompleted) {
        const childrenByParent = new Map();
        for (const task of tasks) {
            if (task.parentId === undefined)
                continue;
            const children = childrenByParent.get(task.parentId) ?? [];
            children.push(task);
            childrenByParent.set(task.parentId, children);
        }
        let height = TASK_MODE_TOP_INSET_PX;
        let visibleRoots = 0;
        for (const task of tasks) {
            if (task.parentId !== undefined)
                continue;
            const children = childrenByParent.get(task.id) ?? [];
            const completed = children.length ? children.every((child) => child.completed) : task.completed;
            if (!showCompleted && completed)
                continue;
            if (visibleRoots)
                height += TASK_GROUP_GAP_PX;
            visibleRoots++;
            height += TASK_ROOT_ROW_HEIGHT_PX + children.length * TASK_CHILD_ROW_HEIGHT_PX;
        }
        return height + TASK_RESOURCE_FRAME_BOTTOM_PX;
    }
    /** Gemeinsame Mindesthöhe aller Task-Spalten, damit die Rahmen auf einer Höhe enden. */
    computeTaskFrameMinHeight(columns, showCompleted) {
        const columnHeights = columns.map((tasks) => this.estimateTaskColumnHeight(tasks, showCompleted));
        return Math.max(TASK_ROOT_ROW_HEIGHT_PX + TASK_MODE_TOP_INSET_PX, ...columnHeights);
    }
    /** Mindestbreite der Spaltenbereiche in px; 0, wenn keine Mindestbreite gesetzt ist. */
    computeColumnsMinWidthPx(groupColumnCounts, minColumnWidthPx) {
        if (minColumnWidthPx <= 0 || groupColumnCounts.length === 0)
            return 0;
        const columns = groupColumnCounts.reduce((sum, count) => sum + count, 0);
        const groups = groupColumnCounts.length;
        return (columns * minColumnWidthPx + (columns - groups) * DAY_COLUMN_GAP_PX + (groups - 1) * DAY_GROUP_GAP_PX);
    }
    formatClock(hours, minutes) {
        const pad = (value) => String(value).padStart(2, '0');
        return `${pad(hours)}:${pad(minutes)}`;
    }
    startOfDay(date) {
        const result = new Date(date);
        result.setHours(0, 0, 0, 0);
        return result;
    }
    /** Letzter Zeitpunkt des Tages, NICHT Mitternacht des Folgetags (sonst kippt timeToOffset). */
    endOfDay(date) {
        const result = new Date(date);
        result.setHours(23, 59, 59, 999);
        return result;
    }
    addDays(date, days) {
        const result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }
    clamp(date, min, max) {
        if (date < min)
            return min;
        if (date > max)
            return max;
        return date;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridLayoutService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridLayoutService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridLayoutService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Lokales Datum als `YYYY-MM-DD`, das Format von `CalendarTask.date`. */
function toDateKey(date) {
    const pad = (value) => String(value).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

const EMPTY_SOURCE = {
    events: signal([]).asReadonly(),
    tasks: signal([]).asReadonly(),
    resources: signal([]).asReadonly(),
    dayAnnotations: signal([]).asReadonly(),
    viewMode: signal('week').asReadonly(),
    columnMode: signal('date').asReadonly(),
    anchorDate: signal(new Date()).asReadonly(),
    config: signal(DEFAULT_GRID_CONFIG).asReadonly(),
};
/** Interner, reaktiver State des Grids (Signals). Wird von GridCalendarComponent instanziiert, kein globaler Store. */
class GridStateService {
    layoutService = inject(GridLayoutService);
    destroyRef = inject(DestroyRef);
    source = signal(EMPTY_SOURCE, ...(ngDevMode ? [{ debugName: "source" }] : /* istanbul ignore next */ []));
    _containerHeightPx = signal(0, ...(ngDevMode ? [{ debugName: "_containerHeightPx" }] : /* istanbul ignore next */ []));
    _now = signal(new Date(), ...(ngDevMode ? [{ debugName: "_now" }] : /* istanbul ignore next */ []));
    events = computed(() => this.source().events(), ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    tasks = computed(() => this.source().tasks(), ...(ngDevMode ? [{ debugName: "tasks" }] : /* istanbul ignore next */ []));
    resources = computed(() => this.source().resources(), ...(ngDevMode ? [{ debugName: "resources" }] : /* istanbul ignore next */ []));
    dayAnnotations = computed(() => this.source().dayAnnotations(), ...(ngDevMode ? [{ debugName: "dayAnnotations" }] : /* istanbul ignore next */ []));
    viewMode = computed(() => this.source().viewMode(), ...(ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []));
    columnMode = computed(() => this.source().columnMode(), ...(ngDevMode ? [{ debugName: "columnMode" }] : /* istanbul ignore next */ []));
    // Blättern ändert den Anker lokal; ein neuer anchorDate-Input setzt ihn zurück.
    navigationAnchor = linkedSignal(() => this.source().anchorDate(), ...(ngDevMode ? [{ debugName: "navigationAnchor" }] : /* istanbul ignore next */ []));
    anchorDate = this.navigationAnchor.asReadonly();
    config = computed(() => this.source().config(), ...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    containerHeightPx = this._containerHeightPx.asReadonly();
    connect(source) {
        this.source.set(source);
    }
    shiftVisibleRange(direction) {
        this.navigationAnchor.set(this.layoutService.shiftAnchor(this.navigationAnchor(), this.viewMode(), direction));
    }
    resetVisibleRange() {
        this.navigationAnchor.set(this.source().anchorDate());
    }
    /**
     * config, aber mit an die verfügbare Höhe angepasster pixelsPerHour, damit das
     * Arbeitszeit-Fenster ohne Scrollen exakt in den Container passt (siehe
     * GridLayoutService.computeEffectivePixelsPerHour).
     */
    effectiveConfig = computed(() => {
        const config = this.config();
        return {
            ...config,
            pixelsPerHour: this.layoutService.computeEffectivePixelsPerHour(config, this._containerHeightPx()),
        };
    }, ...(ngDevMode ? [{ debugName: "effectiveConfig" }] : /* istanbul ignore next */ []));
    /** 1/3/7 Tage ab anchorDate (rollierendes Fenster, kein fixer Wochenstart). */
    visibleDates = computed(() => this.layoutService.computeVisibleRange(this.viewMode(), this.anchorDate()), ...(ngDevMode ? [{ debugName: "visibleDates" }] : /* istanbul ignore next */ []));
    /** Beginn des aktuellen Tages; ändert sich nur bei Tageswechsel, nicht im Minutentakt. */
    today = computed(() => this.layoutService.computeVisibleRange('day', this._now())[0], { ...(ngDevMode ? { debugName: "today" } : /* istanbul ignore next */ {}), equal: (a, b) => a.getTime() === b.getTime() });
    /**
     * Ein Eintrag pro sichtbarem Tag. Im columnMode 'date' hat jeder Tag genau eine Sub-Spalte
     * (der ganze Tag), im columnMode 'resource' eine Sub-Spalte pro Person (Tag×Person-Raster,
     * eine gemeinsame Zeitachse für alle Tage/Personen).
     */
    dayGroups = computed(() => {
        const columnMode = this.columnMode();
        const resources = this.resources();
        const today = this.today();
        return this.visibleDates().map((date) => ({
            date,
            weekNumber: this.layoutService.getIsoWeekNumber(date),
            isToday: this.layoutService.isSameDay(date, today),
            columns: this.buildColumnsForDay(date, columnMode, resources),
        }));
    }, ...(ngDevMode ? [{ debugName: "dayGroups" }] : /* istanbul ignore next */ []));
    /** Alle Sub-Spalten flach (für Lookups, z.B. beim Drag&Drop-Zielspalten-Abgleich). */
    flatColumns = computed(() => this.dayGroups().flatMap((group) => group.columns), ...(ngDevMode ? [{ debugName: "flatColumns" }] : /* istanbul ignore next */ []));
    /** Checklist-Tasks pro sichtbarer Datum-/Ressourcen-Spalte; Task-Daten enthalten keine Uhrzeit. */
    tasksByColumn = computed(() => {
        const tasks = this.tasks();
        const columnMode = this.columnMode();
        const tasksById = new Map(tasks.map((task) => [task.id, task]));
        return new Map(this.dayGroups().flatMap((group) => group.columns.map((column) => [
            column.key,
            tasks.filter((task) => {
                const groupingTask = task.parentId === undefined ? task : (tasksById.get(task.parentId) ?? task);
                return (groupingTask.date === toDateKey(group.date) &&
                    (columnMode !== 'resource' || groupingTask.resourceId === column.resource?.id));
            }),
        ])));
    }, ...(ngDevMode ? [{ debugName: "tasksByColumn" }] : /* istanbul ignore next */ []));
    /** Feiertage und Ferien je Personen-Spalte; im columnMode 'date' gibt es keine Personen-Spalten. */
    annotationsByColumn = computed(() => {
        const annotations = [
            ...new Map(this.dayAnnotations().map((a) => [`${a.date}|${a.resourceId}|${a.type}|${a.label}`, a])).values(),
        ];
        return new Map(this.dayGroups().flatMap((group) => group.columns
            .filter((column) => column.resource)
            .map((column) => [
            column.key,
            annotations.filter((annotation) => annotation.date === toDateKey(group.date) && annotation.resourceId === column.resource?.id),
        ])));
    }, ...(ngDevMode ? [{ debugName: "annotationsByColumn" }] : /* istanbul ignore next */ []));
    /** Event-Layout je Sub-Spalte, berechnet über GridLayoutService (keine Business-Logik hier, nur Orchestrierung). */
    layoutByColumn = computed(() => {
        const result = new Map();
        const config = this.effectiveConfig();
        const events = this.events();
        for (const group of this.dayGroups()) {
            for (const column of group.columns) {
                const eventsForColumn = column.resource
                    ? events.filter((event) => event.resourceId === column.resource.id)
                    : events;
                result.set(column.key, this.layoutService.layoutEventsForColumn(eventsForColumn, group.date, config));
            }
        }
        return result;
    }, ...(ngDevMode ? [{ debugName: "layoutByColumn" }] : /* istanbul ignore next */ []));
    /** Aktueller Zeitpunkt fuer die Live-Zeit-Linie; aktualisiert sich nur an vollen Minuten. */
    now = this._now.asReadonly();
    nowOffsetPx = computed(() => this.layoutService.timeToOffset(this.now(), this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "nowOffsetPx" }] : /* istanbul ignore next */ []));
    /** false außerhalb des Arbeitszeit-Fensters: sonst würde die Linie irreführend am Rand kleben. */
    isNowVisible = computed(() => this.layoutService.isWithinWorkingHours(this.now(), this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "isNowVisible" }] : /* istanbul ignore next */ []));
    /** Pixel-Offsets der dezenten Hilfslinien (unabhängig vom Drag&Drop-Snapping-Raster). */
    gridLinesPx = computed(() => this.layoutService.computeGridLines(this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "gridLinesPx" }] : /* istanbul ignore next */ []));
    _dragAnchor = signal(null, ...(ngDevMode ? [{ debugName: "_dragAnchor" }] : /* istanbul ignore next */ []));
    /** Hilfslinie + Spalte, an der die Oberkante des gerade gezogenen Events hängt (Vorschau = Drop-Ergebnis). */
    dragAnchor = this._dragAnchor.asReadonly();
    setDragAnchor(anchor) {
        this._dragAnchor.set(anchor);
    }
    /** Überschneidet das Event einen anderen Event derselben Spalte (Berührung zählt nicht). */
    collidesWithOthers(candidate) {
        return this.conflictsWith(candidate).length > 0;
    }
    /** Alle anderen Events derselben Spalte, mit denen sich der Kandidat überschneidet. */
    conflictsWith(candidate) {
        return this.events().filter((event) => event.id !== candidate.id &&
            (this.columnMode() !== 'resource' || event.resourceId === candidate.resourceId) &&
            this.layoutService.isSameDay(new Date(event.start), new Date(candidate.start)) &&
            this.layoutService.overlapsAny(candidate, [event]));
    }
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln, als explizite Höhe für Zeitachse/Spalten (entspricht containerHeightPx, kein Scrollen nötig). */
    contentHeightPx = computed(() => this.layoutService.computeContentHeight(this.effectiveConfig()), ...(ngDevMode ? [{ debugName: "contentHeightPx" }] : /* istanbul ignore next */ []));
    constructor() {
        const refresh = () => this._now.set(new Date());
        const delayToNextMinute = 60_000 - (Date.now() % 60_000);
        const initialTimer = setTimeout(() => {
            refresh();
            const intervalTimer = setInterval(refresh, 60_000);
            this.destroyRef.onDestroy(() => clearInterval(intervalTimer));
        }, delayToNextMinute);
        this.destroyRef.onDestroy(() => clearTimeout(initialTimer));
    }
    buildColumnsForDay(date, columnMode, resources) {
        if (columnMode === 'resource') {
            return resources.map((resource) => ({
                key: `${date.toISOString()}__${resource.id}`,
                label: resource.name,
                date,
                resource,
            }));
        }
        return [{ key: date.toISOString(), label: '', date }];
    }
    setContainerHeightPx(heightPx) {
        this._containerHeightPx.set(heightPx);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridStateService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridStateService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

const CSS_VAR_PREFIX = '--glc-';
/** Setzt GridTheme-Werte als CSS Custom Properties auf einem Host-Element. Keine hartkodierten Werte hier. */
class ThemeService {
    apply(theme, hostElement) {
        for (const [key, value] of Object.entries(theme)) {
            if (value === undefined)
                continue;
            hostElement.style.setProperty(this.toCssVarName(key), this.toCssValue(value));
        }
    }
    toCssVarName(key) {
        return CSS_VAR_PREFIX + key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
    }
    toCssValue(value) {
        return typeof value === 'number' ? `${value}px` : value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: ThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: ThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const DEFAULT_GRID_LABELS = {
    today: 'Heute',
    previous: 'Zurück',
    next: 'Weiter',
    weekAbbreviation: 'KW',
    deleteEvent: 'Löschen',
    resizeTop: 'Zum Vergrößern nach oben ziehen',
    resizeBottom: 'Zum Vergrößern nach unten ziehen',
    editingLocked: 'Bearbeitung gesperrt',
    editingUnlocked: 'Bearbeitung freigegeben',
    taskColumn: 'Tasks für diese Person und diesen Tag',
    addNote: 'Notiz hinzufuegen',
    showNotes: 'Notizen anzeigen ({count})',
    collapseSubtasks: '{name}, {count} Untertasks einklappen',
    expandSubtasks: '{name}, {count} Untertasks ausklappen',
};
/** Ersetzt `{key}`-Platzhalter in einer Beschriftung. */
function fillLabel(template, values) {
    return template.replace(/\{(\w+)\}/g, (match, key) => String(values[key] ?? match));
}

/** Führt Listen und Einzelwerte zusammen; bei gleicher ID gewinnt die spätere Quelle. */
function mergeById(...sources) {
    const values = new Map();
    for (const source of sources) {
        const entries = Array.isArray(source) ? source : source ? [source] : [];
        for (const entry of entries) {
            values.set(entry.id, entry);
        }
    }
    return [...values.values()];
}

class EventItemComponent {
    layoutService = inject(GridLayoutService);
    state = inject(GridStateService, { optional: true });
    destroyRef = inject(DestroyRef);
    elementRef = inject((ElementRef));
    ngZone = inject(NgZone);
    cdr = inject(ChangeDetectorRef);
    layout = input.required(...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    columnDate = input.required(...(ngDevMode ? [{ debugName: "columnDate" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    labels = input(DEFAULT_GRID_LABELS, ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    editingLocked = input(false, ...(ngDevMode ? [{ debugName: "editingLocked" }] : /* istanbul ignore next */ []));
    deleted = output();
    eventClicked = output();
    editRequested = output();
    eventUpdated = output();
    /** Grid-Sperre oder per-Event-`locked`: keine Bearbeitung, kein Drag, kein Resize. */
    isLocked = computed(() => this.editingLocked() || this.layout().event.locked === true, ...(ngDevMode ? [{ debugName: "isLocked" }] : /* istanbul ignore next */ []));
    resizeTopLine = signal(null, ...(ngDevMode ? [{ debugName: "resizeTopLine" }] : /* istanbul ignore next */ []));
    resizeBottomLine = signal(null, ...(ngDevMode ? [{ debugName: "resizeBottomLine" }] : /* istanbul ignore next */ []));
    resizeBlocked = signal(false, ...(ngDevMode ? [{ debugName: "resizeBlocked" }] : /* istanbul ignore next */ []));
    dragPreviewSignal = signal(null, ...(ngDevMode ? [{ debugName: "dragPreviewSignal" }] : /* istanbul ignore next */ []));
    blocked = computed(() => this.resizeBlocked() || (this.dragPreviewSignal()?.blocked ?? false), ...(ngDevMode ? [{ debugName: "blocked" }] : /* istanbul ignore next */ []));
    dragRef = viewChild.required(CdkDrag);
    gridLines = computed(() => this.layoutService.computeGridLines(this.config()), ...(ngDevMode ? [{ debugName: "gridLines" }] : /* istanbul ignore next */ []));
    resizeActive = null;
    resizeStartY = 0;
    cancelResize = null;
    /** Spaltenmessung für die Dauer eines Drags; Scrollen verwirft sie, weil sich die Rechtecke verschieben. */
    columnMeasure = null;
    root = viewChild.required('root');
    titleMeasure = viewChild.required('titleMeasure');
    /** Titel passt nicht in die aktuelle Event-Breite: Kurztitel zeigen, Uhrzeit ausblenden. */
    compact = signal(false, ...(ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []));
    displayTitle = computed(() => {
        const { title, shortTitle } = this.layout().event;
        return this.compact() && shortTitle ? shortTitle : title;
    }, ...(ngDevMode ? [{ debugName: "displayTitle" }] : /* istanbul ignore next */ []));
    effectiveTopPx = computed(() => this.resizeTopLine()?.offsetPx ?? this.layout().topPx, ...(ngDevMode ? [{ debugName: "effectiveTopPx" }] : /* istanbul ignore next */ []));
    effectiveHeightPx = computed(() => {
        const bottom = this.resizeBottomLine()?.offsetPx ?? this.layout().topPx + this.layout().heightPx;
        return bottom - this.effectiveTopPx();
    }, ...(ngDevMode ? [{ debugName: "effectiveHeightPx" }] : /* istanbul ignore next */ []));
    /** Start und Ende als Text; während Drag oder Resize die Live-Werte. Das Ende lässt sich per CSS bei schmaler Karte ausblenden. */
    timeParts = computed(() => {
        const format = (time) => this.layoutService.formatTime(time);
        const { id, start, end } = this.layout().event;
        if (!start || !end) {
            return { start: '', end: '' };
        }
        const preview = this.dragPreviewSignal();
        if (preview?.eventId === id) {
            const duration = new Date(end).getTime() - new Date(start).getTime();
            return { start: format(preview.start), end: format(new Date(preview.start.getTime() + duration)) };
        }
        const topLine = this.resizeTopLine();
        const bottomLine = this.resizeBottomLine();
        if (topLine && bottomLine) {
            return {
                start: format(this.layoutService.timeOnGridLine(topLine, this.columnDate())),
                end: format(this.layoutService.timeOnGridLine(bottomLine, this.columnDate())),
            };
        }
        return { start: format(new Date(start)), end: format(new Date(end)) };
    }, ...(ngDevMode ? [{ debugName: "timeParts" }] : /* istanbul ignore next */ []));
    effectiveTimeRange = computed(() => {
        const { start, end } = this.timeParts();
        return start && end ? `${start} - ${end}` : '';
    }, ...(ngDevMode ? [{ debugName: "effectiveTimeRange" }] : /* istanbul ignore next */ []));
    onEventClick(event) {
        const target = event.target;
        if (this.editingLocked() || target.closest('.glc-event-item__delete, .glc-event-item__resize-handle'))
            return;
        event.stopPropagation();
        this.eventClicked.emit(this.layout().event);
    }
    onEventDblClick(event) {
        if (this.isLocked() || event.target.closest('.glc-event-item__delete, .glc-event-item__resize-handle'))
            return;
        event.stopPropagation();
        this.editRequested.emit(this.layout().event.id);
    }
    onEventKeyDown(event) {
        if (this.editingLocked())
            return;
        if (event.altKey && (event.key === 'ArrowUp' || event.key === 'ArrowDown') && !this.isLocked()) {
            event.preventDefault();
            event.stopPropagation();
            // Alt: untere Kante, Alt+Shift: obere Kante; Pfeil = eine Hilfslinie nach oben/unten.
            this.resizeByKey(event.shiftKey ? 'top' : 'bottom', event.key === 'ArrowDown' ? 1 : -1);
            return;
        }
        if (event.key !== 'Enter' && event.key !== ' ') {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        if (event.shiftKey) {
            if (!this.isLocked())
                this.editRequested.emit(this.layout().event.id);
            return;
        }
        this.eventClicked.emit(this.layout().event);
    }
    onCdkDragStarted() {
        this.state?.setDragAnchor(null);
        this.columnMeasure = null;
        // Scrollen verschiebt die Linien unter der Box, ohne dass die Maus sich bewegt.
        this.elementRef.nativeElement.ownerDocument.addEventListener('scroll', this.onScrollWhileDragging, true);
    }
    onCdkDragEnded() {
        // Ohne Rücksprung bliebe die Karte am abgelegten Punkt stehen, auch wenn der Drop verworfen wurde.
        this.dragRef().reset();
        this.columnMeasure = null;
        this.elementRef.nativeElement.ownerDocument.removeEventListener('scroll', this.onScrollWhileDragging, true);
        this.ngZone.run(() => this.dragPreviewSignal.set(null));
    }
    /** CDK-Hook: liefert die Position (oben links) der Vorschau-Box – eingerastet auf Hilfslinie + Spalte. */
    snapToGrid = (pointer, _ref, _size, pickup) => {
        const anchor = this.anchorTo(pointer.x, pointer.y - pickup.y);
        if (!anchor) {
            return { x: pointer.x - pickup.x, y: pointer.y - pickup.y };
        }
        return { x: anchor.columnRect.left, y: anchor.columnRect.top + anchor.line.offsetPx };
    };
    onScrollWhileDragging = () => {
        this.columnMeasure = null;
        const preview = this.elementRef.nativeElement.ownerDocument.querySelector('.cdk-drag-preview');
        const rect = preview?.getBoundingClientRect();
        if (rect) {
            this.anchorTo(rect.left + rect.width / 2, rect.top);
        }
    };
    constructor() {
        this.destroyRef.onDestroy(() => {
            this.elementRef.nativeElement.ownerDocument.removeEventListener('scroll', this.onScrollWhileDragging, true);
            this.cancelResize?.();
        });
        // Breite ändert sich mit Fenster, Ansicht und Personenzahl; ein geänderter Titel ändert die Messbreite.
        afterNextRender(() => {
            this.updateCompact();
            if (typeof ResizeObserver === 'undefined') {
                return;
            }
            const observer = new ResizeObserver(() => this.updateCompact());
            observer.observe(this.root().nativeElement);
            observer.observe(this.titleMeasure().nativeElement);
            this.destroyRef.onDestroy(() => observer.disconnect());
        });
    }
    updateCompact() {
        const root = this.root().nativeElement;
        // Ohne Layout (Breite 0, z. B. noch nicht sichtbar) nichts entscheiden.
        if (root.clientWidth === 0) {
            this.compact.set(false);
            return;
        }
        const style = getComputedStyle(root);
        const available = root.clientWidth - (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0);
        this.compact.set(this.titleMeasure().nativeElement.offsetWidth > available);
    }
    /** Verankert die Box-Oberkante an der nächsten Hilfslinie der Spalte unter x (Vorschau = Drop-Ergebnis). */
    anchorTo(x, boxTopY) {
        const columns = (this.columnMeasure ??= this.measureColumns());
        if (!this.state || columns.length === 0) {
            return null;
        }
        const distance = (rect) => (x < rect.left ? rect.left - x : x > rect.right ? x - rect.right : 0);
        const column = columns.reduce((best, candidate) => (distance(candidate.rect) < distance(best.rect) ? candidate : best));
        const line = this.layoutService.nearestGridLine(this.gridLines(), boxTopY - column.inner.top);
        const targetColumn = this.state?.flatColumns().find((candidate) => candidate.key === column.key);
        const start = this.layoutService.timeOnGridLine(line, targetColumn?.date ?? this.columnDate());
        const event = this.layout().event;
        const duration = new Date(event.end).getTime() - new Date(event.start).getTime();
        const end = new Date(start.getTime() + duration);
        const blocked = this.overlapsAt(start, end, targetColumn?.resource?.id ?? event.resourceId);
        this.state?.setDragAnchor({ line, columnKey: column.key });
        this.dragPreviewSignal.set({ eventId: event.id, start, blocked });
        this.cdr.markForCheck();
        return { line, columnRect: column.inner };
    }
    /** Prüft, ob das Event mit den angegebenen Zeiten einen anderen Event überschneidet. */
    overlapsAt(start, end, resourceId) {
        return this.state?.collidesWithOthers({ ...this.layout().event, start: start.toISOString(), end: end.toISOString(), resourceId }) ?? false;
    }
    updateResizeBlocked() {
        const topLine = this.resizeTopLine();
        const bottomLine = this.resizeBottomLine();
        if (!topLine || !bottomLine)
            return;
        const start = this.layoutService.timeOnGridLine(topLine, this.columnDate());
        const end = this.layoutService.timeOnGridLine(bottomLine, this.columnDate());
        this.resizeBlocked.set(this.overlapsAt(start, end, this.layout().event.resourceId));
    }
    measureColumns() {
        const host = this.elementRef.nativeElement;
        const root = host.closest('glc-grid-calendar') ?? host.ownerDocument;
        return [...root.querySelectorAll('.glc-day-column[data-column-key]')].map((element) => {
            const rect = element.getBoundingClientRect();
            // Events sitzen innerhalb des Spaltenrahmens (+1px wie im Layout): Vorschau genauso platzieren.
            const inner = new DOMRect(rect.left + element.clientLeft + 1, rect.top + element.clientTop, rect.width, rect.height);
            return { key: element.dataset['columnKey'], rect, inner };
        });
    }
    onDeleteClick(event) {
        event.stopPropagation();
        this.deleted.emit(this.layout().event);
    }
    resizeByKey(edge, step) {
        if (this.isLocked())
            return;
        const lines = this.gridLines();
        const { topPx, heightPx } = this.layout();
        const top = this.layoutService.nearestGridLine(lines, topPx);
        const bottom = this.layoutService.nearestGridLine(lines, topPx + heightPx);
        const target = lines[lines.indexOf(edge === 'top' ? top : bottom) + step];
        if (!target) {
            return;
        }
        const newTop = edge === 'top' ? this.layoutService.resizeEdgeLine(lines, 'top', target.offsetPx, bottom) : top;
        const newBottom = edge === 'bottom' ? this.layoutService.resizeEdgeLine(lines, 'bottom', target.offsetPx, top) : bottom;
        if (newTop === top && newBottom === bottom) {
            return;
        }
        this.eventUpdated.emit({
            ...this.layout().event,
            start: this.layoutService.timeOnGridLine(newTop, this.columnDate()).toISOString(),
            end: this.layoutService.timeOnGridLine(newBottom, this.columnDate()).toISOString(),
        });
    }
    onResizeStart(event, edge) {
        if (this.isLocked())
            return;
        event.preventDefault();
        event.stopPropagation();
        this.cancelResize?.();
        this.resizeActive = edge;
        this.resizeStartY = event.clientY;
        const pointerId = event.pointerId;
        // Capture hält die Events auch bei Verlassen des Fensters; fehlt in jsdom.
        event.currentTarget.setPointerCapture?.(pointerId);
        const lines = this.gridLines();
        const startTopPx = this.layout().topPx;
        const startBottomPx = startTopPx + this.layout().heightPx;
        this.resizeTopLine.set(this.layoutService.nearestGridLine(lines, startTopPx));
        this.resizeBottomLine.set(this.layoutService.nearestGridLine(lines, startBottomPx));
        const handleMove = (moveEvent) => {
            if (this.resizeActive === null || moveEvent.pointerId !== pointerId)
                return;
            const deltaY = moveEvent.clientY - this.resizeStartY;
            if (this.resizeActive === 'bottom') {
                this.resizeBottomLine.set(this.layoutService.resizeEdgeLine(lines, 'bottom', startBottomPx + deltaY, this.resizeTopLine()));
            }
            else {
                this.resizeTopLine.set(this.layoutService.resizeEdgeLine(lines, 'top', startTopPx + deltaY, this.resizeBottomLine()));
            }
            this.updateResizeBlocked();
        };
        const finish = () => {
            stopListening();
            this.resizeTopLine.set(null);
            this.resizeBottomLine.set(null);
            this.resizeBlocked.set(false);
            this.resizeActive = null;
        };
        const handleUp = (upEvent) => {
            if (upEvent.pointerId !== pointerId)
                return;
            const topLine = this.resizeTopLine();
            const bottomLine = this.resizeBottomLine();
            if (topLine && bottomLine && !this.resizeBlocked() && (topLine.offsetPx !== startTopPx || bottomLine.offsetPx !== startBottomPx)) {
                const updatedEvent = {
                    ...this.layout().event,
                    start: this.layoutService.timeOnGridLine(topLine, this.columnDate()).toISOString(),
                    end: this.layoutService.timeOnGridLine(bottomLine, this.columnDate()).toISOString(),
                };
                this.eventUpdated.emit(updatedEvent);
            }
            finish();
        };
        const handleCancel = (cancelEvent) => {
            if (cancelEvent.pointerId === pointerId)
                finish();
        };
        const doc = this.elementRef.nativeElement.ownerDocument;
        const stopListening = () => {
            doc.removeEventListener('pointermove', handleMove);
            doc.removeEventListener('pointerup', handleUp);
            doc.removeEventListener('pointercancel', handleCancel);
            this.cancelResize = null;
        };
        doc.addEventListener('pointermove', handleMove);
        doc.addEventListener('pointerup', handleUp);
        doc.addEventListener('pointercancel', handleCancel);
        this.cancelResize = stopListening;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: EventItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: EventItemComponent, isStandalone: true, selector: "glc-event-item", inputs: { layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: true, transformFunction: null }, columnDate: { classPropertyName: "columnDate", publicName: "columnDate", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, labels: { classPropertyName: "labels", publicName: "labels", isSignal: true, isRequired: false, transformFunction: null }, editingLocked: { classPropertyName: "editingLocked", publicName: "editingLocked", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { deleted: "deleted", eventClicked: "eventClicked", editRequested: "editRequested", eventUpdated: "eventUpdated" }, viewQueries: [{ propertyName: "dragRef", first: true, predicate: CdkDrag, descendants: true, isSignal: true }, { propertyName: "root", first: true, predicate: ["root"], descendants: true, isSignal: true }, { propertyName: "titleMeasure", first: true, predicate: ["titleMeasure"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div
      #root
      class="glc-event-item"
      cdkDrag
      [cdkDragData]="layout().event"
      [cdkDragConstrainPosition]="snapToGrid"
      [cdkDragDisabled]="isLocked()"
      (cdkDragStarted)="onCdkDragStarted()"
      (cdkDragEnded)="onCdkDragEnded()"
      [style.top.px]="effectiveTopPx()"
      [style.height.px]="effectiveHeightPx()"
      [style.left]="'calc(' + layout().leftPercent + '% + 1px)'"
      [style.width]="'calc(' + layout().widthPercent + '% - 2px)'"
      [style.--glc-event-accent]="layout().event.color"
      [class.glc-event-item--draft]="layout().event.isDraft"
      [class.glc-event-item--locked]="layout().event.locked"
      [class.glc-event-item--compact]="compact()"
      [class.glc-event-item--blocked]="blocked()"
      [attr.title]="layout().event.title || null"
      role="button"
      tabindex="0"
      aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown Alt+Shift+ArrowUp Alt+Shift+ArrowDown"
      [attr.aria-label]="layout().event.title + ', ' + effectiveTimeRange()"
      (click)="onEventClick($event)"
      (dblclick)="onEventDblClick($event)"
      (keydown)="onEventKeyDown($event)"
    >
      @if (!isLocked()) {
        <button type="button" class="glc-event-item__delete" (click)="onDeleteClick($event)" [attr.aria-label]="labels().deleteEvent">×</button>
      }

      @if (layout().event.imageUrl) {
        <img class="glc-event-item__image" [src]="layout().event.imageUrl" [alt]="layout().event.title" />
      }

      <span #titleMeasure class="glc-event-item__title-measure" aria-hidden="true">{{ layout().event.title }}</span>
      <span class="glc-event-item__title">{{ displayTitle() }}</span>
      @if (!compact()) {
        @let time = timeParts();
        <span class="glc-event-item__time">{{ time.start }}<span class="glc-event-item__time-end"> - {{ time.end }}</span></span>
      }

      @if (!isLocked()) {
        <div
          class="glc-event-item__resize-handle glc-event-item__resize-handle--top"
          aria-hidden="true"
          (pointerdown)="onResizeStart($event, 'top')"
          (touchstart)="$event.stopPropagation()"
          [attr.title]="labels().resizeTop"
        ></div>
        <div
          class="glc-event-item__resize-handle glc-event-item__resize-handle--bottom"
          aria-hidden="true"
          (pointerdown)="onResizeStart($event, 'bottom')"
          (touchstart)="$event.stopPropagation()"
          [attr.title]="labels().resizeBottom"
        ></div>
      }

      @if (blocked()) {
        <svg class="glc-event-item__blocked" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <line x1="0" y1="0" x2="100" y2="100" vector-effect="non-scaling-stroke" />
          <line x1="100" y1="0" x2="0" y2="100" vector-effect="non-scaling-stroke" />
        </svg>
      }

      <!-- Innerhalb des cdkDrag-Elements, sonst findet CDK die Vorschau-Vorlage nicht. -->
      <ng-template cdkDragPreview [matchSize]="true">
        <div
          class="glc-event-item glc-event-item--drag-preview"
          [class.glc-event-item--blocked]="blocked()"
          [style.--glc-event-accent]="layout().event.color"
        >
          <span class="glc-event-item__title">{{ displayTitle() }}</span>
          @let time = timeParts();
          <span class="glc-event-item__time">{{ time.start }}<span class="glc-event-item__time-end"> - {{ time.end }}</span></span>
          @if (blocked()) {
            <svg class="glc-event-item__blocked" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
              <line x1="0" y1="0" x2="100" y2="100" vector-effect="non-scaling-stroke" />
              <line x1="100" y1="0" x2="0" y2="100" vector-effect="non-scaling-stroke" />
            </svg>
          }
        </div>
      </ng-template>
    </div>
  `, isInline: true, styles: [".glc-event-item{--glc-event-accent-resolved: var(--glc-event-accent, var(--glc-color-event-default, #4a90d9));position:absolute;container-type:size;box-sizing:border-box;overflow:visible;border-left:4px solid var(--glc-event-accent-resolved);border-radius:var(--glc-event-radius, 4px);background-color:color-mix(in oklch,var(--glc-event-accent-resolved) 18%,var(--glc-color-background, #fff));color:var(--glc-color-on-event, var(--glc-color-text, #222));padding:2px 4px;font-family:var(--glc-font-family, inherit);font-size:.75rem;cursor:grab;-webkit-user-select:none;user-select:none}.glc-event-item:hover{box-shadow:0 2px 8px #0003}.glc-event-item--draft{background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 10px)}.glc-event-item--locked{cursor:default;border:2px solid var(--glc-event-accent-resolved)}.glc-event-item--drag-preview{pointer-events:none;box-shadow:0 4px 12px #00000040;transition:none!important}.glc-event-item--drag-preview .glc-event-item__time{display:block}.glc-event-item.cdk-drag-placeholder{opacity:0}.glc-event-item--blocked{background-color:color-mix(in srgb,#d32f2f 15%,var(--glc-color-background, #fff))}.glc-event-item__blocked{position:absolute;inset:0;width:100%;height:100%;z-index:5;pointer-events:none;stroke:#d32f2f;stroke-width:3px}.glc-event-item__delete{position:absolute;top:50%;right:2px;transform:translateY(-50%);z-index:11;width:16px;height:16px;line-height:14px;padding:0;border:0;border-radius:50%;background:color-mix(in srgb,currentcolor 15%,transparent);color:inherit;cursor:pointer}.glc-event-item__delete:before{content:\"\";position:absolute;inset:-4px}.glc-event-item__delete:hover{background:color-mix(in srgb,currentcolor 30%,transparent)}@container (max-height: 24px){.glc-event-item .glc-event-item__delete{width:10px;height:10px;line-height:8px;font-size:9px}}.glc-event-item__image{display:block;width:100%;height:40%;object-fit:cover}.glc-event-item__title{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__title-measure{position:absolute;top:0;left:0;visibility:hidden;white-space:nowrap;pointer-events:none}.glc-event-item__time{display:block;font-size:.65rem;opacity:.85;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__resize-handle{position:absolute;left:0;right:0;height:6px;cursor:ns-resize;opacity:0;transition:opacity .2s;background:linear-gradient(to right,transparent,color-mix(in srgb,currentcolor 35%,transparent),transparent);z-index:10;touch-action:none}.glc-event-item__resize-handle:before{content:\"\";position:absolute;inset:-9px 0}@media(pointer:coarse){.glc-event-item__resize-handle{height:14px;opacity:1}}.glc-event-item__resize-handle--top{top:0;border-radius:4px 4px 0 0}.glc-event-item__resize-handle--bottom{bottom:0;border-radius:0 0 4px 4px}.glc-event-item:hover .glc-event-item__resize-handle{opacity:1}@media(prefers-reduced-motion:reduce){.glc-event-item__resize-handle{transition:none}}@media(forced-colors:active){.glc-event-item{border:1px solid CanvasText;border-left-width:4px;background-color:Canvas;color:CanvasText}}@container (height < 40px){.glc-event-item__resize-handle{height:25%}.glc-event-item__resize-handle:before{inset:auto 0;height:9px}.glc-event-item__resize-handle--top:before{bottom:100%}.glc-event-item__resize-handle--bottom:before{top:100%}}@container (height < 34px){.glc-event-item__time{display:none}}@container (height < 34px){.glc-event-item--drag-preview .glc-event-item__title{display:none}}@container (height < 20px){.glc-event-item__title{font-size:.6rem;line-height:1}}@container (width < 5rem){.glc-event-item__time-end{display:none}}\n"], dependencies: [{ kind: "directive", type: CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: CdkDragPreview, selector: "ng-template[cdkDragPreview]", inputs: ["data", "matchSize"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: EventItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-event-item', imports: [CdkDrag, CdkDragPreview], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div
      #root
      class="glc-event-item"
      cdkDrag
      [cdkDragData]="layout().event"
      [cdkDragConstrainPosition]="snapToGrid"
      [cdkDragDisabled]="isLocked()"
      (cdkDragStarted)="onCdkDragStarted()"
      (cdkDragEnded)="onCdkDragEnded()"
      [style.top.px]="effectiveTopPx()"
      [style.height.px]="effectiveHeightPx()"
      [style.left]="'calc(' + layout().leftPercent + '% + 1px)'"
      [style.width]="'calc(' + layout().widthPercent + '% - 2px)'"
      [style.--glc-event-accent]="layout().event.color"
      [class.glc-event-item--draft]="layout().event.isDraft"
      [class.glc-event-item--locked]="layout().event.locked"
      [class.glc-event-item--compact]="compact()"
      [class.glc-event-item--blocked]="blocked()"
      [attr.title]="layout().event.title || null"
      role="button"
      tabindex="0"
      aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown Alt+Shift+ArrowUp Alt+Shift+ArrowDown"
      [attr.aria-label]="layout().event.title + ', ' + effectiveTimeRange()"
      (click)="onEventClick($event)"
      (dblclick)="onEventDblClick($event)"
      (keydown)="onEventKeyDown($event)"
    >
      @if (!isLocked()) {
        <button type="button" class="glc-event-item__delete" (click)="onDeleteClick($event)" [attr.aria-label]="labels().deleteEvent">×</button>
      }

      @if (layout().event.imageUrl) {
        <img class="glc-event-item__image" [src]="layout().event.imageUrl" [alt]="layout().event.title" />
      }

      <span #titleMeasure class="glc-event-item__title-measure" aria-hidden="true">{{ layout().event.title }}</span>
      <span class="glc-event-item__title">{{ displayTitle() }}</span>
      @if (!compact()) {
        @let time = timeParts();
        <span class="glc-event-item__time">{{ time.start }}<span class="glc-event-item__time-end"> - {{ time.end }}</span></span>
      }

      @if (!isLocked()) {
        <div
          class="glc-event-item__resize-handle glc-event-item__resize-handle--top"
          aria-hidden="true"
          (pointerdown)="onResizeStart($event, 'top')"
          (touchstart)="$event.stopPropagation()"
          [attr.title]="labels().resizeTop"
        ></div>
        <div
          class="glc-event-item__resize-handle glc-event-item__resize-handle--bottom"
          aria-hidden="true"
          (pointerdown)="onResizeStart($event, 'bottom')"
          (touchstart)="$event.stopPropagation()"
          [attr.title]="labels().resizeBottom"
        ></div>
      }

      @if (blocked()) {
        <svg class="glc-event-item__blocked" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <line x1="0" y1="0" x2="100" y2="100" vector-effect="non-scaling-stroke" />
          <line x1="100" y1="0" x2="0" y2="100" vector-effect="non-scaling-stroke" />
        </svg>
      }

      <!-- Innerhalb des cdkDrag-Elements, sonst findet CDK die Vorschau-Vorlage nicht. -->
      <ng-template cdkDragPreview [matchSize]="true">
        <div
          class="glc-event-item glc-event-item--drag-preview"
          [class.glc-event-item--blocked]="blocked()"
          [style.--glc-event-accent]="layout().event.color"
        >
          <span class="glc-event-item__title">{{ displayTitle() }}</span>
          @let time = timeParts();
          <span class="glc-event-item__time">{{ time.start }}<span class="glc-event-item__time-end"> - {{ time.end }}</span></span>
          @if (blocked()) {
            <svg class="glc-event-item__blocked" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
              <line x1="0" y1="0" x2="100" y2="100" vector-effect="non-scaling-stroke" />
              <line x1="100" y1="0" x2="0" y2="100" vector-effect="non-scaling-stroke" />
            </svg>
          }
        </div>
      </ng-template>
    </div>
  `, styles: [".glc-event-item{--glc-event-accent-resolved: var(--glc-event-accent, var(--glc-color-event-default, #4a90d9));position:absolute;container-type:size;box-sizing:border-box;overflow:visible;border-left:4px solid var(--glc-event-accent-resolved);border-radius:var(--glc-event-radius, 4px);background-color:color-mix(in oklch,var(--glc-event-accent-resolved) 18%,var(--glc-color-background, #fff));color:var(--glc-color-on-event, var(--glc-color-text, #222));padding:2px 4px;font-family:var(--glc-font-family, inherit);font-size:.75rem;cursor:grab;-webkit-user-select:none;user-select:none}.glc-event-item:hover{box-shadow:0 2px 8px #0003}.glc-event-item--draft{background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 10px)}.glc-event-item--locked{cursor:default;border:2px solid var(--glc-event-accent-resolved)}.glc-event-item--drag-preview{pointer-events:none;box-shadow:0 4px 12px #00000040;transition:none!important}.glc-event-item--drag-preview .glc-event-item__time{display:block}.glc-event-item.cdk-drag-placeholder{opacity:0}.glc-event-item--blocked{background-color:color-mix(in srgb,#d32f2f 15%,var(--glc-color-background, #fff))}.glc-event-item__blocked{position:absolute;inset:0;width:100%;height:100%;z-index:5;pointer-events:none;stroke:#d32f2f;stroke-width:3px}.glc-event-item__delete{position:absolute;top:50%;right:2px;transform:translateY(-50%);z-index:11;width:16px;height:16px;line-height:14px;padding:0;border:0;border-radius:50%;background:color-mix(in srgb,currentcolor 15%,transparent);color:inherit;cursor:pointer}.glc-event-item__delete:before{content:\"\";position:absolute;inset:-4px}.glc-event-item__delete:hover{background:color-mix(in srgb,currentcolor 30%,transparent)}@container (max-height: 24px){.glc-event-item .glc-event-item__delete{width:10px;height:10px;line-height:8px;font-size:9px}}.glc-event-item__image{display:block;width:100%;height:40%;object-fit:cover}.glc-event-item__title{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__title-measure{position:absolute;top:0;left:0;visibility:hidden;white-space:nowrap;pointer-events:none}.glc-event-item__time{display:block;font-size:.65rem;opacity:.85;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;position:relative;z-index:1}.glc-event-item__resize-handle{position:absolute;left:0;right:0;height:6px;cursor:ns-resize;opacity:0;transition:opacity .2s;background:linear-gradient(to right,transparent,color-mix(in srgb,currentcolor 35%,transparent),transparent);z-index:10;touch-action:none}.glc-event-item__resize-handle:before{content:\"\";position:absolute;inset:-9px 0}@media(pointer:coarse){.glc-event-item__resize-handle{height:14px;opacity:1}}.glc-event-item__resize-handle--top{top:0;border-radius:4px 4px 0 0}.glc-event-item__resize-handle--bottom{bottom:0;border-radius:0 0 4px 4px}.glc-event-item:hover .glc-event-item__resize-handle{opacity:1}@media(prefers-reduced-motion:reduce){.glc-event-item__resize-handle{transition:none}}@media(forced-colors:active){.glc-event-item{border:1px solid CanvasText;border-left-width:4px;background-color:Canvas;color:CanvasText}}@container (height < 40px){.glc-event-item__resize-handle{height:25%}.glc-event-item__resize-handle:before{inset:auto 0;height:9px}.glc-event-item__resize-handle--top:before{bottom:100%}.glc-event-item__resize-handle--bottom:before{top:100%}}@container (height < 34px){.glc-event-item__time{display:none}}@container (height < 34px){.glc-event-item--drag-preview .glc-event-item__title{display:none}}@container (height < 20px){.glc-event-item__title{font-size:.6rem;line-height:1}}@container (width < 5rem){.glc-event-item__time-end{display:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: true }] }], columnDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnDate", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], labels: [{ type: i0.Input, args: [{ isSignal: true, alias: "labels", required: false }] }], editingLocked: [{ type: i0.Input, args: [{ isSignal: true, alias: "editingLocked", required: false }] }], deleted: [{ type: i0.Output, args: ["deleted"] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], editRequested: [{ type: i0.Output, args: ["editRequested"] }], eventUpdated: [{ type: i0.Output, args: ["eventUpdated"] }], dragRef: [{ type: i0.ViewChild, args: [i0.forwardRef(() => CdkDrag), { isSignal: true }] }], root: [{ type: i0.ViewChild, args: ['root', { isSignal: true }] }], titleMeasure: [{ type: i0.ViewChild, args: ['titleMeasure', { isSignal: true }] }] } });

class DayColumnComponent {
    layoutService = inject(GridLayoutService);
    destroyRef = inject(DestroyRef);
    columnKey = input.required(...(ngDevMode ? [{ debugName: "columnKey" }] : /* istanbul ignore next */ []));
    layouts = input.required(...(ngDevMode ? [{ debugName: "layouts" }] : /* istanbul ignore next */ []));
    columnDate = input.required(...(ngDevMode ? [{ debugName: "columnDate" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    borderColor = input(undefined, ...(ngDevMode ? [{ debugName: "borderColor" }] : /* istanbul ignore next */ []));
    resourceId = input(undefined, ...(ngDevMode ? [{ debugName: "resourceId" }] : /* istanbul ignore next */ []));
    gridLinesPx = input([], ...(ngDevMode ? [{ debugName: "gridLinesPx" }] : /* istanbul ignore next */ []));
    labels = input(DEFAULT_GRID_LABELS, ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    editingLocked = input(false, ...(ngDevMode ? [{ debugName: "editingLocked" }] : /* istanbul ignore next */ []));
    dropped = output();
    eventClicked = output();
    eventEditRequested = output();
    eventDeleted = output();
    eventUpdated = output();
    eventDrawn = output();
    gridLines = computed(() => this.layoutService.computeGridLines(this.config()), ...(ngDevMode ? [{ debugName: "gridLines" }] : /* istanbul ignore next */ []));
    cancelDrawing = null;
    drawStartLine = signal(null, ...(ngDevMode ? [{ debugName: "drawStartLine" }] : /* istanbul ignore next */ []));
    drawEndLine = signal(null, ...(ngDevMode ? [{ debugName: "drawEndLine" }] : /* istanbul ignore next */ []));
    /** Gezeichneter Bereich von Hilfslinie zu Hilfslinie, mindestens eine Linie hoch. */
    drawRange = computed(() => {
        const a = this.drawStartLine();
        const b = this.drawEndLine();
        return a && b ? this.layoutService.drawRange(this.gridLines(), a, b) : null;
    }, ...(ngDevMode ? [{ debugName: "drawRange" }] : /* istanbul ignore next */ []));
    drawingLayout = computed(() => {
        const range = this.drawRange();
        return range ? { topPx: range[0].offsetPx, heightPx: range[1].offsetPx - range[0].offsetPx } : null;
    }, ...(ngDevMode ? [{ debugName: "drawingLayout" }] : /* istanbul ignore next */ []));
    /** Hilfsuhr: Hilfslinie unter der Maus, nur über leerem Raster und ohne gedrückte Maustaste. */
    hoverLine = signal(null, ...(ngDevMode ? [{ debugName: "hoverLine" }] : /* istanbul ignore next */ []));
    hoverLabel = computed(() => {
        const line = this.hoverLine();
        return line ? this.layoutService.formatGridLineTime(line) : '';
    }, ...(ngDevMode ? [{ debugName: "hoverLabel" }] : /* istanbul ignore next */ []));
    constructor() {
        this.destroyRef.onDestroy(() => this.cancelDrawing?.());
    }
    onMouseMove(event) {
        // buttons !== 0: Zeichnen, Verschieben oder Resize läuft gerade.
        if (this.editingLocked() || event.buttons !== 0 || event.target.closest('.glc-event-item')) {
            this.hoverLine.set(null);
            return;
        }
        this.hoverLine.set(this.lineAt(event.currentTarget, event.clientY));
    }
    /** Hilfslinie an einer Bildschirm-Y-Position (Linien beginnen an der Innenkante der Spalte). */
    lineAt(column, clientY) {
        const top = column.getBoundingClientRect().top + column.clientTop;
        return this.layoutService.nearestGridLine(this.gridLines(), clientY - top);
    }
    onDropped(event) {
        this.dropped.emit(event);
    }
    onDrawStart(event) {
        this.hoverLine.set(null);
        if (this.editingLocked() || event.button !== 0 || event.target.closest('.glc-event-item')) {
            return;
        }
        event.preventDefault();
        this.cancelDrawing?.();
        const element = event.currentTarget;
        const doc = element.ownerDocument;
        const pointerId = event.pointerId;
        // Capture hält die Events auch bei Verlassen des Fensters; fehlt in jsdom.
        element.setPointerCapture?.(pointerId);
        const lineAt = (clientY) => this.lineAt(element, clientY);
        const startLine = lineAt(event.clientY);
        this.drawStartLine.set(startLine);
        this.drawEndLine.set(startLine);
        const onMove = (moveEvent) => {
            if (moveEvent.pointerId === pointerId) {
                this.drawEndLine.set(lineAt(moveEvent.clientY));
            }
        };
        const stop = () => {
            doc.removeEventListener('pointermove', onMove);
            doc.removeEventListener('pointerup', onUp);
            doc.removeEventListener('pointercancel', onCancel);
            doc.removeEventListener('keydown', onKeyDown);
            this.drawStartLine.set(null);
            this.drawEndLine.set(null);
            this.cancelDrawing = null;
        };
        const onUp = (upEvent) => {
            if (upEvent.pointerId !== pointerId) {
                return;
            }
            const range = this.drawRange();
            if (range) {
                const startTime = this.layoutService.timeOnGridLine(range[0], this.columnDate());
                const endTime = this.layoutService.timeOnGridLine(range[1], this.columnDate());
                this.eventDrawn.emit({ start: startTime.toISOString(), end: endTime.toISOString(), resourceId: this.resourceId() });
            }
            stop();
        };
        const onCancel = (cancelEvent) => {
            if (cancelEvent.pointerId === pointerId) {
                stop();
            }
        };
        const onKeyDown = (keyEvent) => {
            if (keyEvent.key === 'Escape') {
                stop();
            }
        };
        doc.addEventListener('pointermove', onMove);
        doc.addEventListener('pointerup', onUp);
        doc.addEventListener('pointercancel', onCancel);
        doc.addEventListener('keydown', onKeyDown);
        this.cancelDrawing = stop;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: DayColumnComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: DayColumnComponent, isStandalone: true, selector: "glc-day-column", inputs: { columnKey: { classPropertyName: "columnKey", publicName: "columnKey", isSignal: true, isRequired: true, transformFunction: null }, layouts: { classPropertyName: "layouts", publicName: "layouts", isSignal: true, isRequired: true, transformFunction: null }, columnDate: { classPropertyName: "columnDate", publicName: "columnDate", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, borderColor: { classPropertyName: "borderColor", publicName: "borderColor", isSignal: true, isRequired: false, transformFunction: null }, resourceId: { classPropertyName: "resourceId", publicName: "resourceId", isSignal: true, isRequired: false, transformFunction: null }, gridLinesPx: { classPropertyName: "gridLinesPx", publicName: "gridLinesPx", isSignal: true, isRequired: false, transformFunction: null }, labels: { classPropertyName: "labels", publicName: "labels", isSignal: true, isRequired: false, transformFunction: null }, editingLocked: { classPropertyName: "editingLocked", publicName: "editingLocked", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dropped: "dropped", eventClicked: "eventClicked", eventEditRequested: "eventEditRequested", eventDeleted: "eventDeleted", eventUpdated: "eventUpdated", eventDrawn: "eventDrawn" }, ngImport: i0, template: `
    <div
      class="glc-day-column"
      cdkDropList
      cdkDropListSortingDisabled
      [attr.data-column-key]="columnKey()"
      [cdkDropListData]="columnKey()"
      (cdkDropListDropped)="onDropped($event)"
      (pointerdown)="onDrawStart($event)"
      (mousemove)="onMouseMove($event)"
      (mouseleave)="hoverLine.set(null)"
      [style.--glc-resource-color]="borderColor()"
      [class.glc-day-column--framed]="!!borderColor()"
      [class.glc-day-column--locked]="editingLocked()"
    >
      @for (line of gridLinesPx(); track line.offsetPx) {
        <div
          class="glc-day-column__gridline"
          [class.glc-day-column__gridline--hour]="line.isHour"
          [style.top.px]="line.offsetPx"
        ></div>
      }
      @for (layout of layouts(); track layout.event.id) {
        <glc-event-item
          [layout]="layout"
          [columnDate]="columnDate()"
          [config]="config()"
          [labels]="labels()"
          [editingLocked]="editingLocked()"
          (eventClicked)="eventClicked.emit($event)"
          (editRequested)="eventEditRequested.emit($event)"
          (deleted)="eventDeleted.emit($event)"
          (eventUpdated)="eventUpdated.emit($event)"
        />
      }
      @if (drawingLayout(); as layout) {
        <div
          class="glc-day-column__draft"
          [style.top.px]="layout.topPx"
          [style.height.px]="layout.heightPx"
        ></div>
      }
      @if (hoverLine(); as line) {
        <div class="glc-day-column__hover-line" [style.top.px]="line.offsetPx">
          <span class="glc-day-column__hover-time">{{ hoverLabel() }}</span>
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;flex:1 1 0;min-width:0;height:100%;border-radius:8px}.glc-day-column{position:relative;box-sizing:border-box;width:100%;height:100%;touch-action:none}.glc-day-column--locked{touch-action:auto}.glc-day-column--framed{border:3px solid var(--glc-resource-color);border-top:0;border-radius:0 0 8px 8px}.glc-day-column__gridline{position:absolute;left:0;right:0;border-top:1px solid transparent;pointer-events:none}.glc-day-column__gridline--hour{border-top:1px solid var(--glc-color-border, #ccc)}.glc-day-column__hover-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-primary, #333);pointer-events:none}.glc-day-column__hover-time{position:absolute;left:0;bottom:2px;display:inline-block;white-space:nowrap;padding:.05rem .35rem;border-radius:4px;background:var(--glc-color-hover-bg, #000);color:var(--glc-color-hover-text, #fff);font-size:.65rem;font-weight:600;pointer-events:none}.glc-day-column__draft{position:absolute;left:1px;right:1px;box-sizing:border-box;border:1px solid var(--glc-color-draft-border, #1c7ed6);border-radius:var(--glc-event-radius, 4px);background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 10px);pointer-events:none}\n"], dependencies: [{ kind: "directive", type: CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "component", type: EventItemComponent, selector: "glc-event-item", inputs: ["layout", "columnDate", "config", "labels", "editingLocked"], outputs: ["deleted", "eventClicked", "editRequested", "eventUpdated"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: DayColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-day-column', imports: [CdkDropList, EventItemComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div
      class="glc-day-column"
      cdkDropList
      cdkDropListSortingDisabled
      [attr.data-column-key]="columnKey()"
      [cdkDropListData]="columnKey()"
      (cdkDropListDropped)="onDropped($event)"
      (pointerdown)="onDrawStart($event)"
      (mousemove)="onMouseMove($event)"
      (mouseleave)="hoverLine.set(null)"
      [style.--glc-resource-color]="borderColor()"
      [class.glc-day-column--framed]="!!borderColor()"
      [class.glc-day-column--locked]="editingLocked()"
    >
      @for (line of gridLinesPx(); track line.offsetPx) {
        <div
          class="glc-day-column__gridline"
          [class.glc-day-column__gridline--hour]="line.isHour"
          [style.top.px]="line.offsetPx"
        ></div>
      }
      @for (layout of layouts(); track layout.event.id) {
        <glc-event-item
          [layout]="layout"
          [columnDate]="columnDate()"
          [config]="config()"
          [labels]="labels()"
          [editingLocked]="editingLocked()"
          (eventClicked)="eventClicked.emit($event)"
          (editRequested)="eventEditRequested.emit($event)"
          (deleted)="eventDeleted.emit($event)"
          (eventUpdated)="eventUpdated.emit($event)"
        />
      }
      @if (drawingLayout(); as layout) {
        <div
          class="glc-day-column__draft"
          [style.top.px]="layout.topPx"
          [style.height.px]="layout.heightPx"
        ></div>
      }
      @if (hoverLine(); as line) {
        <div class="glc-day-column__hover-line" [style.top.px]="line.offsetPx">
          <span class="glc-day-column__hover-time">{{ hoverLabel() }}</span>
        </div>
      }
    </div>
  `, styles: [":host{display:block;flex:1 1 0;min-width:0;height:100%;border-radius:8px}.glc-day-column{position:relative;box-sizing:border-box;width:100%;height:100%;touch-action:none}.glc-day-column--locked{touch-action:auto}.glc-day-column--framed{border:3px solid var(--glc-resource-color);border-top:0;border-radius:0 0 8px 8px}.glc-day-column__gridline{position:absolute;left:0;right:0;border-top:1px solid transparent;pointer-events:none}.glc-day-column__gridline--hour{border-top:1px solid var(--glc-color-border, #ccc)}.glc-day-column__hover-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-primary, #333);pointer-events:none}.glc-day-column__hover-time{position:absolute;left:0;bottom:2px;display:inline-block;white-space:nowrap;padding:.05rem .35rem;border-radius:4px;background:var(--glc-color-hover-bg, #000);color:var(--glc-color-hover-text, #fff);font-size:.65rem;font-weight:600;pointer-events:none}.glc-day-column__draft{position:absolute;left:1px;right:1px;box-sizing:border-box;border:1px solid var(--glc-color-draft-border, #1c7ed6);border-radius:var(--glc-event-radius, 4px);background:repeating-linear-gradient(135deg,var(--glc-color-draft-primary, #228be6) 0,var(--glc-color-draft-primary, #228be6) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 5px,var(--glc-color-draft-secondary, var(--glc-color-background, #fff)) 10px);pointer-events:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { columnKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnKey", required: true }] }], layouts: [{ type: i0.Input, args: [{ isSignal: true, alias: "layouts", required: true }] }], columnDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnDate", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], borderColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "borderColor", required: false }] }], resourceId: [{ type: i0.Input, args: [{ isSignal: true, alias: "resourceId", required: false }] }], gridLinesPx: [{ type: i0.Input, args: [{ isSignal: true, alias: "gridLinesPx", required: false }] }], labels: [{ type: i0.Input, args: [{ isSignal: true, alias: "labels", required: false }] }], editingLocked: [{ type: i0.Input, args: [{ isSignal: true, alias: "editingLocked", required: false }] }], dropped: [{ type: i0.Output, args: ["dropped"] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], eventEditRequested: [{ type: i0.Output, args: ["eventEditRequested"] }], eventDeleted: [{ type: i0.Output, args: ["eventDeleted"] }], eventUpdated: [{ type: i0.Output, args: ["eventUpdated"] }], eventDrawn: [{ type: i0.Output, args: ["eventDrawn"] }] } });

class BirthdayListComponent {
    destroyRef = inject(DestroyRef);
    layout = inject(GridLayoutService);
    birthdays = input.required(...(ngDevMode ? [{ debugName: "birthdays" }] : /* istanbul ignore next */ []));
    date = input.required(...(ngDevMode ? [{ debugName: "date" }] : /* istanbul ignore next */ []));
    opened = signal(false, ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    compact = signal(false, ...(ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []));
    firstNames = computed(() => this.birthdays().map((birthday) => birthday.firstName).join(', '), ...(ngDevMode ? [{ debugName: "firstNames" }] : /* istanbul ignore next */ []));
    fullNames = computed(() => this.birthdays().map((birthday) => `${birthday.firstName} ${birthday.lastName}`.trim()).join(', '), ...(ngDevMode ? [{ debugName: "fullNames" }] : /* istanbul ignore next */ []));
    details = computed(() => this.birthdays().map((birthday) => ({
        id: birthday.id,
        text: `${birthday.firstName} ${birthday.lastName}, ${birthday.birthDate.slice(0, 4)} (${this.layout.birthdayAge(birthday, this.date())})`,
    })), ...(ngDevMode ? [{ debugName: "details" }] : /* istanbul ignore next */ []));
    nameArea = viewChild.required('nameArea');
    measure = viewChild.required('measure');
    toggleOpened() {
        this.opened.update((opened) => !opened);
    }
    constructor() {
        afterNextRender(() => {
            const update = () => {
                this.compact.set(this.measure().nativeElement.offsetWidth > this.nameArea().nativeElement.clientWidth);
            };
            update();
            if (typeof ResizeObserver === 'undefined')
                return;
            const observer = new ResizeObserver(update);
            observer.observe(this.nameArea().nativeElement);
            observer.observe(this.measure().nativeElement);
            this.destroyRef.onDestroy(() => observer.disconnect());
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: BirthdayListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: BirthdayListComponent, isStandalone: true, selector: "glc-birthday-list", inputs: { birthdays: { classPropertyName: "birthdays", publicName: "birthdays", isSignal: true, isRequired: true, transformFunction: null }, date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: true, transformFunction: null } }, viewQueries: [{ propertyName: "nameArea", first: true, predicate: ["nameArea"], descendants: true, isSignal: true }, { propertyName: "measure", first: true, predicate: ["measure"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <button
      type="button"
      class="glc-grid-header__birthday"
      cdkOverlayOrigin
      #origin="cdkOverlayOrigin"
      [attr.aria-label]="fullNames()"
      [attr.aria-expanded]="opened()"
      (click)="toggleOpened()"
      (keydown.escape)="opened.set(false)"
    >
      <svg class="glc-grid-header__cake" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M5 11h14v10H5z M3 21h18 M5 15c2 3 5-3 7 0s5 0 7 0 M8 7v4 M12 7v4 M16 7v4 M8 3v1 M12 3v1 M16 3v1" />
      </svg>
      <span class="glc-grid-header__birthday-name" [hidden]="compact()">{{ firstNames() }}</span>
      <span #nameArea class="glc-grid-header__birthday-space" aria-hidden="true"></span>
      <span #measure class="glc-grid-header__birthday-measure" aria-hidden="true">{{ firstNames() }}</span>
    </button>
    <ng-template
      cdkConnectedOverlay
      [cdkConnectedOverlayOrigin]="origin"
      [cdkConnectedOverlayOpen]="opened()"
      [cdkConnectedOverlayPush]="true"
      (overlayOutsideClick)="opened.set(false)"
      (overlayKeydown)="$event.key === 'Escape' && opened.set(false)"
    >
      <div class="glc-grid-header__birthday-detail" role="status">
        @for (detail of details(); track detail.id) {
          <div class="glc-grid-header__birthday-person">{{ detail.text }}</div>
        }
      </div>
    </ng-template>
  `, isInline: true, styles: [":host{display:block;flex:1 1 0;min-width:0}.glc-grid-header__birthday{position:relative;display:flex;align-items:center;justify-content:flex-end;gap:.2rem;width:100%;min-width:0;padding:0;border:0;background:none;color:var(--glc-color-birthday, #b8860b);font:inherit;font-size:.75rem;cursor:pointer}.glc-grid-header__cake{flex:0 0 1em;width:1em;height:1em;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}.glc-grid-header__birthday-name{flex:0 0 auto;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:left}.glc-grid-header__birthday-space{position:absolute;width:calc(100% - 1em - .2rem);visibility:hidden;pointer-events:none}.glc-grid-header__birthday-measure{position:absolute;visibility:hidden;white-space:nowrap;pointer-events:none}.glc-grid-header__birthday-detail{display:block;max-width:min(20rem,90vw);overflow-wrap:anywhere;padding:.4rem .6rem;border:1px solid var(--glc-color-border, #ccc);border-radius:.25rem;background:var(--glc-color-background, Canvas);color:var(--glc-color-birthday, #b8860b);font-family:var(--glc-font-family, inherit);font-size:.85rem}\n"], dependencies: [{ kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation", "cdkConnectedOverlayUsePopover", "cdkConnectedOverlayMatchWidth", "cdkConnectedOverlay"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: BirthdayListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-birthday-list', imports: [OverlayModule], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <button
      type="button"
      class="glc-grid-header__birthday"
      cdkOverlayOrigin
      #origin="cdkOverlayOrigin"
      [attr.aria-label]="fullNames()"
      [attr.aria-expanded]="opened()"
      (click)="toggleOpened()"
      (keydown.escape)="opened.set(false)"
    >
      <svg class="glc-grid-header__cake" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M5 11h14v10H5z M3 21h18 M5 15c2 3 5-3 7 0s5 0 7 0 M8 7v4 M12 7v4 M16 7v4 M8 3v1 M12 3v1 M16 3v1" />
      </svg>
      <span class="glc-grid-header__birthday-name" [hidden]="compact()">{{ firstNames() }}</span>
      <span #nameArea class="glc-grid-header__birthday-space" aria-hidden="true"></span>
      <span #measure class="glc-grid-header__birthday-measure" aria-hidden="true">{{ firstNames() }}</span>
    </button>
    <ng-template
      cdkConnectedOverlay
      [cdkConnectedOverlayOrigin]="origin"
      [cdkConnectedOverlayOpen]="opened()"
      [cdkConnectedOverlayPush]="true"
      (overlayOutsideClick)="opened.set(false)"
      (overlayKeydown)="$event.key === 'Escape' && opened.set(false)"
    >
      <div class="glc-grid-header__birthday-detail" role="status">
        @for (detail of details(); track detail.id) {
          <div class="glc-grid-header__birthday-person">{{ detail.text }}</div>
        }
      </div>
    </ng-template>
  `, styles: [":host{display:block;flex:1 1 0;min-width:0}.glc-grid-header__birthday{position:relative;display:flex;align-items:center;justify-content:flex-end;gap:.2rem;width:100%;min-width:0;padding:0;border:0;background:none;color:var(--glc-color-birthday, #b8860b);font:inherit;font-size:.75rem;cursor:pointer}.glc-grid-header__cake{flex:0 0 1em;width:1em;height:1em;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}.glc-grid-header__birthday-name{flex:0 0 auto;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:left}.glc-grid-header__birthday-space{position:absolute;width:calc(100% - 1em - .2rem);visibility:hidden;pointer-events:none}.glc-grid-header__birthday-measure{position:absolute;visibility:hidden;white-space:nowrap;pointer-events:none}.glc-grid-header__birthday-detail{display:block;max-width:min(20rem,90vw);overflow-wrap:anywhere;padding:.4rem .6rem;border:1px solid var(--glc-color-border, #ccc);border-radius:.25rem;background:var(--glc-color-background, Canvas);color:var(--glc-color-birthday, #b8860b);font-family:var(--glc-font-family, inherit);font-size:.85rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { birthdays: [{ type: i0.Input, args: [{ isSignal: true, alias: "birthdays", required: true }] }], date: [{ type: i0.Input, args: [{ isSignal: true, alias: "date", required: true }] }], nameArea: [{ type: i0.ViewChild, args: ['nameArea', { isSignal: true }] }], measure: [{ type: i0.ViewChild, args: ['measure', { isSignal: true }] }] } });

class GridHeaderComponent {
    layout = inject(GridLayoutService);
    dayGroups = input.required(...(ngDevMode ? [{ debugName: "dayGroups" }] : /* istanbul ignore next */ []));
    birthdays = input([], ...(ngDevMode ? [{ debugName: "birthdays" }] : /* istanbul ignore next */ []));
    birthdaysByDate = computed(() => new Map(this.dayGroups().map((group) => [group.date, this.layout.birthdaysOnDate(this.birthdays(), group.date)])), ...(ngDevMode ? [{ debugName: "birthdaysByDate" }] : /* istanbul ignore next */ []));
    labels = input(DEFAULT_GRID_LABELS, ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    annotationsByColumn = input(new Map(), ...(ngDevMode ? [{ debugName: "annotationsByColumn" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: GridHeaderComponent, isStandalone: true, selector: "glc-grid-header", inputs: { dayGroups: { classPropertyName: "dayGroups", publicName: "dayGroups", isSignal: true, isRequired: true, transformFunction: null }, birthdays: { classPropertyName: "birthdays", publicName: "birthdays", isSignal: true, isRequired: false, transformFunction: null }, labels: { classPropertyName: "labels", publicName: "labels", isSignal: true, isRequired: false, transformFunction: null }, annotationsByColumn: { classPropertyName: "annotationsByColumn", publicName: "annotationsByColumn", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="glc-grid-header">
      @for (group of dayGroups(); track group.date.toISOString()) {
        <div class="glc-grid-header__day" [class.glc-grid-header__day--today]="group.isToday" [style.flex-grow]="group.columns.length">
          <div class="glc-grid-header__day-row">
            <span class="glc-grid-header__day-label">
              <span class="glc-grid-header__day-label-date">
                <span class="glc-grid-header__date-long">{{ group.date | date: 'EEEE dd.MM.yyyy' }}</span>
                <span class="glc-grid-header__date-medium">{{ group.date | date: 'EEE dd.MM.yyyy' }}</span>
                <span class="glc-grid-header__date-short">{{ group.date | date: 'EEEEEE dd.MM.yy' }}</span>
              </span>
              <span class="glc-grid-header__week-row">
                <span class="glc-grid-header__day-label-week">{{ labels().weekAbbreviation }} {{ group.weekNumber }}</span>
                @let dayBirthdays = birthdaysByDate().get(group.date) ?? [];
                @if (dayBirthdays.length) {
                  <glc-birthday-list [birthdays]="dayBirthdays" [date]="group.date" />
                }
              </span>
            </span>

          </div>
          <div class="glc-grid-header__annotations">
            @for (column of group.columns; track column.key) {
              <div class="glc-grid-header__annotation-cell">
                @for (annotation of annotationsByColumn().get(column.key) ?? []; track annotation.type + annotation.label) {
                  <span class="glc-grid-header__annotation glc-grid-header__annotation--{{ annotation.type }}">{{ annotation.label }}</span>
                }
              </div>
            }
          </div>
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;flex:1 1 auto;min-width:0}.glc-grid-header{display:flex;width:100%;gap:var(--glc-columns-gap, 8px)}.glc-grid-header__day{flex:1 1 0;min-width:0;display:flex;flex-direction:column;font-family:var(--glc-font-family, inherit);container-type:inline-size}.glc-grid-header__date-medium,.glc-grid-header__date-short{display:none}.glc-grid-header__day-row{display:flex;align-items:center;gap:.5rem;padding:var(--glc-header-padding, .5rem);flex-wrap:nowrap}.glc-grid-header__day-label{display:flex;flex-direction:column;line-height:1.25;min-width:0;flex:1 1 auto;text-align:left}.glc-grid-header__day-label-date{font-weight:600;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__day-label-week{flex:0 0 auto;font-weight:400;font-size:.75rem;opacity:.7;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__week-row{display:flex;align-items:center;flex-wrap:nowrap;gap:.25rem .5rem;min-width:0}.glc-grid-header__annotations{display:flex;height:1.4rem;flex:0 0 auto;min-width:0}.glc-grid-header__annotation-cell{flex:1 1 0;min-width:0;display:flex;align-items:center;gap:.2rem;padding:0 .4rem}.glc-grid-header__annotation{flex:1 1 0;min-width:0;font-size:.7rem;line-height:1.4;padding:.1rem .4rem;border-radius:.25rem;color:var(--glc-color-on-primary, #fff);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__annotation--holiday{background:var(--glc-color-holiday, #2e7d32)}.glc-grid-header__annotation--vacation{background:var(--glc-color-vacation, #1565c0)}.glc-grid-header__day--today .glc-grid-header__day-label-date,.glc-grid-header__day--today .glc-grid-header__day-label-week{color:var(--glc-color-today, #d32f2f)}.glc-grid-header__day--today .glc-grid-header__day-label-date{font-weight:700}@container (width < 9.5rem){.glc-grid-header__date-long{display:none}.glc-grid-header__date-medium{display:inline}}@container (width < 7rem){.glc-grid-header__date-medium{display:none}.glc-grid-header__date-short{display:inline}}\n"], dependencies: [{ kind: "component", type: BirthdayListComponent, selector: "glc-birthday-list", inputs: ["birthdays", "date"] }, { kind: "pipe", type: DatePipe, name: "date" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-grid-header', imports: [DatePipe, BirthdayListComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="glc-grid-header">
      @for (group of dayGroups(); track group.date.toISOString()) {
        <div class="glc-grid-header__day" [class.glc-grid-header__day--today]="group.isToday" [style.flex-grow]="group.columns.length">
          <div class="glc-grid-header__day-row">
            <span class="glc-grid-header__day-label">
              <span class="glc-grid-header__day-label-date">
                <span class="glc-grid-header__date-long">{{ group.date | date: 'EEEE dd.MM.yyyy' }}</span>
                <span class="glc-grid-header__date-medium">{{ group.date | date: 'EEE dd.MM.yyyy' }}</span>
                <span class="glc-grid-header__date-short">{{ group.date | date: 'EEEEEE dd.MM.yy' }}</span>
              </span>
              <span class="glc-grid-header__week-row">
                <span class="glc-grid-header__day-label-week">{{ labels().weekAbbreviation }} {{ group.weekNumber }}</span>
                @let dayBirthdays = birthdaysByDate().get(group.date) ?? [];
                @if (dayBirthdays.length) {
                  <glc-birthday-list [birthdays]="dayBirthdays" [date]="group.date" />
                }
              </span>
            </span>

          </div>
          <div class="glc-grid-header__annotations">
            @for (column of group.columns; track column.key) {
              <div class="glc-grid-header__annotation-cell">
                @for (annotation of annotationsByColumn().get(column.key) ?? []; track annotation.type + annotation.label) {
                  <span class="glc-grid-header__annotation glc-grid-header__annotation--{{ annotation.type }}">{{ annotation.label }}</span>
                }
              </div>
            }
          </div>
        </div>
      }
    </div>
  `, styles: [":host{display:block;flex:1 1 auto;min-width:0}.glc-grid-header{display:flex;width:100%;gap:var(--glc-columns-gap, 8px)}.glc-grid-header__day{flex:1 1 0;min-width:0;display:flex;flex-direction:column;font-family:var(--glc-font-family, inherit);container-type:inline-size}.glc-grid-header__date-medium,.glc-grid-header__date-short{display:none}.glc-grid-header__day-row{display:flex;align-items:center;gap:.5rem;padding:var(--glc-header-padding, .5rem);flex-wrap:nowrap}.glc-grid-header__day-label{display:flex;flex-direction:column;line-height:1.25;min-width:0;flex:1 1 auto;text-align:left}.glc-grid-header__day-label-date{font-weight:600;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__day-label-week{flex:0 0 auto;font-weight:400;font-size:.75rem;opacity:.7;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__week-row{display:flex;align-items:center;flex-wrap:nowrap;gap:.25rem .5rem;min-width:0}.glc-grid-header__annotations{display:flex;height:1.4rem;flex:0 0 auto;min-width:0}.glc-grid-header__annotation-cell{flex:1 1 0;min-width:0;display:flex;align-items:center;gap:.2rem;padding:0 .4rem}.glc-grid-header__annotation{flex:1 1 0;min-width:0;font-size:.7rem;line-height:1.4;padding:.1rem .4rem;border-radius:.25rem;color:var(--glc-color-on-primary, #fff);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.glc-grid-header__annotation--holiday{background:var(--glc-color-holiday, #2e7d32)}.glc-grid-header__annotation--vacation{background:var(--glc-color-vacation, #1565c0)}.glc-grid-header__day--today .glc-grid-header__day-label-date,.glc-grid-header__day--today .glc-grid-header__day-label-week{color:var(--glc-color-today, #d32f2f)}.glc-grid-header__day--today .glc-grid-header__day-label-date{font-weight:700}@container (width < 9.5rem){.glc-grid-header__date-long{display:none}.glc-grid-header__date-medium{display:inline}}@container (width < 7rem){.glc-grid-header__date-medium{display:none}.glc-grid-header__date-short{display:inline}}\n"] }]
        }], propDecorators: { dayGroups: [{ type: i0.Input, args: [{ isSignal: true, alias: "dayGroups", required: true }] }], birthdays: [{ type: i0.Input, args: [{ isSignal: true, alias: "birthdays", required: false }] }], labels: [{ type: i0.Input, args: [{ isSignal: true, alias: "labels", required: false }] }], annotationsByColumn: [{ type: i0.Input, args: [{ isSignal: true, alias: "annotationsByColumn", required: false }] }] } });

class TimeAxisComponent {
    layoutService = inject(GridLayoutService);
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** Eine Markierung pro voller Stunde im Arbeitszeit-Fenster, Position via GridLayoutService. */
    hourMarks = computed(() => {
        const config = this.config();
        return this.layoutService
            .computeGridLines({ ...config, gridLineIntervalMinutes: 60 })
            .filter((line) => line.isHour)
            .map((line) => ({
            label: this.layoutService.formatGridLineTime(line),
            topPx: line.offsetPx,
        }));
    }, ...(ngDevMode ? [{ debugName: "hourMarks" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TimeAxisComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: TimeAxisComponent, isStandalone: true, selector: "glc-time-axis", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <div class="glc-time-axis">
      @for (mark of hourMarks(); track mark.label) {
        <div class="glc-time-axis__mark" [style.top.px]="mark.topPx">{{ mark.label }}</div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;flex:0 0 auto;width:var(--glc-time-axis-width, 3.5rem)}.glc-time-axis{position:relative;width:100%;height:100%;font-family:var(--glc-font-family, inherit);color:var(--glc-color-border, #666)}.glc-time-axis__mark{position:absolute;left:0;right:0;box-sizing:border-box;transform:translateY(-50%);font-size:.75rem;font-weight:700;color:var(--glc-color-hour-line, var(--glc-color-text, #222));text-align:right;padding-right:.35rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TimeAxisComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-time-axis', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="glc-time-axis">
      @for (mark of hourMarks(); track mark.label) {
        <div class="glc-time-axis__mark" [style.top.px]="mark.topPx">{{ mark.label }}</div>
      }
    </div>
  `, styles: [":host{display:block;flex:0 0 auto;width:var(--glc-time-axis-width, 3.5rem)}.glc-time-axis{position:relative;width:100%;height:100%;font-family:var(--glc-font-family, inherit);color:var(--glc-color-border, #666)}.glc-time-axis__mark{position:absolute;left:0;right:0;box-sizing:border-box;transform:translateY(-50%);font-size:.75rem;font-weight:700;color:var(--glc-color-hour-line, var(--glc-color-text, #222));text-align:right;padding-right:.35rem}\n"] }]
        }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }] } });

class TaskListColumnComponent {
    tasks = input([], ...(ngDevMode ? [{ debugName: "tasks" }] : /* istanbul ignore next */ []));
    resources = input([], ...(ngDevMode ? [{ debugName: "resources" }] : /* istanbul ignore next */ []));
    showCompleted = input(false, ...(ngDevMode ? [{ debugName: "showCompleted" }] : /* istanbul ignore next */ []));
    labels = input(DEFAULT_GRID_LABELS, ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    tasksChange = output();
    commentsRequested = output();
    expandedIds = signal(new Set(), ...(ngDevMode ? [{ debugName: "expandedIds" }] : /* istanbul ignore next */ []));
    rows = computed(() => {
        const tasks = this.tasks();
        const labels = this.labels();
        const resourceColors = new Map(this.resources().map((resource) => [resource.id, resource.color]));
        const childrenByParent = new Map();
        for (const task of tasks) {
            if (task.parentId === undefined)
                continue;
            const children = childrenByParent.get(task.parentId) ?? [];
            children.push(task);
            childrenByParent.set(task.parentId, children);
        }
        return tasks
            .filter((task) => task.parentId === undefined)
            .map((task) => {
            const children = childrenByParent.get(task.id) ?? [];
            const completed = children.length > 0 ? children.every((child) => child.completed) : task.completed;
            const expanded = this.expandedIds().has(task.id);
            const view = {
                ...this.taskItem(task, completed, resourceColors, labels),
                expandLabel: fillLabel(expanded ? labels.collapseSubtasks : labels.expandSubtasks, {
                    name: task.name,
                    count: children.length,
                }),
                hasChildren: children.length > 0,
                expanded,
                children: children
                    .filter(() => this.showCompleted() || !completed)
                    .map((child) => this.taskItem(child, child.completed, resourceColors, labels)),
            };
            return view;
        })
            .filter((row) => this.showCompleted() || !row.completed);
    }, ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    taskItem(task, completed, resourceColors, labels) {
        const commentsCount = task.comments?.length ?? 0;
        const resourceColor = resourceColors.get(task.resourceId);
        return {
            task,
            completed,
            commentsCount,
            commentsLabel: commentsCount ? fillLabel(labels.showNotes, { count: commentsCount }) : labels.addNote,
            resourceColor,
        };
    }
    toggleExpanded(id) {
        this.expandedIds.update((expanded) => {
            const next = new Set(expanded);
            if (next.has(id))
                next.delete(id);
            else
                next.add(id);
            return next;
        });
    }
    toggleCompleted(id, completed) {
        const tasks = this.tasks();
        const target = tasks.find((task) => task.id === id);
        if (!target)
            return;
        const children = tasks.filter((task) => task.parentId === id);
        if (children.length)
            return;
        const updated = tasks.map((task) => (task.id === id ? { ...task, completed } : task));
        if (target.parentId !== undefined) {
            const parentChildren = updated.filter((task) => task.parentId === target.parentId);
            const parentCompleted = parentChildren.every((child) => child.completed);
            this.tasksChange.emit(updated.map((task) => (task.id === target.parentId ? { ...task, completed: parentCompleted } : task)));
            return;
        }
        this.tasksChange.emit(updated);
    }
    onCheckboxChange(id, event) {
        this.toggleCompleted(id, event.target.checked);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TaskListColumnComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: TaskListColumnComponent, isStandalone: true, selector: "glc-task-list-column", inputs: { tasks: { classPropertyName: "tasks", publicName: "tasks", isSignal: true, isRequired: false, transformFunction: null }, resources: { classPropertyName: "resources", publicName: "resources", isSignal: true, isRequired: false, transformFunction: null }, showCompleted: { classPropertyName: "showCompleted", publicName: "showCompleted", isSignal: true, isRequired: false, transformFunction: null }, labels: { classPropertyName: "labels", publicName: "labels", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { tasksChange: "tasksChange", commentsRequested: "commentsRequested" }, ngImport: i0, template: `
    <section class="glc-task-list-column" [attr.aria-label]="labels().taskColumn">
      @for (row of rows(); track row.task.id) {
        <div
          class="glc-task-list-column__group"
          [style.--glc-task-color]="row.resourceColor"
        >
          <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="row.commentsLabel" (click)="commentsRequested.emit(row.task.id)">{{ row.commentsCount }}</button>
          <article
            class="glc-task-list-column__card"
            [class.glc-task-list-column__card--completed]="row.completed"
          >
            @if (row.hasChildren) {
              <span
                class="glc-task-list-column__name glc-task-list-column__name--expandable"
                role="button"
                tabindex="0"
                [attr.aria-label]="row.expandLabel"
                [attr.aria-expanded]="row.expanded"
                (click)="toggleExpanded(row.task.id)"
                (keydown.enter)="toggleExpanded(row.task.id)"
                (keydown.space)="toggleExpanded(row.task.id); $event.preventDefault()"
              >{{ row.task.name }}</span>
            } @else {
              <span class="glc-task-list-column__name">{{ row.task.name }}</span>
            }
            <input
              type="checkbox"
              [checked]="row.completed"
              [disabled]="row.hasChildren"
              [attr.aria-label]="row.task.name"
              (change)="onCheckboxChange(row.task.id, $event)"
            />
          </article>
          @if (row.expanded) {
            <div class="glc-task-list-column__children">
              @for (child of row.children; track child.task.id) {
                <article
                  class="glc-task-list-column__card glc-task-list-column__card--child"
                  [class.glc-task-list-column__card--completed]="child.completed"
                  [style.--glc-task-color]="child.resourceColor"
                >
                  <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="child.commentsLabel" (click)="commentsRequested.emit(child.task.id)">{{ child.commentsCount }}</button>
                  <span class="glc-task-list-column__name">{{ child.task.name }}</span>
                  <input
                    type="checkbox"
                    [checked]="child.completed"
                    [attr.aria-label]="child.task.name"
                    (change)="onCheckboxChange(child.task.id, $event)"
                  />
                </article>
              }
            </div>
          }
        </div>
      } @empty {
      }
    </section>
  `, isInline: true, styles: ["@charset \"UTF-8\";:host{display:block;box-sizing:border-box;flex:1 1 0;min-width:0;overflow:visible;container-type:inline-size}.glc-task-list-column{display:flex;flex-direction:column;gap:.35rem;box-sizing:border-box;min-width:0;overflow:visible;padding:0 .55rem 0 1px}.glc-task-list-column__group{position:relative;min-width:0;overflow:visible;border:1px solid var(--glc-color-border, #ccc);border-left:3px solid var(--glc-task-color, var(--glc-color-task-default, #495057));border-radius:var(--glc-task-radius, 4px);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 18%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card{position:relative;display:flex;align-items:center;gap:.3rem;min-width:0;min-height:28px;padding:.25rem .2rem .25rem .4rem;line-height:1.35;font-family:var(--glc-font-family, inherit);font-size:.75rem}.glc-task-list-column__card--child{min-height:26px;padding-left:.65rem;border-top:1px solid color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 30%,transparent);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 10%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card--completed .glc-task-list-column__name{text-decoration:line-through;opacity:.75}.glc-task-list-column__children{box-sizing:border-box;padding-left:.5rem;border-left:1px solid var(--glc-color-border, #ccc)}.glc-task-list-column__name{flex:1 1 auto;min-width:0;border:0;padding:0;background:transparent;color:inherit;font:inherit;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:left}.glc-task-list-column__name--expandable{cursor:pointer;text-decoration:underline dotted;text-underline-offset:2px}.glc-task-list-column__note-action{position:absolute;top:-.0625rem;right:-.5625rem;z-index:1;display:grid;box-sizing:border-box;place-items:center;width:1rem;height:1rem;padding:0;transform:translateY(-50%);cursor:pointer}.glc-task-list-column__note-action:before{content:\"\";position:absolute;inset:-4px}.glc-task-list-column__comment-count{border:1px solid var(--glc-task-color, var(--glc-color-task-count, #d9364f));border-radius:50%;background:var(--glc-color-task-count-background, var(--glc-color-background, #fff));color:var(--glc-task-color, var(--glc-color-task-count, #d9364f));font-family:var(--glc-font-family, inherit);font-size:.65rem;font-weight:600;line-height:1}.glc-task-list-column__comment-count:hover{background:var(--glc-color-task-count-background, var(--glc-color-background, #fff))}.glc-task-list-column input[type=checkbox]{position:relative;display:inline-grid;flex:0 0 1rem;width:1rem;height:1rem;place-items:center;margin:0 0 0 .25rem;appearance:none;border:1px solid var(--glc-task-color, var(--glc-color-border, #ccc));border-radius:50%;background:var(--glc-color-background, #fff);cursor:pointer}.glc-task-list-column input[type=checkbox]:before{content:\"\";position:absolute;inset:-4px}.glc-task-list-column input[type=checkbox]:after{content:\"\\2713\";color:var(--glc-task-color, var(--glc-color-success, #2f9e44));font-size:.75rem;font-weight:700;line-height:1;transform:scale(0)}.glc-task-list-column input[type=checkbox]:checked{border-color:var(--glc-task-color, var(--glc-color-success, #2f9e44))}.glc-task-list-column input[type=checkbox]:checked:after{transform:scale(1)}.glc-task-list-column input[type=checkbox]:disabled{cursor:default}.glc-task-list-column input[type=checkbox]:focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px}.glc-task-list-column :focus:not(:focus-visible){outline:none}.glc-task-list-column :focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px;border-radius:2px}@container (max-width: 72px){.glc-task-list-column__children{padding-left:.25rem}}@container (max-width: 7rem){.glc-task-list-column__card{flex-wrap:wrap;row-gap:.15rem}.glc-task-list-column__name{flex:1 1 100%;overflow-wrap:break-word;-webkit-hyphens:auto;hyphens:auto;font-size:.65rem;white-space:normal;text-overflow:clip;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;line-clamp:3}.glc-task-list-column__card input[type=checkbox]{margin-left:auto}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: TaskListColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'glc-task-list-column', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <section class="glc-task-list-column" [attr.aria-label]="labels().taskColumn">
      @for (row of rows(); track row.task.id) {
        <div
          class="glc-task-list-column__group"
          [style.--glc-task-color]="row.resourceColor"
        >
          <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="row.commentsLabel" (click)="commentsRequested.emit(row.task.id)">{{ row.commentsCount }}</button>
          <article
            class="glc-task-list-column__card"
            [class.glc-task-list-column__card--completed]="row.completed"
          >
            @if (row.hasChildren) {
              <span
                class="glc-task-list-column__name glc-task-list-column__name--expandable"
                role="button"
                tabindex="0"
                [attr.aria-label]="row.expandLabel"
                [attr.aria-expanded]="row.expanded"
                (click)="toggleExpanded(row.task.id)"
                (keydown.enter)="toggleExpanded(row.task.id)"
                (keydown.space)="toggleExpanded(row.task.id); $event.preventDefault()"
              >{{ row.task.name }}</span>
            } @else {
              <span class="glc-task-list-column__name">{{ row.task.name }}</span>
            }
            <input
              type="checkbox"
              [checked]="row.completed"
              [disabled]="row.hasChildren"
              [attr.aria-label]="row.task.name"
              (change)="onCheckboxChange(row.task.id, $event)"
            />
          </article>
          @if (row.expanded) {
            <div class="glc-task-list-column__children">
              @for (child of row.children; track child.task.id) {
                <article
                  class="glc-task-list-column__card glc-task-list-column__card--child"
                  [class.glc-task-list-column__card--completed]="child.completed"
                  [style.--glc-task-color]="child.resourceColor"
                >
                  <button type="button" class="glc-task-list-column__note-action glc-task-list-column__comment-count" [attr.aria-label]="child.commentsLabel" (click)="commentsRequested.emit(child.task.id)">{{ child.commentsCount }}</button>
                  <span class="glc-task-list-column__name">{{ child.task.name }}</span>
                  <input
                    type="checkbox"
                    [checked]="child.completed"
                    [attr.aria-label]="child.task.name"
                    (change)="onCheckboxChange(child.task.id, $event)"
                  />
                </article>
              }
            </div>
          }
        </div>
      } @empty {
      }
    </section>
  `, styles: ["@charset \"UTF-8\";:host{display:block;box-sizing:border-box;flex:1 1 0;min-width:0;overflow:visible;container-type:inline-size}.glc-task-list-column{display:flex;flex-direction:column;gap:.35rem;box-sizing:border-box;min-width:0;overflow:visible;padding:0 .55rem 0 1px}.glc-task-list-column__group{position:relative;min-width:0;overflow:visible;border:1px solid var(--glc-color-border, #ccc);border-left:3px solid var(--glc-task-color, var(--glc-color-task-default, #495057));border-radius:var(--glc-task-radius, 4px);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 18%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card{position:relative;display:flex;align-items:center;gap:.3rem;min-width:0;min-height:28px;padding:.25rem .2rem .25rem .4rem;line-height:1.35;font-family:var(--glc-font-family, inherit);font-size:.75rem}.glc-task-list-column__card--child{min-height:26px;padding-left:.65rem;border-top:1px solid color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 30%,transparent);background:color-mix(in srgb,var(--glc-task-color, var(--glc-color-task-default, #495057)) 10%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222)}.glc-task-list-column__card--completed .glc-task-list-column__name{text-decoration:line-through;opacity:.75}.glc-task-list-column__children{box-sizing:border-box;padding-left:.5rem;border-left:1px solid var(--glc-color-border, #ccc)}.glc-task-list-column__name{flex:1 1 auto;min-width:0;border:0;padding:0;background:transparent;color:inherit;font:inherit;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:left}.glc-task-list-column__name--expandable{cursor:pointer;text-decoration:underline dotted;text-underline-offset:2px}.glc-task-list-column__note-action{position:absolute;top:-.0625rem;right:-.5625rem;z-index:1;display:grid;box-sizing:border-box;place-items:center;width:1rem;height:1rem;padding:0;transform:translateY(-50%);cursor:pointer}.glc-task-list-column__note-action:before{content:\"\";position:absolute;inset:-4px}.glc-task-list-column__comment-count{border:1px solid var(--glc-task-color, var(--glc-color-task-count, #d9364f));border-radius:50%;background:var(--glc-color-task-count-background, var(--glc-color-background, #fff));color:var(--glc-task-color, var(--glc-color-task-count, #d9364f));font-family:var(--glc-font-family, inherit);font-size:.65rem;font-weight:600;line-height:1}.glc-task-list-column__comment-count:hover{background:var(--glc-color-task-count-background, var(--glc-color-background, #fff))}.glc-task-list-column input[type=checkbox]{position:relative;display:inline-grid;flex:0 0 1rem;width:1rem;height:1rem;place-items:center;margin:0 0 0 .25rem;appearance:none;border:1px solid var(--glc-task-color, var(--glc-color-border, #ccc));border-radius:50%;background:var(--glc-color-background, #fff);cursor:pointer}.glc-task-list-column input[type=checkbox]:before{content:\"\";position:absolute;inset:-4px}.glc-task-list-column input[type=checkbox]:after{content:\"\\2713\";color:var(--glc-task-color, var(--glc-color-success, #2f9e44));font-size:.75rem;font-weight:700;line-height:1;transform:scale(0)}.glc-task-list-column input[type=checkbox]:checked{border-color:var(--glc-task-color, var(--glc-color-success, #2f9e44))}.glc-task-list-column input[type=checkbox]:checked:after{transform:scale(1)}.glc-task-list-column input[type=checkbox]:disabled{cursor:default}.glc-task-list-column input[type=checkbox]:focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px}.glc-task-list-column :focus:not(:focus-visible){outline:none}.glc-task-list-column :focus-visible{outline:2px solid var(--glc-color-primary, #d9364f);outline-offset:2px;border-radius:2px}@container (max-width: 72px){.glc-task-list-column__children{padding-left:.25rem}}@container (max-width: 7rem){.glc-task-list-column__card{flex-wrap:wrap;row-gap:.15rem}.glc-task-list-column__name{flex:1 1 100%;overflow-wrap:break-word;-webkit-hyphens:auto;hyphens:auto;font-size:.65rem;white-space:normal;text-overflow:clip;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;line-clamp:3}.glc-task-list-column__card input[type=checkbox]{margin-left:auto}}\n"] }]
        }], propDecorators: { tasks: [{ type: i0.Input, args: [{ isSignal: true, alias: "tasks", required: false }] }], resources: [{ type: i0.Input, args: [{ isSignal: true, alias: "resources", required: false }] }], showCompleted: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCompleted", required: false }] }], labels: [{ type: i0.Input, args: [{ isSignal: true, alias: "labels", required: false }] }], tasksChange: [{ type: i0.Output, args: ["tasksChange"] }], commentsRequested: [{ type: i0.Output, args: ["commentsRequested"] }] } });

/** Öffentlicher Library-Einstiegspunkt mit Event-Raster und datumsgelagerter Task-Zeile. */
class GridCalendar {
    hostElement = inject((ElementRef));
    themeService = inject(ThemeService);
    destroyRef = inject(DestroyRef);
    layoutService = inject(GridLayoutService);
    state = inject(GridStateService);
    bodyEl = viewChild('bodyEl', ...(ngDevMode ? [{ debugName: "bodyEl" }] : /* istanbul ignore next */ []));
    cancelPan = null;
    event = input(undefined, ...(ngDevMode ? [{ debugName: "event" }] : /* istanbul ignore next */ []));
    events = input([], ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    tasks = input([], ...(ngDevMode ? [{ debugName: "tasks" }] : /* istanbul ignore next */ []));
    showCompletedTasks = input(false, ...(ngDevMode ? [{ debugName: "showCompletedTasks" }] : /* istanbul ignore next */ []));
    contentMode = input('both', ...(ngDevMode ? [{ debugName: "contentMode" }] : /* istanbul ignore next */ []));
    resource = input(undefined, ...(ngDevMode ? [{ debugName: "resource" }] : /* istanbul ignore next */ []));
    resources = input([], ...(ngDevMode ? [{ debugName: "resources" }] : /* istanbul ignore next */ []));
    birthdays = input([], ...(ngDevMode ? [{ debugName: "birthdays" }] : /* istanbul ignore next */ []));
    data = input({}, ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    viewMode = input('week', ...(ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []));
    columnMode = input('date', ...(ngDevMode ? [{ debugName: "columnMode" }] : /* istanbul ignore next */ []));
    anchorDate = input(new Date(), ...(ngDevMode ? [{ debugName: "anchorDate" }] : /* istanbul ignore next */ []));
    theme = input({}, ...(ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []));
    /** Feiertage und Ferien je Person, angezeigt unter dem Personen-Pill (columnMode 'resource'). */
    dayAnnotations = input([], ...(ngDevMode ? [{ debugName: "dayAnnotations" }] : /* istanbul ignore next */ []));
    /** Überschreibt einzelne Beschriftungen; nicht gesetzte bleiben deutsch. */
    labels = input({}, ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    config = input(DEFAULT_GRID_CONFIG, ...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** Veto-Hook für Drag&Drop: wird beim Drop ausgewertet, `false` verwirft das Verschieben. */
    canMoveEvent = input(() => true, ...(ngDevMode ? [{ debugName: "canMoveEvent" }] : /* istanbul ignore next */ []));
    /** Sperrt alle Event-Interaktionen (Maus, Touch, Tastatur); Standard ist gesperrt, per Schloss-Button umschaltbar. */
    editingLocked = model(true, ...(ngDevMode ? [{ debugName: "editingLocked" }] : /* istanbul ignore next */ []));
    /** Mindestbreite je Spalte in px; wird unterschritten, scrollt das Grid horizontal. 0 = aus. */
    minColumnWidth = input(0, ...(ngDevMode ? [{ debugName: "minColumnWidth" }] : /* istanbul ignore next */ []));
    toggleEditingLocked() {
        this.editingLocked.update((locked) => !locked);
    }
    eventsChange = output();
    tasksChange = output();
    eventMoved = output();
    eventClicked = output();
    /** Doppelklick auf einen Event: ID für einen Editor der Host-App. */
    eventEditRequested = output();
    eventDeleted = output();
    eventUpdated = output();
    eventCreateRequested = output();
    /** Verworfene Aktion, weil sie einen anderen Event überschneiden würde. */
    overlapRejected = output();
    taskCommentsRequested = output();
    /** Neuer sichtbarer Zeitraum nach Blättern oder Heute; die Host-App lädt die Daten dafür nach. */
    visibleRangeChange = output();
    /** Pills-Zeile (Personen-Namen) wird nur in columnMode 'resource' gerendert. */
    hasResourceColumns = computed(() => this.state.dayGroups().some((group) => group.columns.some((column) => !!column.resource)), ...(ngDevMode ? [{ debugName: "hasResourceColumns" }] : /* istanbul ignore next */ []));
    nowLabel = computed(() => this.layoutService.formatTime(this.state.now()), ...(ngDevMode ? [{ debugName: "nowLabel" }] : /* istanbul ignore next */ []));
    effectiveLabels = computed(() => ({ ...DEFAULT_GRID_LABELS, ...this.labels() }), ...(ngDevMode ? [{ debugName: "effectiveLabels" }] : /* istanbul ignore next */ []));
    scrollable = computed(() => this.minColumnWidth() > 0, ...(ngDevMode ? [{ debugName: "scrollable" }] : /* istanbul ignore next */ []));
    columnsMinWidthPx = computed(() => this.layoutService.computeColumnsMinWidthPx(this.state.dayGroups().map((group) => group.columns.length), this.minColumnWidth()), ...(ngDevMode ? [{ debugName: "columnsMinWidthPx" }] : /* istanbul ignore next */ []));
    normalizedEvents = computed(() => mergeById(this.data().events ?? [], this.events(), this.event()), ...(ngDevMode ? [{ debugName: "normalizedEvents" }] : /* istanbul ignore next */ []));
    normalizedResources = computed(() => mergeById(this.data().resources ?? [], this.resources(), this.resource()), ...(ngDevMode ? [{ debugName: "normalizedResources" }] : /* istanbul ignore next */ []));
    normalizedTasks = computed(() => mergeById(this.data().tasks ?? [], this.tasks()), ...(ngDevMode ? [{ debugName: "normalizedTasks" }] : /* istanbul ignore next */ []));
    /** Platz unter der letzten Stundenlinie für Personen-Rahmen und die halbe Beschriftung "18:00"; wird von der Stundenhöhe abgezogen. */
    frameBottomBufferPx = 10;
    taskFrameMinHeightPx = computed(() => this.layoutService.computeTaskFrameMinHeight([...this.state.tasksByColumn().values()], this.showCompletedTasks()), ...(ngDevMode ? [{ debugName: "taskFrameMinHeightPx" }] : /* istanbul ignore next */ []));
    constructor() {
        this.state.connect({
            events: this.normalizedEvents,
            tasks: this.normalizedTasks,
            resources: this.normalizedResources,
            dayAnnotations: this.dayAnnotations,
            viewMode: this.viewMode,
            columnMode: this.columnMode,
            anchorDate: this.anchorDate,
            config: this.config,
        });
        effect(() => this.themeService.apply(this.theme(), this.hostElement.nativeElement));
        this.destroyRef.onDestroy(() => this.cancelPan?.());
        // Misst die verfügbare Höhe des Grid-Bodys, damit GridStateService die Stunden ohne
        // Scrollen exakt in den Container stauchen kann (siehe effectiveConfig).
        afterNextRender(() => {
            const element = this.bodyEl()?.nativeElement;
            if (!element || typeof ResizeObserver === 'undefined') {
                return;
            }
            const observer = new ResizeObserver((entries) => {
                const height = entries[0]?.contentRect.height ?? 0;
                this.state.setContainerHeightPx(Math.max(0, height - this.frameBottomBufferPx));
            });
            observer.observe(element);
            this.destroyRef.onDestroy(() => observer.disconnect());
        });
    }
    onPanStart(event, scroll) {
        if (!this.editingLocked() || !this.scrollable() || event.pointerType !== 'mouse' ||
            event.button !== 0 || scroll.scrollWidth <= scroll.clientWidth) {
            return;
        }
        event.preventDefault();
        this.cancelPan?.();
        const doc = scroll.ownerDocument;
        const startX = event.clientX;
        const startScrollLeft = scroll.scrollLeft;
        const pointerId = event.pointerId;
        const stop = () => {
            doc.removeEventListener('pointermove', onMove);
            doc.removeEventListener('pointerup', onEnd);
            doc.removeEventListener('pointercancel', onEnd);
            doc.defaultView?.removeEventListener('blur', stop);
            this.cancelPan = null;
        };
        const onMove = (move) => {
            if (move.pointerId !== pointerId)
                return;
            if (!this.editingLocked() || !this.scrollable() || (move.buttons & 1) === 0) {
                stop();
                return;
            }
            scroll.scrollLeft = startScrollLeft + startX - move.clientX;
        };
        const onEnd = (end) => {
            if (end.pointerId === pointerId)
                stop();
        };
        doc.addEventListener('pointermove', onMove);
        doc.addEventListener('pointerup', onEnd);
        doc.addEventListener('pointercancel', onEnd);
        doc.defaultView?.addEventListener('blur', stop);
        this.cancelPan = stop;
    }
    navigate(direction) {
        this.state.shiftVisibleRange(direction);
        this.emitVisibleRange();
    }
    goToInitialView() {
        this.state.resetVisibleRange();
        this.emitVisibleRange();
    }
    emitVisibleRange() {
        const dates = this.state.visibleDates();
        this.visibleRangeChange.emit({ viewMode: this.viewMode(), from: dates[0], to: dates[dates.length - 1] });
    }
    /** Berechnet aus dem CDK-Drop-Event die neue Start-/Endzeit (und ggf. Ressource) und meldet sie nach außen. */
    onColumnDropped(dropEvent) {
        const calendarEvent = dropEvent.item.data;
        if (this.editingLocked() || calendarEvent.locked || !this.canMoveEvent()(calendarEvent)) {
            return;
        }
        const anchor = this.state.dragAnchor();
        this.state.setDragAnchor(null);
        // Zielspalte = Spalte, in der die Vorschau eingerastet war (nicht die unter dem Mauszeiger).
        const targetKey = anchor?.columnKey ?? dropEvent.container.data;
        const targetColumn = this.state.flatColumns().find((column) => column.key === targetKey);
        if (!targetColumn) {
            return;
        }
        const config = this.state.effectiveConfig();
        const referenceDate = targetColumn.date ?? this.state.visibleDates()[0];
        // Ohne Bewegung bleibt der Event auf seiner bisherigen Linie.
        const line = anchor?.line ??
            this.layoutService.nearestGridLine(this.state.gridLinesPx(), this.layoutService.timeToOffset(new Date(calendarEvent.start), config));
        const newStart = this.layoutService.timeOnGridLine(line, referenceDate);
        const durationMs = new Date(calendarEvent.end).getTime() - new Date(calendarEvent.start).getTime();
        const newEnd = new Date(newStart.getTime() + durationMs);
        const updatedEvent = {
            ...calendarEvent,
            start: newStart.toISOString(),
            end: newEnd.toISOString(),
            resourceId: targetColumn.resource?.id ?? calendarEvent.resourceId,
        };
        const conflicts = this.state.conflictsWith(updatedEvent);
        if (conflicts.length > 0) {
            this.overlapRejected.emit({ event: updatedEvent, conflicts });
            return;
        }
        const updatedEvents = this.normalizedEvents().map((existing) => (existing.id === updatedEvent.id ? updatedEvent : existing));
        this.eventsChange.emit(updatedEvents);
        this.eventMoved.emit(updatedEvent);
    }
    /** Entfernt einen Event aus dem Array und meldet die Änderung nach außen (immutable). */
    onEventDeleted(event) {
        if (this.editingLocked() || event.locked)
            return;
        const updatedEvents = this.normalizedEvents().filter((existing) => existing.id !== event.id);
        this.eventsChange.emit(updatedEvents);
        this.eventDeleted.emit(event);
    }
    /** Aktualisiert einen Event (z. B. durch Resize) und meldet die Änderung nach außen (immutable). */
    onEventUpdated(updatedEvent) {
        if (this.editingLocked() || updatedEvent.locked)
            return;
        const conflicts = this.state.conflictsWith(updatedEvent);
        if (conflicts.length > 0) {
            this.overlapRejected.emit({ event: updatedEvent, conflicts });
            return;
        }
        const updatedEvents = this.normalizedEvents().map((existing) => (existing.id === updatedEvent.id ? updatedEvent : existing));
        this.eventsChange.emit(updatedEvents);
        this.eventUpdated.emit(updatedEvent);
    }
    onEventDrawn(request) {
        if (this.editingLocked())
            return;
        const draft = {
            id: this.nextDraftId(),
            title: '',
            start: request.start,
            end: request.end,
            resourceId: request.resourceId,
            isDraft: true,
        };
        const conflicts = this.state.conflictsWith(draft);
        if (conflicts.length > 0) {
            this.overlapRejected.emit({ event: draft, conflicts });
            return;
        }
        this.eventsChange.emit([...this.normalizedEvents(), draft]);
        this.eventCreateRequested.emit(draft);
    }
    onTasksChanged(updatedTasks) {
        const updatedIds = new Set(updatedTasks.map((task) => task.id));
        const tasks = [...this.normalizedTasks().filter((task) => !updatedIds.has(task.id)), ...updatedTasks];
        this.tasksChange.emit(tasks);
    }
    nextDraftId() {
        const negativeIds = this.normalizedEvents().map((event) => event.id).filter((id) => id < 0);
        return Math.min(0, ...negativeIds) - 1;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridCalendar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.22", type: GridCalendar, isStandalone: true, selector: "glc-grid-calendar", inputs: { event: { classPropertyName: "event", publicName: "event", isSignal: true, isRequired: false, transformFunction: null }, events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: false, transformFunction: null }, tasks: { classPropertyName: "tasks", publicName: "tasks", isSignal: true, isRequired: false, transformFunction: null }, showCompletedTasks: { classPropertyName: "showCompletedTasks", publicName: "showCompletedTasks", isSignal: true, isRequired: false, transformFunction: null }, contentMode: { classPropertyName: "contentMode", publicName: "contentMode", isSignal: true, isRequired: false, transformFunction: null }, resource: { classPropertyName: "resource", publicName: "resource", isSignal: true, isRequired: false, transformFunction: null }, resources: { classPropertyName: "resources", publicName: "resources", isSignal: true, isRequired: false, transformFunction: null }, birthdays: { classPropertyName: "birthdays", publicName: "birthdays", isSignal: true, isRequired: false, transformFunction: null }, data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, viewMode: { classPropertyName: "viewMode", publicName: "viewMode", isSignal: true, isRequired: false, transformFunction: null }, columnMode: { classPropertyName: "columnMode", publicName: "columnMode", isSignal: true, isRequired: false, transformFunction: null }, anchorDate: { classPropertyName: "anchorDate", publicName: "anchorDate", isSignal: true, isRequired: false, transformFunction: null }, theme: { classPropertyName: "theme", publicName: "theme", isSignal: true, isRequired: false, transformFunction: null }, dayAnnotations: { classPropertyName: "dayAnnotations", publicName: "dayAnnotations", isSignal: true, isRequired: false, transformFunction: null }, labels: { classPropertyName: "labels", publicName: "labels", isSignal: true, isRequired: false, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: false, transformFunction: null }, canMoveEvent: { classPropertyName: "canMoveEvent", publicName: "canMoveEvent", isSignal: true, isRequired: false, transformFunction: null }, editingLocked: { classPropertyName: "editingLocked", publicName: "editingLocked", isSignal: true, isRequired: false, transformFunction: null }, minColumnWidth: { classPropertyName: "minColumnWidth", publicName: "minColumnWidth", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { editingLocked: "editingLockedChange", eventsChange: "eventsChange", tasksChange: "tasksChange", eventMoved: "eventMoved", eventClicked: "eventClicked", eventEditRequested: "eventEditRequested", eventDeleted: "eventDeleted", eventUpdated: "eventUpdated", eventCreateRequested: "eventCreateRequested", overlapRejected: "overlapRejected", taskCommentsRequested: "taskCommentsRequested", visibleRangeChange: "visibleRangeChange" }, providers: [GridStateService], viewQueries: [{ propertyName: "bodyEl", first: true, predicate: ["bodyEl"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"glc-grid-calendar\">\r\n  <div\r\n    class=\"glc-grid-calendar__scroll\"\r\n    #scrollEl\r\n    [class.glc-grid-calendar__scroll--scrollable]=\"scrollable()\"\r\n    [style.--glc-columns-min-width]=\"columnsMinWidthPx() + 'px'\"\r\n  >\r\n  <div class=\"glc-grid-calendar__header-row\">\r\n    <div class=\"glc-grid-calendar__header-spacer glc-grid-calendar__nav\">\r\n      <button type=\"button\" class=\"glc-grid-calendar__nav-button\" [attr.aria-label]=\"effectiveLabels().previous\" (click)=\"navigate(-1)\"><svg class=\"glc-grid-calendar__nav-icon\" viewBox=\"0 0 10 16\" aria-hidden=\"true\"><path d=\"M8 2 L2 8 L8 14\" /></svg></button>\r\n      <button type=\"button\" class=\"glc-grid-calendar__nav-button glc-grid-calendar__nav-button--today\" [attr.aria-label]=\"effectiveLabels().today\" (click)=\"goToInitialView()\"><span class=\"glc-grid-calendar__today-dot\"></span></button>\r\n      <button type=\"button\" class=\"glc-grid-calendar__nav-button\" [attr.aria-label]=\"effectiveLabels().next\" (click)=\"navigate(1)\"><svg class=\"glc-grid-calendar__nav-icon\" viewBox=\"0 0 10 16\" aria-hidden=\"true\"><path d=\"M2 2 L8 8 L2 14\" /></svg></button>\r\n      @if (editingLocked()) {\r\n        <button type=\"button\" class=\"glc-grid-calendar__lock-button\" [attr.aria-label]=\"effectiveLabels().editingLocked\" (click)=\"toggleEditingLocked()\">\r\n          <svg class=\"glc-grid-calendar__lock-icon\" viewBox=\"0 0 24 24\" aria-hidden=\"true\">\r\n            <path d=\"M7 10V7a5 5 0 0 1 10 0v3\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" />\r\n            <rect x=\"4\" y=\"10\" width=\"16\" height=\"11\" rx=\"2\" fill=\"currentColor\" />\r\n          </svg>\r\n        </button>\r\n      } @else {\r\n        <button type=\"button\" class=\"glc-grid-calendar__lock-button\" [attr.aria-label]=\"effectiveLabels().editingUnlocked\" (click)=\"toggleEditingLocked()\">\r\n          <svg class=\"glc-grid-calendar__lock-icon\" viewBox=\"0 0 24 24\" aria-hidden=\"true\">\r\n            <path d=\"M7 10V5a5 5 0 0 1 10 0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" />\r\n            <rect x=\"4\" y=\"10\" width=\"16\" height=\"11\" rx=\"2\" fill=\"currentColor\" />\r\n          </svg>\r\n        </button>\r\n      }\r\n    </div>\r\n    <div class=\"glc-grid-calendar__columns\">\r\n      <glc-grid-header [dayGroups]=\"state.dayGroups()\" [birthdays]=\"birthdays()\" [labels]=\"effectiveLabels()\" [annotationsByColumn]=\"state.annotationsByColumn()\" />\r\n    </div>\r\n  </div>\r\n\r\n  @if (hasResourceColumns()) {\r\n    <div class=\"glc-grid-calendar__pills-row\">\r\n      <div class=\"glc-grid-calendar__header-spacer\"></div>\r\n      <div class=\"glc-grid-calendar__columns\">\r\n        @for (group of state.dayGroups(); track group.date.toISOString()) {\r\n          <div class=\"glc-grid-calendar__pills-day-group\" [style.flex-grow]=\"group.columns.length\">\r\n            @for (column of group.columns; track column.key) {\r\n              @let resourceColor = column.resource?.color;\r\n              <div\r\n                class=\"glc-grid-calendar__pill-cell\"\r\n                [class.glc-grid-calendar__pill-cell--framed]=\"!!resourceColor\"\r\n                [style.--glc-resource-color]=\"resourceColor\"\r\n              >\r\n                @if (column.resource) {\r\n                  <span class=\"glc-grid-calendar__pill\">\r\n                    {{ column.label }}\r\n                  </span>\r\n                }\r\n              </div>\r\n            }\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <div class=\"glc-grid-calendar__grid-content\" [hidden]=\"contentMode() === 'tasks'\">\r\n    <div class=\"glc-grid-calendar__body\" #bodyEl>\r\n      <glc-time-axis [config]=\"state.effectiveConfig()\" [style.height.px]=\"state.contentHeightPx() + frameBottomBufferPx\" />\r\n      @if (state.isNowVisible()) {\r\n        <div class=\"glc-grid-calendar__now-badge-wrap\" [style.top.px]=\"state.nowOffsetPx()\">\r\n          <span class=\"glc-grid-calendar__now-badge\">{{ nowLabel() }}</span>\r\n        </div>\r\n      }\r\n      <div class=\"glc-grid-calendar__columns\" cdkDropListGroup (pointerdown)=\"onPanStart($event, scrollEl)\">\r\n        @for (group of state.dayGroups(); track group.date.toISOString()) {\r\n          <div\r\n            class=\"glc-grid-calendar__day-group\"\r\n            [style.flex-grow]=\"group.columns.length\"\r\n            [style.height.px]=\"state.contentHeightPx() + frameBottomBufferPx\"\r\n          >\r\n            @for (column of group.columns; track column.key) {\r\n              <glc-day-column\r\n                [columnKey]=\"column.key\"\r\n                [layouts]=\"state.layoutByColumn().get(column.key) ?? []\"\r\n                [columnDate]=\"group.date\"\r\n                [config]=\"state.effectiveConfig()\"\r\n                [borderColor]=\"column.resource?.color\"\r\n                [resourceId]=\"column.resource?.id\"\r\n                [gridLinesPx]=\"state.gridLinesPx()\"\r\n                [labels]=\"effectiveLabels()\"\r\n                [editingLocked]=\"editingLocked()\"\r\n                [style.height.px]=\"state.contentHeightPx() + frameBottomBufferPx\"\r\n                (eventClicked)=\"eventClicked.emit($event)\"\r\n                (eventEditRequested)=\"eventEditRequested.emit($event)\"\r\n                (eventDeleted)=\"onEventDeleted($event)\"\r\n                (eventUpdated)=\"onEventUpdated($event)\"\r\n                (eventDrawn)=\"onEventDrawn($event)\"\r\n                (dropped)=\"onColumnDropped($event)\"\r\n              />\r\n            }\r\n            @if (group.isToday && state.isNowVisible()) {\r\n              <div class=\"glc-grid-calendar__now-line\" [style.top.px]=\"state.nowOffsetPx()\"></div>\r\n            }\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  @if (contentMode() !== 'grid') {\r\n    <div class=\"glc-grid-calendar__tasks-row\" [class.glc-grid-calendar__tasks-row--full]=\"contentMode() === 'tasks'\">\r\n      <div class=\"glc-grid-calendar__header-spacer\"></div>\r\n      <div class=\"glc-grid-calendar__columns\">\r\n        @for (group of state.dayGroups(); track group.date.toISOString()) {\r\n          <div\r\n            class=\"glc-grid-calendar__day-group\"\r\n            [style.flex-grow]=\"group.columns.length\"\r\n            [style.min-height.px]=\"contentMode() === 'tasks' ? taskFrameMinHeightPx() : null\"\r\n          >\r\n            @for (column of group.columns; track column.key) {\r\n              @let taskFrameColor = column.resource?.color;\r\n              <glc-task-list-column\r\n                [tasks]=\"state.tasksByColumn().get(column.key) ?? []\"\r\n                [resources]=\"normalizedResources()\"\r\n                [showCompleted]=\"showCompletedTasks()\"\r\n                [labels]=\"effectiveLabels()\"\r\n                [class.glc-grid-calendar__task-frame]=\"contentMode() === 'tasks' && !!taskFrameColor\"\r\n                [style.--glc-resource-color]=\"taskFrameColor\"\r\n                (tasksChange)=\"onTasksChanged($event)\"\r\n                (commentsRequested)=\"taskCommentsRequested.emit($event)\"\r\n              />\r\n            }\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n  </div>\r\n</div>\r\n", styles: [".glc-grid-calendar{display:flex;flex-direction:column;width:100%;height:100%;font-family:var(--glc-font-family, inherit);color-scheme:var(--glc-color-scheme, normal);background:var(--glc-color-background, transparent);color:var(--glc-color-text, inherit)}.glc-grid-calendar__grid-content{display:flex;flex:1 1 auto;flex-direction:column;min-height:0}.glc-grid-calendar__grid-content[hidden]{display:none}.glc-grid-calendar__header-row{display:flex;flex:0 0 auto}.glc-grid-calendar__header-spacer{flex:0 0 var(--glc-time-axis-width, 3.5rem)}.glc-grid-calendar__nav{display:grid;grid-template-columns:repeat(3,max-content);align-content:start;position:relative;align-items:flex-start;justify-content:center;gap:.25em;width:var(--glc-time-axis-width, 3.5rem);padding:var(--glc-header-padding, .5rem);box-sizing:border-box;white-space:nowrap}.glc-grid-calendar__nav-button{display:inline-flex;align-items:center;height:1.25em;font:inherit;font-weight:700;line-height:1.25;padding:0;border:none;background:none;color:inherit;cursor:pointer}.glc-grid-calendar__nav-button:hover{opacity:.7}.glc-grid-calendar__nav-icon{width:.6em;height:.9em;fill:none;stroke:currentColor;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}.glc-grid-calendar__lock-button{grid-column:1/-1;justify-self:center;width:1.4em;height:1.4em;padding:0;border:0;background:none;color:inherit;cursor:pointer}.glc-grid-calendar__lock-button:hover{opacity:.7}.glc-grid-calendar__lock-icon{width:100%;height:100%;fill:#d32f2f}.glc-grid-calendar__today-dot{display:inline-block;width:.9em;height:.9em;border-radius:50%;background:currentColor;vertical-align:middle}.glc-grid-calendar__pills-row{display:flex;flex:0 0 auto}.glc-grid-calendar__pill-cell{box-sizing:border-box;flex:1 1 0;min-width:0;display:flex;align-items:center;justify-content:center;padding:.4rem}.glc-grid-calendar__pill-cell--framed{border:3px solid var(--glc-resource-color);border-bottom:0;border-radius:8px 8px 0 0}.glc-grid-calendar__task-frame{border:3px solid var(--glc-resource-color);border-top:0;border-radius:0 0 8px 8px}.glc-grid-calendar__pill{display:inline-block;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:center;border:1px solid var(--glc-resource-color, var(--glc-color-border, #ccc));background:color-mix(in oklch,var(--glc-resource-color, var(--glc-color-border, #ccc)) 18%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222);font-size:.75rem;font-weight:600;padding:.3rem .75rem;border-radius:999px}.glc-grid-calendar__body{position:relative;display:flex;flex:1 1 auto;min-height:0;overflow:visible}.glc-grid-calendar__scroll{display:flex;flex:1 1 auto;flex-direction:column;min-width:0;min-height:0}.glc-grid-calendar__scroll--scrollable{overflow:auto}.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__header-row,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__pills-row,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__grid-content,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__tasks-row{min-width:calc(var(--glc-time-axis-width, 3.5rem) + var(--glc-columns-padding-inline, 8px) * 2 + var(--glc-columns-min-width, 0px))}.glc-grid-calendar__scroll--scrollable .glc-grid-calendar__header-spacer,.glc-grid-calendar__scroll--scrollable .glc-grid-calendar__nav,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__grid-content>.glc-grid-calendar__body>glc-time-axis{position:sticky;left:0;z-index:3;background-color:var(--glc-color-background, Canvas)}.glc-grid-calendar__tasks-row{display:flex;flex:0 0 auto;padding-top:.85rem}.glc-grid-calendar__tasks-row:not(.glc-grid-calendar__tasks-row--full)>.glc-grid-calendar__columns{border-top:1px solid var(--glc-color-border, #ccc)}.glc-grid-calendar__tasks-row--full{box-sizing:border-box;flex:1 1 0;min-height:0;overflow:visible;border-top:0;padding-top:0}.glc-grid-calendar__tasks-row--full>.glc-grid-calendar__columns{height:100%;align-items:flex-start}.glc-grid-calendar__columns{display:flex;flex:1 1 0;min-width:0;gap:var(--glc-columns-gap, 8px);padding:0 var(--glc-columns-padding-inline, 8px)}.glc-grid-calendar__day-group{display:flex;position:relative;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__pills-day-group{display:flex;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__now-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-now, #e03131);pointer-events:none}.glc-grid-calendar__now-badge-wrap{position:absolute;left:0;width:var(--glc-time-axis-width, 3.5rem);box-sizing:border-box;transform:translateY(-50%);display:flex;justify-content:flex-end;overflow:hidden;z-index:2;pointer-events:none}.glc-grid-calendar__now-badge{display:inline-block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.75rem;font-weight:700;color:var(--glc-color-on-now, #fff);background:var(--glc-color-now, #e03131);border-radius:4px;padding:.05rem .35rem}\n"], dependencies: [{ kind: "component", type: GridHeaderComponent, selector: "glc-grid-header", inputs: ["dayGroups", "birthdays", "labels", "annotationsByColumn"] }, { kind: "component", type: TimeAxisComponent, selector: "glc-time-axis", inputs: ["config"] }, { kind: "component", type: DayColumnComponent, selector: "glc-day-column", inputs: ["columnKey", "layouts", "columnDate", "config", "borderColor", "resourceId", "gridLinesPx", "labels", "editingLocked"], outputs: ["dropped", "eventClicked", "eventEditRequested", "eventDeleted", "eventUpdated", "eventDrawn"] }, { kind: "component", type: TaskListColumnComponent, selector: "glc-task-list-column", inputs: ["tasks", "resources", "showCompleted", "labels"], outputs: ["tasksChange", "commentsRequested"] }, { kind: "directive", type: CdkDropListGroup, selector: "[cdkDropListGroup]", inputs: ["cdkDropListGroupDisabled"], exportAs: ["cdkDropListGroup"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: GridCalendar, decorators: [{
            type: Component,
            args: [{ selector: 'glc-grid-calendar', imports: [GridHeaderComponent, TimeAxisComponent, DayColumnComponent, TaskListColumnComponent, CdkDropListGroup], providers: [GridStateService], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"glc-grid-calendar\">\r\n  <div\r\n    class=\"glc-grid-calendar__scroll\"\r\n    #scrollEl\r\n    [class.glc-grid-calendar__scroll--scrollable]=\"scrollable()\"\r\n    [style.--glc-columns-min-width]=\"columnsMinWidthPx() + 'px'\"\r\n  >\r\n  <div class=\"glc-grid-calendar__header-row\">\r\n    <div class=\"glc-grid-calendar__header-spacer glc-grid-calendar__nav\">\r\n      <button type=\"button\" class=\"glc-grid-calendar__nav-button\" [attr.aria-label]=\"effectiveLabels().previous\" (click)=\"navigate(-1)\"><svg class=\"glc-grid-calendar__nav-icon\" viewBox=\"0 0 10 16\" aria-hidden=\"true\"><path d=\"M8 2 L2 8 L8 14\" /></svg></button>\r\n      <button type=\"button\" class=\"glc-grid-calendar__nav-button glc-grid-calendar__nav-button--today\" [attr.aria-label]=\"effectiveLabels().today\" (click)=\"goToInitialView()\"><span class=\"glc-grid-calendar__today-dot\"></span></button>\r\n      <button type=\"button\" class=\"glc-grid-calendar__nav-button\" [attr.aria-label]=\"effectiveLabels().next\" (click)=\"navigate(1)\"><svg class=\"glc-grid-calendar__nav-icon\" viewBox=\"0 0 10 16\" aria-hidden=\"true\"><path d=\"M2 2 L8 8 L2 14\" /></svg></button>\r\n      @if (editingLocked()) {\r\n        <button type=\"button\" class=\"glc-grid-calendar__lock-button\" [attr.aria-label]=\"effectiveLabels().editingLocked\" (click)=\"toggleEditingLocked()\">\r\n          <svg class=\"glc-grid-calendar__lock-icon\" viewBox=\"0 0 24 24\" aria-hidden=\"true\">\r\n            <path d=\"M7 10V7a5 5 0 0 1 10 0v3\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" />\r\n            <rect x=\"4\" y=\"10\" width=\"16\" height=\"11\" rx=\"2\" fill=\"currentColor\" />\r\n          </svg>\r\n        </button>\r\n      } @else {\r\n        <button type=\"button\" class=\"glc-grid-calendar__lock-button\" [attr.aria-label]=\"effectiveLabels().editingUnlocked\" (click)=\"toggleEditingLocked()\">\r\n          <svg class=\"glc-grid-calendar__lock-icon\" viewBox=\"0 0 24 24\" aria-hidden=\"true\">\r\n            <path d=\"M7 10V5a5 5 0 0 1 10 0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" />\r\n            <rect x=\"4\" y=\"10\" width=\"16\" height=\"11\" rx=\"2\" fill=\"currentColor\" />\r\n          </svg>\r\n        </button>\r\n      }\r\n    </div>\r\n    <div class=\"glc-grid-calendar__columns\">\r\n      <glc-grid-header [dayGroups]=\"state.dayGroups()\" [birthdays]=\"birthdays()\" [labels]=\"effectiveLabels()\" [annotationsByColumn]=\"state.annotationsByColumn()\" />\r\n    </div>\r\n  </div>\r\n\r\n  @if (hasResourceColumns()) {\r\n    <div class=\"glc-grid-calendar__pills-row\">\r\n      <div class=\"glc-grid-calendar__header-spacer\"></div>\r\n      <div class=\"glc-grid-calendar__columns\">\r\n        @for (group of state.dayGroups(); track group.date.toISOString()) {\r\n          <div class=\"glc-grid-calendar__pills-day-group\" [style.flex-grow]=\"group.columns.length\">\r\n            @for (column of group.columns; track column.key) {\r\n              @let resourceColor = column.resource?.color;\r\n              <div\r\n                class=\"glc-grid-calendar__pill-cell\"\r\n                [class.glc-grid-calendar__pill-cell--framed]=\"!!resourceColor\"\r\n                [style.--glc-resource-color]=\"resourceColor\"\r\n              >\r\n                @if (column.resource) {\r\n                  <span class=\"glc-grid-calendar__pill\">\r\n                    {{ column.label }}\r\n                  </span>\r\n                }\r\n              </div>\r\n            }\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <div class=\"glc-grid-calendar__grid-content\" [hidden]=\"contentMode() === 'tasks'\">\r\n    <div class=\"glc-grid-calendar__body\" #bodyEl>\r\n      <glc-time-axis [config]=\"state.effectiveConfig()\" [style.height.px]=\"state.contentHeightPx() + frameBottomBufferPx\" />\r\n      @if (state.isNowVisible()) {\r\n        <div class=\"glc-grid-calendar__now-badge-wrap\" [style.top.px]=\"state.nowOffsetPx()\">\r\n          <span class=\"glc-grid-calendar__now-badge\">{{ nowLabel() }}</span>\r\n        </div>\r\n      }\r\n      <div class=\"glc-grid-calendar__columns\" cdkDropListGroup (pointerdown)=\"onPanStart($event, scrollEl)\">\r\n        @for (group of state.dayGroups(); track group.date.toISOString()) {\r\n          <div\r\n            class=\"glc-grid-calendar__day-group\"\r\n            [style.flex-grow]=\"group.columns.length\"\r\n            [style.height.px]=\"state.contentHeightPx() + frameBottomBufferPx\"\r\n          >\r\n            @for (column of group.columns; track column.key) {\r\n              <glc-day-column\r\n                [columnKey]=\"column.key\"\r\n                [layouts]=\"state.layoutByColumn().get(column.key) ?? []\"\r\n                [columnDate]=\"group.date\"\r\n                [config]=\"state.effectiveConfig()\"\r\n                [borderColor]=\"column.resource?.color\"\r\n                [resourceId]=\"column.resource?.id\"\r\n                [gridLinesPx]=\"state.gridLinesPx()\"\r\n                [labels]=\"effectiveLabels()\"\r\n                [editingLocked]=\"editingLocked()\"\r\n                [style.height.px]=\"state.contentHeightPx() + frameBottomBufferPx\"\r\n                (eventClicked)=\"eventClicked.emit($event)\"\r\n                (eventEditRequested)=\"eventEditRequested.emit($event)\"\r\n                (eventDeleted)=\"onEventDeleted($event)\"\r\n                (eventUpdated)=\"onEventUpdated($event)\"\r\n                (eventDrawn)=\"onEventDrawn($event)\"\r\n                (dropped)=\"onColumnDropped($event)\"\r\n              />\r\n            }\r\n            @if (group.isToday && state.isNowVisible()) {\r\n              <div class=\"glc-grid-calendar__now-line\" [style.top.px]=\"state.nowOffsetPx()\"></div>\r\n            }\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  @if (contentMode() !== 'grid') {\r\n    <div class=\"glc-grid-calendar__tasks-row\" [class.glc-grid-calendar__tasks-row--full]=\"contentMode() === 'tasks'\">\r\n      <div class=\"glc-grid-calendar__header-spacer\"></div>\r\n      <div class=\"glc-grid-calendar__columns\">\r\n        @for (group of state.dayGroups(); track group.date.toISOString()) {\r\n          <div\r\n            class=\"glc-grid-calendar__day-group\"\r\n            [style.flex-grow]=\"group.columns.length\"\r\n            [style.min-height.px]=\"contentMode() === 'tasks' ? taskFrameMinHeightPx() : null\"\r\n          >\r\n            @for (column of group.columns; track column.key) {\r\n              @let taskFrameColor = column.resource?.color;\r\n              <glc-task-list-column\r\n                [tasks]=\"state.tasksByColumn().get(column.key) ?? []\"\r\n                [resources]=\"normalizedResources()\"\r\n                [showCompleted]=\"showCompletedTasks()\"\r\n                [labels]=\"effectiveLabels()\"\r\n                [class.glc-grid-calendar__task-frame]=\"contentMode() === 'tasks' && !!taskFrameColor\"\r\n                [style.--glc-resource-color]=\"taskFrameColor\"\r\n                (tasksChange)=\"onTasksChanged($event)\"\r\n                (commentsRequested)=\"taskCommentsRequested.emit($event)\"\r\n              />\r\n            }\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n  </div>\r\n</div>\r\n", styles: [".glc-grid-calendar{display:flex;flex-direction:column;width:100%;height:100%;font-family:var(--glc-font-family, inherit);color-scheme:var(--glc-color-scheme, normal);background:var(--glc-color-background, transparent);color:var(--glc-color-text, inherit)}.glc-grid-calendar__grid-content{display:flex;flex:1 1 auto;flex-direction:column;min-height:0}.glc-grid-calendar__grid-content[hidden]{display:none}.glc-grid-calendar__header-row{display:flex;flex:0 0 auto}.glc-grid-calendar__header-spacer{flex:0 0 var(--glc-time-axis-width, 3.5rem)}.glc-grid-calendar__nav{display:grid;grid-template-columns:repeat(3,max-content);align-content:start;position:relative;align-items:flex-start;justify-content:center;gap:.25em;width:var(--glc-time-axis-width, 3.5rem);padding:var(--glc-header-padding, .5rem);box-sizing:border-box;white-space:nowrap}.glc-grid-calendar__nav-button{display:inline-flex;align-items:center;height:1.25em;font:inherit;font-weight:700;line-height:1.25;padding:0;border:none;background:none;color:inherit;cursor:pointer}.glc-grid-calendar__nav-button:hover{opacity:.7}.glc-grid-calendar__nav-icon{width:.6em;height:.9em;fill:none;stroke:currentColor;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}.glc-grid-calendar__lock-button{grid-column:1/-1;justify-self:center;width:1.4em;height:1.4em;padding:0;border:0;background:none;color:inherit;cursor:pointer}.glc-grid-calendar__lock-button:hover{opacity:.7}.glc-grid-calendar__lock-icon{width:100%;height:100%;fill:#d32f2f}.glc-grid-calendar__today-dot{display:inline-block;width:.9em;height:.9em;border-radius:50%;background:currentColor;vertical-align:middle}.glc-grid-calendar__pills-row{display:flex;flex:0 0 auto}.glc-grid-calendar__pill-cell{box-sizing:border-box;flex:1 1 0;min-width:0;display:flex;align-items:center;justify-content:center;padding:.4rem}.glc-grid-calendar__pill-cell--framed{border:3px solid var(--glc-resource-color);border-bottom:0;border-radius:8px 8px 0 0}.glc-grid-calendar__task-frame{border:3px solid var(--glc-resource-color);border-top:0;border-radius:0 0 8px 8px}.glc-grid-calendar__pill{display:inline-block;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:center;border:1px solid var(--glc-resource-color, var(--glc-color-border, #ccc));background:color-mix(in oklch,var(--glc-resource-color, var(--glc-color-border, #ccc)) 18%,var(--glc-color-background, #fff));color:var(--glc-color-text, #222);font-size:.75rem;font-weight:600;padding:.3rem .75rem;border-radius:999px}.glc-grid-calendar__body{position:relative;display:flex;flex:1 1 auto;min-height:0;overflow:visible}.glc-grid-calendar__scroll{display:flex;flex:1 1 auto;flex-direction:column;min-width:0;min-height:0}.glc-grid-calendar__scroll--scrollable{overflow:auto}.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__header-row,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__pills-row,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__grid-content,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__tasks-row{min-width:calc(var(--glc-time-axis-width, 3.5rem) + var(--glc-columns-padding-inline, 8px) * 2 + var(--glc-columns-min-width, 0px))}.glc-grid-calendar__scroll--scrollable .glc-grid-calendar__header-spacer,.glc-grid-calendar__scroll--scrollable .glc-grid-calendar__nav,.glc-grid-calendar__scroll--scrollable>.glc-grid-calendar__grid-content>.glc-grid-calendar__body>glc-time-axis{position:sticky;left:0;z-index:3;background-color:var(--glc-color-background, Canvas)}.glc-grid-calendar__tasks-row{display:flex;flex:0 0 auto;padding-top:.85rem}.glc-grid-calendar__tasks-row:not(.glc-grid-calendar__tasks-row--full)>.glc-grid-calendar__columns{border-top:1px solid var(--glc-color-border, #ccc)}.glc-grid-calendar__tasks-row--full{box-sizing:border-box;flex:1 1 0;min-height:0;overflow:visible;border-top:0;padding-top:0}.glc-grid-calendar__tasks-row--full>.glc-grid-calendar__columns{height:100%;align-items:flex-start}.glc-grid-calendar__columns{display:flex;flex:1 1 0;min-width:0;gap:var(--glc-columns-gap, 8px);padding:0 var(--glc-columns-padding-inline, 8px)}.glc-grid-calendar__day-group{display:flex;position:relative;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__pills-day-group{display:flex;flex:1 1 0;min-width:0;gap:3px}.glc-grid-calendar__now-line{position:absolute;left:0;right:0;border-top:1px dashed var(--glc-color-now, #e03131);pointer-events:none}.glc-grid-calendar__now-badge-wrap{position:absolute;left:0;width:var(--glc-time-axis-width, 3.5rem);box-sizing:border-box;transform:translateY(-50%);display:flex;justify-content:flex-end;overflow:hidden;z-index:2;pointer-events:none}.glc-grid-calendar__now-badge{display:inline-block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.75rem;font-weight:700;color:var(--glc-color-on-now, #fff);background:var(--glc-color-now, #e03131);border-radius:4px;padding:.05rem .35rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { bodyEl: [{ type: i0.ViewChild, args: ['bodyEl', { isSignal: true }] }], event: [{ type: i0.Input, args: [{ isSignal: true, alias: "event", required: false }] }], events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: false }] }], tasks: [{ type: i0.Input, args: [{ isSignal: true, alias: "tasks", required: false }] }], showCompletedTasks: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCompletedTasks", required: false }] }], contentMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentMode", required: false }] }], resource: [{ type: i0.Input, args: [{ isSignal: true, alias: "resource", required: false }] }], resources: [{ type: i0.Input, args: [{ isSignal: true, alias: "resources", required: false }] }], birthdays: [{ type: i0.Input, args: [{ isSignal: true, alias: "birthdays", required: false }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], viewMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "viewMode", required: false }] }], columnMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnMode", required: false }] }], anchorDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "anchorDate", required: false }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: false }] }], dayAnnotations: [{ type: i0.Input, args: [{ isSignal: true, alias: "dayAnnotations", required: false }] }], labels: [{ type: i0.Input, args: [{ isSignal: true, alias: "labels", required: false }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: false }] }], canMoveEvent: [{ type: i0.Input, args: [{ isSignal: true, alias: "canMoveEvent", required: false }] }], editingLocked: [{ type: i0.Input, args: [{ isSignal: true, alias: "editingLocked", required: false }] }, { type: i0.Output, args: ["editingLockedChange"] }], minColumnWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "minColumnWidth", required: false }] }], eventsChange: [{ type: i0.Output, args: ["eventsChange"] }], tasksChange: [{ type: i0.Output, args: ["tasksChange"] }], eventMoved: [{ type: i0.Output, args: ["eventMoved"] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], eventEditRequested: [{ type: i0.Output, args: ["eventEditRequested"] }], eventDeleted: [{ type: i0.Output, args: ["eventDeleted"] }], eventUpdated: [{ type: i0.Output, args: ["eventUpdated"] }], eventCreateRequested: [{ type: i0.Output, args: ["eventCreateRequested"] }], overlapRejected: [{ type: i0.Output, args: ["overlapRejected"] }], taskCommentsRequested: [{ type: i0.Output, args: ["taskCommentsRequested"] }], visibleRangeChange: [{ type: i0.Output, args: ["visibleRangeChange"] }] } });

/*
 * Public API Surface of grid-calendar
 */

/**
 * Generated bundle index. Do not edit.
 */

export { GridCalendar, GridLayoutService, ThemeService, toDateKey };
//# sourceMappingURL=swbpapk_acmtemu-grid-calendar.mjs.map
