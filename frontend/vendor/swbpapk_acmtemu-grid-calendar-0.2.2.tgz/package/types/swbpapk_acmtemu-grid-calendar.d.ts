import * as _angular_core from '@angular/core';
import { Signal } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

/** Auf dem Fuenf-Minuten-Raster erzeugte Zeitspanne aus einer leeren Grid-Spalte. */
interface EventDrawRequest {
    start: string;
    end: string;
    resourceId?: number;
}

/** Eine Ressource/ein Benutzer, dem Events zugeordnet werden können. */
interface CalendarResource {
    id: number;
    name: string;
    avatarUrl?: string;
    color?: string;
}

/**
 * Ein Termin im Grid. `start`/`end` sind ISO-8601-Strings, damit das Objekt
 * verlustfrei als JSON rein- und rausgereicht werden kann (kein Date-Objekt
 * im öffentlichen Vertrag).
 */
interface CalendarEvent {
    id: number;
    title: string;
    /** Kompakter Ersatz fuer einen zu breiten Titel, maximal drei Zeichen. */
    shortTitle?: string;
    start: string;
    end: string;
    resourceId?: number;
    category?: string;
    color?: string;
    imageUrl?: string;
    /** Lokaler, noch nicht persistierter Zeichenentwurf mit negativer ID. */
    isDraft?: boolean;
    /** Gesperrt: nicht verschiebbar, nicht skalierbar, nicht löschbar und nicht bearbeitbar. */
    locked?: boolean;
    meta?: Record<string, unknown>;
}

/** Bearbeitbarer Kommentar einer Checklistenaufgabe. */
interface CalendarTaskComment {
    id: number;
    text: string;
    createdAt: string;
    updatedAt?: string;
    author?: string;
}

/** Datumsbezogene Checklistenaufgabe ohne Uhrzeit. */
interface CalendarTask {
    id: number;
    name: string;
    /** Lokales Kalenderdatum im Format YYYY-MM-DD. */
    date: string;
    resourceId: number;
    /** Eine Ebene Unteraufgaben; fehlt bei einer Hauptaufgabe. */
    parentId?: number;
    completed: boolean;
    comments?: CalendarTaskComment[];
}

/** Gemeinsamer JSON-Eingabevertrag fuer Ressourcen, Events und Checklisten-Tasks. */
interface CalendarGridData {
    resources?: CalendarResource[];
    events?: CalendarEvent[];
    tasks?: CalendarTask[];
}

/** Legt fest, wofür die Spalten des Grids stehen. */
type GridColumnMode = 'date' | 'resource';

/** Sichtbarkeit der zeitgebundenen Grid-Ansicht und der datumsgelagerten Tasks. */
type GridContentMode = 'both' | 'grid' | 'tasks';

/**
 * Zeitraster-Konfiguration, mit der GridLayoutService rechnet. Der Startpunkt
 * jeder Ansicht ergibt sich aus `anchorDate` (rollierendes Fenster), nicht aus
 * einem fixen Wochenstart.
 */
interface GridConfig {
    workingHoursStart: number;
    workingHoursEnd: number;
    pixelsPerHour: number;
    /** Abstand der Hilfslinien in Minuten; Verschieben, Resize und Zeichnen rasten darauf ein. Default: 5. */
    gridLineIntervalMinutes?: number;
}

/**
 * Theming-Input. Jeder Key wird von ThemeService 1:1 als CSS Custom Property
 * `--glc-<kebab-case-key>` auf dem Host-Element gesetzt.
 */
interface GridTheme {
    colorPrimary?: string;
    colorOnPrimary?: string;
    /** Fläche des Grids; ohne Wert bleibt der Hintergrund transparent. */
    colorBackground?: string;
    /** Standard-Textfarbe des Grids; ohne Wert wird sie geerbt. */
    colorText?: string;
    colorBorder?: string;
    /** Akzent (Balken) für Events ohne eigene `color`. */
    colorEventDefault?: string;
    /** Textfarbe in Events; Standard ist `colorText`. */
    colorOnEvent?: string;
    colorNow?: string;
    colorOnNow?: string;
    /** Farbe der vollen-Stunden-Linie samt Zeitachsen-Beschriftung (siehe TimeAxisComponent/DayColumnComponent). */
    colorHourLine?: string;
    /** Setzt `color-scheme` am Grid, damit native Elemente (Checkboxen, Scrollbars) zum Theme passen. */
    colorScheme?: 'light' | 'dark' | 'light dark';
    fontFamily?: string;
    /** Eckenradius von Events in px. */
    eventRadius?: number;
}

/** Beschriftungen der Oberfläche; `{name}` und `{count}` werden beim Anzeigen ersetzt. */
interface GridLabels {
    /** Badge am heutigen Tag. */
    today: string;
    /** Präfix der Kalenderwoche, z. B. "KW 36". */
    weekAbbreviation: string;
    deleteEvent: string;
    resizeTop: string;
    resizeBottom: string;
    taskColumn: string;
    addNote: string;
    /** Verfügbar: `{count}`. */
    showNotes: string;
    /** Verfügbar: `{name}`, `{count}`. */
    collapseSubtasks: string;
    /** Verfügbar: `{name}`, `{count}`. */
    expandSubtasks: string;
}

/** Sichtbarer Zeitbereich des Grids. */
type GridViewMode = 'day' | '3day' | 'week';

/** Eine dezente Hintergrund-Hilfslinie im Raster, siehe GridLayoutService.computeGridLines. */
interface GridLine {
    offsetPx: number;
    /** true bei vollen Stunden (kräftigere Linie), false bei den Zwischenschritten (z.B. 30-Min-Marke). */
    isHour: boolean;
    /** Uhrzeit, für die diese Linie steht (Anker beim Drag&Drop). */
    hours: number;
    minutes: number;
}

/** Ergebnis der Layout-Berechnung: Pixel-/Prozent-Werte für die Darstellung eines Events. */
interface EventLayout {
    event: CalendarEvent;
    topPx: number;
    heightPx: number;
    leftPercent: number;
    widthPercent: number;
}

declare class GridLayoutService {
    /** Liefert die sichtbaren Tage als Mitternachts-Daten, beginnend bei anchorDate. */
    computeVisibleRange(viewMode: GridViewMode, anchorDate: Date): Date[];
    /** Pixel-Offset eines Zeitpunkts relativ zum Spaltenanfang (Arbeitszeit-Fenster). */
    timeToOffset(time: Date, config: GridConfig): number;
    /** Liegt der Zeitpunkt innerhalb des Arbeitszeit-Fensters? Für die "Jetzt"-Linie: sonst würde
     * timeToOffset auf den Rand klemmen und eine falsche Uhrzeit an der falschen Stelle anzeigen. */
    isWithinWorkingHours(time: Date, config: GridConfig): boolean;
    /**
     * Layoutet alle Events einer Spalte (ein Tag bzw. ein Tag einer Person): auf den Tag
     * geclippt. Jeder Event nutzt die volle Spaltenbreite (eine Spalte gehört bereits genau
     * einem Tag/einer Person) — kein Nebeneinander-Splitting bei zeitlicher Überlappung.
     */
    layoutEventsForColumn(events: CalendarEvent[], columnDate: Date, config: GridConfig): EventLayout[];
    /** Die Hilfslinie, die einer Position (px ab Spaltenanfang) am nächsten liegt. */
    nearestGridLine(lines: GridLine[], topPx: number): GridLine;
    /**
     * Neue Hilfslinie für die bewegte Kante beim Resize: rastet auf die nächste Linie zu `edgePx`,
     * hält aber mindestens eine Linie Abstand zur anderen Kante (`otherLine`).
     */
    resizeEdgeLine(lines: GridLine[], edge: 'top' | 'bottom', edgePx: number, otherLine: GridLine): GridLine;
    /** Gezeichneter Bereich von Linie `a` zu Linie `b` in Linienreihenfolge, mindestens eine Linie hoch. */
    drawRange(lines: GridLine[], a: GridLine, b: GridLine): [GridLine, GridLine];
    /** Zeitpunkt einer Hilfslinie an einem bestimmten Tag. */
    timeOnGridLine(line: GridLine, columnDate: Date): Date;
    /** Uhrzeit als 24-Stunden-Text `HH:mm` (lokale Zeit, unabhängig von der Browser-Locale). */
    formatTime(time: Date): string;
    /** Beschriftung einer Hilfslinie als `HH:mm`. */
    formatGridLineTime(line: GridLine): string;
    /** Vergleicht zwei Zeitpunkte auf Kalendertag-Gleichheit (unabhängig von Uhrzeit). */
    isSameDay(a: Date, b: Date): boolean;
    /** Berührende Kanten (Ende = Start) gelten nicht als Überlappung. */
    overlapsAny(candidate: CalendarEvent, others: CalendarEvent[]): boolean;
    /** ISO-8601-Kalenderwoche (die Woche mit dem ersten Donnerstag des Jahres ist KW 1). */
    getIsoWeekNumber(date: Date): number;
    /** Pixel-Offsets dezentere Hilfslinien im Abstand von gridLineIntervalMinutes (Default 5). Volle Stunden sind als isHour markiert. */
    computeGridLines(config: GridConfig): GridLine[];
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln (für explizite Höhen von Zeitachse/Spalten). */
    computeContentHeight(config: GridConfig): number;
    /**
     * Staucht/streckt die Stunden so, dass das Arbeitszeit-Fenster exakt in `availableHeightPx`
     * passt (kein Scrollen nötig). Ohne bekannte verfügbare Höhe (<= 0) bleibt config.pixelsPerHour
     * unverändert.
     */
    computeEffectivePixelsPerHour(config: GridConfig, availableHeightPx: number): number;
    /** Geschätzte Höhe einer Task-Spalte: sichtbare Hauptaufgaben samt Unteraufgaben, Abstände und Rahmen. */
    estimateTaskColumnHeight(tasks: CalendarTask[], showCompleted: boolean): number;
    /** Gemeinsame Mindesthöhe aller Task-Spalten, damit die Rahmen auf einer Höhe enden. */
    computeTaskFrameMinHeight(columns: CalendarTask[][], showCompleted: boolean): number;
    private formatClock;
    private startOfDay;
    /** Letzter Zeitpunkt des Tages, NICHT Mitternacht des Folgetags (sonst kippt timeToOffset). */
    private endOfDay;
    private addDays;
    private clamp;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridLayoutService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<GridLayoutService>;
}

/** Eine Spalte im Grid: entweder ein Tag (columnMode 'date') oder eine Person/Ressource (columnMode 'resource'). */
interface GridColumn {
    key: string;
    label: string;
    date?: Date;
    resource?: CalendarResource;
}

/** Ein sichtbarer Tag mit seinen Sub-Spalten (1 im columnMode 'date', 1 pro Ressource im columnMode 'resource'). */
interface DayGroup {
    date: Date;
    weekNumber: number;
    isToday: boolean;
    columns: GridColumn[];
}

interface DragAnchor {
    line: GridLine;
    columnKey: string;
}
/** Eingabe-Signale des Grids; GridCalendar reicht seine Inputs einmalig per connect() durch. */
interface GridStateSource {
    events: Signal<CalendarEvent[]>;
    tasks: Signal<CalendarTask[]>;
    resources: Signal<CalendarResource[]>;
    viewMode: Signal<GridViewMode>;
    columnMode: Signal<GridColumnMode>;
    anchorDate: Signal<Date>;
    config: Signal<GridConfig>;
}
/** Interner, reaktiver State des Grids (Signals). Wird von GridCalendarComponent instanziiert, kein globaler Store. */
declare class GridStateService {
    private readonly layoutService;
    private readonly destroyRef;
    private readonly source;
    private readonly _containerHeightPx;
    private readonly _now;
    readonly events: Signal<CalendarEvent[]>;
    readonly tasks: Signal<CalendarTask[]>;
    readonly resources: Signal<CalendarResource[]>;
    readonly viewMode: Signal<GridViewMode>;
    readonly columnMode: Signal<GridColumnMode>;
    readonly anchorDate: Signal<Date>;
    readonly config: Signal<GridConfig>;
    readonly containerHeightPx: Signal<number>;
    connect(source: GridStateSource): void;
    /**
     * config, aber mit an die verfügbare Höhe angepasster pixelsPerHour, damit das
     * Arbeitszeit-Fenster ohne Scrollen exakt in den Container passt (siehe
     * GridLayoutService.computeEffectivePixelsPerHour).
     */
    readonly effectiveConfig: Signal<GridConfig>;
    /** 1/3/7 Tage ab anchorDate (rollierendes Fenster, kein fixer Wochenstart). */
    readonly visibleDates: Signal<Date[]>;
    /** Beginn des aktuellen Tages; ändert sich nur bei Tageswechsel, nicht im Minutentakt. */
    private readonly today;
    /**
     * Ein Eintrag pro sichtbarem Tag. Im columnMode 'date' hat jeder Tag genau eine Sub-Spalte
     * (der ganze Tag), im columnMode 'resource' eine Sub-Spalte pro Person (Tag×Person-Raster,
     * eine gemeinsame Zeitachse für alle Tage/Personen).
     */
    readonly dayGroups: Signal<DayGroup[]>;
    /** Alle Sub-Spalten flach (für Lookups, z.B. beim Drag&Drop-Zielspalten-Abgleich). */
    readonly flatColumns: Signal<GridColumn[]>;
    /** Checklist-Tasks pro sichtbarer Datum-/Ressourcen-Spalte; Task-Daten enthalten keine Uhrzeit. */
    readonly tasksByColumn: Signal<Map<string, CalendarTask[]>>;
    /** Event-Layout je Sub-Spalte, berechnet über GridLayoutService (keine Business-Logik hier, nur Orchestrierung). */
    readonly layoutByColumn: Signal<Map<string, EventLayout[]>>;
    /** Aktueller Zeitpunkt fuer die Live-Zeit-Linie; aktualisiert sich nur an vollen Minuten. */
    readonly now: Signal<Date>;
    readonly nowOffsetPx: Signal<number>;
    /** false außerhalb des Arbeitszeit-Fensters: sonst würde die Linie irreführend am Rand kleben. */
    readonly isNowVisible: Signal<boolean>;
    /** Pixel-Offsets der dezenten Hilfslinien (unabhängig vom Drag&Drop-Snapping-Raster). */
    readonly gridLinesPx: Signal<GridLine[]>;
    private readonly _dragAnchor;
    /** Hilfslinie + Spalte, an der die Oberkante des gerade gezogenen Events hängt (Vorschau = Drop-Ergebnis). */
    readonly dragAnchor: Signal<DragAnchor | null>;
    setDragAnchor(anchor: DragAnchor | null): void;
    /** Gesamthöhe des Arbeitszeit-Fensters in Pixeln, als explizite Höhe für Zeitachse/Spalten (entspricht containerHeightPx, kein Scrollen nötig). */
    readonly contentHeightPx: Signal<number>;
    constructor();
    private buildColumnsForDay;
    setContainerHeightPx(heightPx: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridStateService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<GridStateService>;
}

/** Öffentlicher Library-Einstiegspunkt mit Event-Raster und datumsgelagerter Task-Zeile. */
declare class GridCalendar {
    private readonly hostElement;
    private readonly themeService;
    private readonly destroyRef;
    protected readonly layoutService: GridLayoutService;
    readonly state: GridStateService;
    private readonly bodyEl;
    readonly event: _angular_core.InputSignal<CalendarEvent | undefined>;
    readonly events: _angular_core.InputSignal<CalendarEvent[]>;
    readonly tasks: _angular_core.InputSignal<CalendarTask[]>;
    readonly showCompletedTasks: _angular_core.InputSignal<boolean>;
    readonly contentMode: _angular_core.InputSignal<GridContentMode>;
    readonly resource: _angular_core.InputSignal<CalendarResource | undefined>;
    readonly resources: _angular_core.InputSignal<CalendarResource[]>;
    readonly data: _angular_core.InputSignal<CalendarGridData>;
    readonly viewMode: _angular_core.InputSignal<GridViewMode>;
    readonly columnMode: _angular_core.InputSignal<GridColumnMode>;
    readonly anchorDate: _angular_core.InputSignal<Date>;
    readonly theme: _angular_core.InputSignal<GridTheme>;
    /** Überschreibt einzelne Beschriftungen; nicht gesetzte bleiben deutsch. */
    readonly labels: _angular_core.InputSignal<Partial<GridLabels>>;
    readonly config: _angular_core.InputSignal<GridConfig>;
    /** Veto-Hook für Drag&Drop: wird beim Drop ausgewertet, `false` verwirft das Verschieben. */
    readonly canMoveEvent: _angular_core.InputSignal<(event: CalendarEvent) => boolean>;
    readonly eventsChange: _angular_core.OutputEmitterRef<CalendarEvent[]>;
    readonly tasksChange: _angular_core.OutputEmitterRef<CalendarTask[]>;
    readonly eventMoved: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventClicked: _angular_core.OutputEmitterRef<CalendarEvent>;
    /** Doppelklick auf einen Event: ID für einen Editor der Host-App. */
    readonly eventEditRequested: _angular_core.OutputEmitterRef<number>;
    readonly eventDeleted: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventUpdated: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly eventCreateRequested: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly taskCommentsRequested: _angular_core.OutputEmitterRef<number>;
    /** Pills-Zeile (Personen-Namen) wird nur in columnMode 'resource' gerendert. */
    protected readonly hasResourceColumns: _angular_core.Signal<boolean>;
    protected readonly nowLabel: _angular_core.Signal<string>;
    protected readonly effectiveLabels: _angular_core.Signal<GridLabels>;
    private readonly normalizedEvents;
    protected readonly normalizedResources: _angular_core.Signal<CalendarResource[]>;
    private readonly normalizedTasks;
    /** Platz unter der letzten Stundenlinie für Personen-Rahmen und die halbe Beschriftung "18:00"; wird von der Stundenhöhe abgezogen. */
    protected readonly frameBottomBufferPx = 10;
    protected readonly taskFrameMinHeightPx: _angular_core.Signal<number>;
    constructor();
    /** Berechnet aus dem CDK-Drop-Event die neue Start-/Endzeit (und ggf. Ressource) und meldet sie nach außen. */
    onColumnDropped(dropEvent: CdkDragDrop<string>): void;
    /** Entfernt einen Event aus dem Array und meldet die Änderung nach außen (immutable). */
    onEventDeleted(event: CalendarEvent): void;
    /** Aktualisiert einen Event (z. B. durch Resize) und meldet die Änderung nach außen (immutable). */
    onEventUpdated(updatedEvent: CalendarEvent): void;
    onEventDrawn(request: EventDrawRequest): void;
    onTasksChanged(updatedTasks: CalendarTask[]): void;
    private overlapsOtherEvent;
    private nextDraftId;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridCalendar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GridCalendar, "glc-grid-calendar", never, { "event": { "alias": "event"; "required": false; "isSignal": true; }; "events": { "alias": "events"; "required": false; "isSignal": true; }; "tasks": { "alias": "tasks"; "required": false; "isSignal": true; }; "showCompletedTasks": { "alias": "showCompletedTasks"; "required": false; "isSignal": true; }; "contentMode": { "alias": "contentMode"; "required": false; "isSignal": true; }; "resource": { "alias": "resource"; "required": false; "isSignal": true; }; "resources": { "alias": "resources"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "viewMode": { "alias": "viewMode"; "required": false; "isSignal": true; }; "columnMode": { "alias": "columnMode"; "required": false; "isSignal": true; }; "anchorDate": { "alias": "anchorDate"; "required": false; "isSignal": true; }; "theme": { "alias": "theme"; "required": false; "isSignal": true; }; "labels": { "alias": "labels"; "required": false; "isSignal": true; }; "config": { "alias": "config"; "required": false; "isSignal": true; }; "canMoveEvent": { "alias": "canMoveEvent"; "required": false; "isSignal": true; }; }, { "eventsChange": "eventsChange"; "tasksChange": "tasksChange"; "eventMoved": "eventMoved"; "eventClicked": "eventClicked"; "eventEditRequested": "eventEditRequested"; "eventDeleted": "eventDeleted"; "eventUpdated": "eventUpdated"; "eventCreateRequested": "eventCreateRequested"; "taskCommentsRequested": "taskCommentsRequested"; }, never, never, true, never>;
}

/** Lokales Datum als `YYYY-MM-DD`, das Format von `CalendarTask.date`. */
declare function toDateKey(date: Date): string;

/** Setzt GridTheme-Werte als CSS Custom Properties auf einem Host-Element. Keine hartkodierten Werte hier. */
declare class ThemeService {
    apply(theme: GridTheme, hostElement: HTMLElement): void;
    private toCssVarName;
    private toCssValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ThemeService>;
}

export { GridCalendar, GridLayoutService, ThemeService, toDateKey };
export type { CalendarEvent, CalendarGridData, CalendarResource, CalendarTask, CalendarTaskComment, DayGroup, EventDrawRequest, EventLayout, GridColumn, GridColumnMode, GridConfig, GridContentMode, GridLabels, GridLine, GridTheme, GridViewMode };
